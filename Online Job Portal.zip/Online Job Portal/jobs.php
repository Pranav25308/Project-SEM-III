<?php 
include 'connection.php';
?>
<!DOCTYPE html>
<html>
        <head>
        <meta charset="UTF-8">
        <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>
    <link href="style-jobs.css" rel="stylesheet">
    <link rel="icon" href="images/logo.png" type="image/icon type">
    <title> Jobs </title>
    <style> 
.job
{
    border: 0px solid black;
    border-radius: 25px;
    width:1100px;
    margin-left: 200px;
    padding: 25px;
    box-shadow: 10px 10px 15px 5px #b9bcbd;
}
.job_title
{
    color:#0a6cff;
    font-size:28px;
    font-weight: bold;
    font-family: Verdana, Geneva, Tahoma, sans-serif;
    text-decoration: underline;
}
.com
{
    font-size: 15px;
    font-family: Verdana, Geneva, Tahoma, sans-serif;
}
.j_d , .e_c
{
    font-size: 15px;
    font-family: Verdana, Geneva, Tahoma, sans-serif;
    font-weight: bold;
}
.j_d2 , .e_c2
{
    font-size: 14px;
    font-family: Verdana, Geneva, Tahoma, sans-serif;
}
.btn
{
    width:200px;
    height:45px;
    margin-left: 400px;
    
 
}

    </style>
        </head>
    <body>
        <div class="container-fluid">

            <?php 
             include 'header.php';
            ?>

            <br><br><br><br><br><br>
            
            <div class="jumbotron" align="center">
                <h1> Recent jobs &#128293; </h1>
                <p>Posted by Recruiters or Companies. </p>    
            </div>

            <br><br><br><br><br><br>

            <div>
                <marquee direction="left" hspace=20px>
                    <img src="Images/mnc1.jpg" height="200px" width="200px"> 
                    <img src="Images/mnc2.png" height="200px" width="200px" style="margin-left:20px;-webkit-box-shadow:none;-moz-box-shadow:none;box-shadow:none;"> 
                    <img src="Images/mnc3.webp" height="200px" width="200px" style="margin-left:20px;-webkit-box-shadow:none;-moz-box-shadow:none;box-shadow:none;">
                    <img src="Images/mbc4.png" height="200px" width="200px" style="margin-left:20px;-webkit-box-shadow:none;-moz-box-shadow:none;box-shadow:none;">
                    <img src="Images/mnc5.png" height="200px" width="200px" style="margin-left:20px;-webkit-box-shadow:none;-moz-box-shadow:none;box-shadow:none;">
                    <img src="Images/mnc6.jpg" height="200px" width="200px" style="margin-left:20px;-webkit-box-shadow:none;-moz-box-shadow:none;box-shadow:none;">
                    <img src="Images/mnc7.jfif" height="200px" width="200px" style="margin-left:20px;-webkit-box-shadow:none;-moz-box-shadow:none;box-shadow:none;">
                    <img src="Images/mnc8.png" height="200px" width="200px" style="margin-left:20px;-webkit-box-shadow:none;-moz-box-shadow:none;box-shadow:none;">
                    <img src="Images/mnc9.png" height="200px" width="200px" style="margin-left:20px;-webkit-box-shadow:none;-moz-box-shadow:none;box-shadow:none;">
                    <img src="Images/mnc10.png" height="200px" width="200px" style="margin-left:20px;-webkit-box-shadow:none;-moz-box-shadow:none;box-shadow:none;">
                    <img src="Images/mnc11.png" height="200px" width="200px" style="margin-left:20px;-webkit-box-shadow:none;-moz-box-shadow:none;box-shadow:none;">
                    <img src="Images/mnc12.png" height="200px" width="200px" style="margin-left:20px;-webkit-box-shadow:none;-moz-box-shadow:none;box-shadow:none;">
                </marquee>  
            </div>


            <br><br>
            
            <br>

            <?php
                  $records1 = "select * from jobs"; 
                  $sql1 = mysqli_query($con,$records1);


                  while ($data = mysqli_fetch_array($sql1))
                  {
                    $m1 = $data['cname'];
                    $m2 = $data['cwebsite'];
                    $m3 = $data['job_title'];
                    $m4 = $data['job_desc'];
                    $m5 = $data['job_eligibility'];
                    $m6 = $data['job_type'];
                    $m7 = $data['end_date'];
                    $m8 = $data['location'];
                ?>
                <form method="post"> 
                <div class="job">
                    <h3 class="job_title" name="jobtitle"> <?php echo "$m3"; ?> </h3>
                    <br>
                    <h5 class="com"> Company : <?php echo "$m1"; ?> </h5>
                    <h5 class="com"> Website :  <?php echo "$m2"; ?> </h5>
                    <br>
                    <h5 class="j_d"> Job Description: </h5>
                    <p class="j_d2"> <?php echo "$m4"; ?> </p>
                    <br>
                    <h5 class="e_c"> Eligibility Crietria  : </h5>
                    <p class="e_c2"> <?php echo "$m5"; ?> </p>
                    <br> 
                    <h5 class="com"> Job Type  : <?php echo "$m6"; ?> </h5>
                    <h5 class="com"> End Date  : <?php echo "$m7"; ?> </h5>
                    <h5 class="com"> Location  :  <?php echo "$m8"; ?></h5>
                    <br>
                    <input type="button" class="btn btn-primary" value="Apply" onclick="window.location.href='login.php'"> 
                </div>   <br><br><br><br><br> 
                </form>

                <?php
                  }
                ?> 
                
            <br>

            <?php  
             include 'footer.php';
            ?>
        </div>
    </body>
</html>