<?php
           include 'connection.php';
            $n = date("Y-m-d");

            echo $n;
          
            $q = "delete from jobs where end_date='$n'"; 
            if($con -> query($q))
            {
            echo "<script> alert ('Expired Jobs Removed Successfully ! ') </script>  ";
            echo "<script> window.location='job-posts.php'</script>  ";
            }
            else 
            {
                echo "Error";
            }
