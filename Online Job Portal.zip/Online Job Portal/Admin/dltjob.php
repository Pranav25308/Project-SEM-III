

            <?php
            include 'connection.php';
            $r = $_GET['compna'];


            $q = "DELETE FROM post Where jobposts='$r'";
            if ($con->query($q)) {
                echo "<script> alert ('Deleted ! ') </script>  ";
                echo "<script> window.location='job-posts.php'</script>  ";
            }
            ?>
