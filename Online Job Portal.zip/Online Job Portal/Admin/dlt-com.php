

            <?php
            include 'connection.php';
            $r = $_GET['compna'];

            $q = "DELETE FROM company_signup Where Com_Email='$r'";

            if ($con->query($q)) {
                echo "<script> alert ('Deleted ! ') </script>  ";
                echo "<script> window.location='com-reg-mng.php'</script>  ";
            } else {
                echo "ERROR";
            }


            ?>
