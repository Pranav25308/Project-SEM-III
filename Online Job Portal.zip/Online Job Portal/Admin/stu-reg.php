<?php include 'connection.php'; ?>
<!DOCTYPE html>
<html>

<head>
  <meta charset="UTF-8">
  <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.1.3/css/bootstrap.min.css" integrity="sha384-MCw98/SFnGE8fJT3GXwEOngsV7Zt27NXFoaoApmYm81iuXoPkFOJwJ8ERdknLPMO" crossorigin="anonymous">
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>
  <link href="style-stu-reg.css" rel="stylesheet">
  <link rel="icon" href="images/logo.png" type="image/icon type">
  <title> Manage job Posts </title>
  <style>
    td {
      padding: 10px;
    }

    table {
      border-collapse: separate;
      border-spacing: 0 25px;
    }

    .form-control {
      height: 40px;
      border-radius: 5px;
      width: 300px;
    }
  </style>
</head>

<body>
  <div class="container-fluid">

    <?php
    include 'header.php';
    ?>

    <br><br><br>

    <?php
    $u = $_SESSION['email'];
    ?>



    <div class="jumbotron">
      <h2 align="center"> Job Seekers Registrations </h2>

    </div>
    <br><br>
    <table class="table table-hover" width="70%">
      <thead class="thead-light">
        <tr>
          <th> Name </th>
          <th> Contact </th>
          <th> Email </th>
        </tr>
      </thead>




      <?php

      $records = "select * from student_signup";
      $sql = mysqli_query($con, $records);

      while ($data = mysqli_fetch_array($sql)) {
        $r1 = $data['Name'];
        $r2 = $data['Contact'];
        $r3 = $data['Email'];
        $r4 = $data['Password'];

      ?>

        <tr>
          <td> <?php echo "$r1"; ?> </td>
          <td> <?php echo "$r2"; ?> </td>
          <td> <?php echo "$r3"; ?> </td>
        </tr>

      <?php
      }

      ?>
    </table>





    <?php
    include 'footer.php';
    ?>

  </div>
</body>

</html>