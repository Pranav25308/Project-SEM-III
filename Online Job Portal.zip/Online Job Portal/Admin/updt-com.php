<?php include 'connection.php'; ?>
<!DOCTYPE html>
<html>

<head>
  <meta charset="UTF-8">
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>
  <link href="style-recruiter-profile.css" rel="stylesheet">
  <!-- <link rel="icon" href="images/Tlogo.png" type="image/icon type"> -->
  <title> Profile </title>
  <style>
    #int2,
    #int3,
    #cou3,
    #cou2,
    #lan2,
    #lan3,
    #lan4,
    #lan5,
    #tenth,
    #twelth,
    #gra,
    #pgra,
    #save,
    #lan-t2,
    #lang-t3 {
      display: none;
    }

    .form-control {
      width: 250px;
      display: inline;
      height: 35px;

    }

    label {
      display: inline;
    }

    td {
      padding: 15px;
    }

    #signup1 {
      margin-left: 680px;
      margin-top: 8px;
      height: 43px;
      width: 150px;
      border-radius: 15px;
      background-color: #ffffff00;
      font-size: 15px;
      border: 3px solid #39db4f;
    }

    #signup1:hover {
      color: white;
      background-color: #39db4f;
      transition: all 0.6s ease;
    }
  </style>
</head>

<body>
  <div class="container-fluid">

    <div class="jumbotron">
      <h1 align="center"> Company Profile </h1>
    </div>

    <a href="com-reg-mng.php"> Back </a>

    <?php
    $r = $_GET['compna'];
    ?>

    <?php

    $records = "select * from company_signup where Com_Email='$r'";
    $sql = mysqli_query($con, $records);

    while ($data = mysqli_fetch_array($sql)) {
      $r1 = $data['Com_Name'];
      $r2 = $data['Com_Contact'];
      $r3 = $data['Com_Email'];
      $r4 = $data['Com_Pass'];
    }

    ?>


    <form method="post" name="f1">
      <table align="center" cellspacing="10px" cellpadding="10px">

        <tr>
          <td> <label for="aname"> Name. </label>
            <font color="red" size="4px"> * </font>
          </td>
          <td> <input type="text" id="aname" class="form-control" name="name" value="<?php echo "$r1"; ?>" pattern="[a-zA-Z ]+" title="Please use alphabets only." required> </td>
        </tr>

        <tr>
          <td> <label for="acon"> Contact No. </label>
            <font color="red" size="2px"> * </font>
          </td>
          <td> <input type="text" id="acon" class="form-control" value="<?php echo "$r2"; ?>" name="pcon" pattern="(7|8|9)\d{9}" title="Please Enter 10 Digit Contact Number.It Must Be Start With 7 or 8 or 9 ." required> </td>
        </tr>

        <tr>
          <td> <label for="aemail">Email. </label>
            <font color="red" size="4px"> * </font>
          </td>
          <td> <input type="email" id="aemail" class="form-control" value="<?php echo "$r3"; ?>" name="email" readonly> </td>
        </tr>

        <tr>
          <td> <label for="apass">Password. </label>
            <font color="red" size="4px"> * </font>
          </td>
          <td> <input type="password" id="apass" class="form-control" value="<?php echo "$r4"; ?>" name="pass" pattern="(?=.*\d)(?=.*[a-z])(?=.*[A-Z]).{8,}" title="Must contain at least one number and one uppercase and lowercase letter, and at least 8 or more characters" required> </td>
        </tr>

        <tr>
          <td></td>
          <td><input type="checkbox" id="show" onclick="hide()"> Show / Hide Password <br> </td>
        </tr>

      </table> <br>
      <button type="submit" name="Seeker_btn" id="signup1"> Update </button>
    </form>

    <script>
      function hide() {
        var z = document.getElementById("apass");

        if (z.type === "password") {

          z.type = "text";
        } else {

          z.type = "password";
        }
      }
    </script>

    <br><br>
    <?php
    include 'footer.php';
    ?>

  </div>
</body>

</html>
<?php
if (isset($_POST['Seeker_btn'])) {

  $n1 = $_POST["name"];
  $n2 = $_POST["pcon"];
  $n3 = $_POST["email"];
  $n4 = $_POST["pass"];


  $q = "UPDATE company_signup SET Com_Name='$n1',Com_Contact='$n2',Com_Pass='$n4' WHERE Com_Email = '$n3'";

  if ($con->query($q)) {
    echo "<script> alert('Update Successfully !') </script>";
    echo "<script> window.location='com-reg-mng.php'</script>  ";
  }
}
?>