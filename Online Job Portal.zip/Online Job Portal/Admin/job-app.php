<?php include 'connection.php'; ?>
<!DOCTYPE html>
<html>

<head>
  <meta charset="UTF-8">
  <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.1.3/css/bootstrap.min.css" integrity="sha384-MCw98/SFnGE8fJT3GXwEOngsV7Zt27NXFoaoApmYm81iuXoPkFOJwJ8ERdknLPMO" crossorigin="anonymous">
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>
  <link href="style-stu-reg.css" rel="stylesheet">
  <link rel="icon" href="images/logo.png" type="image/icon type">
  <title> Job Applications </title>
  <style>
    td {
      padding: 10px;
    }

    table {
      border-collapse: separate;
      border-spacing: 0 25px;
    }

    .form-control {
      height: 40px;
      border-radius: 5px;
      width: 300px;
    }
  </style>
</head>

<body>
  <div class="container-fluid">

    <?php
    include 'header.php';
    ?>

    <br><br><br>

    <?php
    $u = $_SESSION['email'];
    ?>



    <div class="jumbotron">
      <h2 align="center"> Job Applications </h2>

    </div>
    <br><br>
    <table class="table table-striped">
      <thead class="thead-light">
        <tr>
          <th> Applicant's Email</th>
          <th> Company Name </th>
          <th> Company Website </th>
          <th> Job Title </th>
          <th> Job Description </th>
          <th> Job Eligibility </th>
          <th> Job Type </th>
          <th> End Date of Apply </th>
          <th> Location </th>
        </tr>
      </thead>



      <?php

      $records = "select * from applications";
      $sql = mysqli_query($con, $records);

      while ($data = mysqli_fetch_array($sql)) {
        $r1 = $data['seeker_email'];
        $r2 = $data['com_name'];
        $r3 = $data['com_website'];
        $r4 = $data['job_title'];
        $r5 = $data['job_desc'];
        $r6 = $data['job_eli'];
        $r7 = $data['job_type'];
        $r8 = $data['end_date'];
        $r9 = $data['location'];


      ?>

        <tr>
          <td> <?php echo "$r1"; ?> </td>
          <td> <?php echo "$r2"; ?> </td>
          <td> <?php echo "$r3"; ?> </td>
          <td> <?php echo "$r4"; ?> </td>
          <td> <?php echo "$r5"; ?> </td>
          <td> <?php echo "$r6"; ?> </td>
          <td> <?php echo "$r7"; ?> </td>
          <td> <?php echo "$r8"; ?> </td>
          <td> <?php echo "$r9"; ?> </td>
        </tr>

      <?php
      }

      ?>
    </table>





    <?php
    include 'footer.php';
    ?>

  </div>
</body>

</html>