<?php

session_start();//session is a way to store information (in variables) to be used across multiple pages.  
/*
header("Location: http://localhost/Online%20Job%20Portal/login.php");
session_destroy();  
*/
    unset($_SESSION['email']);  
      session_destroy();  
      header("Location: http://localhost/Online%20Job%20Portal/login.php");
