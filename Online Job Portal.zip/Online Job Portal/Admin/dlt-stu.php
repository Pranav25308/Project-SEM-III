

            <?php
            include 'connection.php';
            $r = $_GET['compna'];



            $q = "DELETE FROM student_signup Where Email='$r'";

            if ($con->query($q)) {
                echo "<script> alert ('Deleted ! ') </script>  ";
                echo "<script> window.location='stu-reg-mng.php'</script>  ";
            } else {
                echo "ERROR";
            }


            ?>
