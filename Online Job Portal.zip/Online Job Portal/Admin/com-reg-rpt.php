<?php include 'connection.php'; ?>
<!DOCTYPE html>
<html>

<head>
    <meta charset="UTF-8">
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.1.3/css/bootstrap.min.css" integrity="sha384-MCw98/SFnGE8fJT3GXwEOngsV7Zt27NXFoaoApmYm81iuXoPkFOJwJ8ERdknLPMO" crossorigin="anonymous">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>
    <link href="style-stu-reg.css" rel="stylesheet">

    <link rel="icon" href="images/logo.png" type="image/icon type">
    <title> Company Registrations </title>
    <style>
        td {
            padding: 10px;
        }

        table {
            border-collapse: separate;
            border-spacing: 0 25px;
        }

        .form-control {
            height: 40px;
            border-radius: 5px;
            width: 300px;
        }

        #prn {
            width: 130px;
            height: 40px;
            margin-left: 620px;
        }

        #prn:hover {
            background-color: white;
            transition: 0.5s ease;
        }
    </style>
</head>

<body>
    <div class="container-fluid">

        <?php
        include 'header.php';
        ?>

        <br><br><br>

        <?php
        $u = $_SESSION['email'];
        ?>



        <div class="jumbotron">
            <h2 align="center"> Company Registration Report </h2>
            <h5 align="center"> You Can Print Report Below ! </h5>

        </div>
        <br><br>
        <div id="prnt">
            <table class="table table-hover" width="70%">
                <thead class="thead-light">
                    <tr>
                        <th> Name </th>
                        <th> Contact </th>
                        <th> Email </th>
                    </tr>
                </thead>

                <?php

                $records = "select * from company_signup";
                $sql = mysqli_query($con, $records);

                while ($data = mysqli_fetch_array($sql)) {
                    $r1 = $data['Com_Name'];
                    $r2 = $data['Com_Contact'];
                    $r3 = $data['Com_Email'];
                    $r4 = $data['Com_Pass'];

                ?>

                    <tr>
                        <td> <?php echo "$r1"; ?> </td>
                        <td> <?php echo "$r2"; ?> </td>
                        <td> <?php echo "$r3"; ?> </td>
                    </tr>

                <?php
                }

                ?>
            </table>
        </div>

        <br>
        <br>
        <button class="btn btn-dark" id="prn" onclick="printPageArea('prnt')"> Download <i class="glyphicon glyphicon-download-alt"></i> </button>
        <br><br>

        <script>
            function printPageArea(prnt) {
                var printContent = document.getElementById(prnt);
                var WinPrint = window.open('', '', 'width=900,height=650');
                WinPrint.document.write(printContent.innerHTML);
                WinPrint.document.close();
                WinPrint.focus();
                WinPrint.print();
                WinPrint.close();
            }
        </script>




        <?php
        include 'footer.php';
        ?>

    </div>
</body>

</html>