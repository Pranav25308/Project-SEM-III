

            <?php
            include 'connection.php';
            $r = $_GET['compna'];
            echo "$r";

            $records = "select * from student_signup where Name='$r'";
            $sql = mysqli_query($con, $records);
            while ($data = mysqli_fetch_array($sql)) {
              $q1 = $data['Email'];
            }

            $q = "DELETE FROM applicant_edu Where email='$q1'";
            $w = "DELETE FROM applicant_exp Where email='$q1'";
            $e = "DELETE FROM applicant_other Where email='$q1'";
            $t = "DELETE FROM applicant_profile Where email='$q1'";

            if ($con->query($q) && $con->query($w) && $con->query($e) && $con->query($t)) {
              echo "<script> alert ('Deleted ! ') </script>  ";
              echo "<script> window.location='stu-pro-mng.php'</script>  ";
            }
            ?>
