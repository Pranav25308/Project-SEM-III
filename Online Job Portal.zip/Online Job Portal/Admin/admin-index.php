<?php include 'connection.php'; ?>
<!DOCTYPE html>
<html>

<head>
  <meta charset="UTF-8">
  <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.1.3/css/bootstrap.min.css" integrity="sha384-MCw98/SFnGE8fJT3GXwEOngsV7Zt27NXFoaoApmYm81iuXoPkFOJwJ8ERdknLPMO" crossorigin="anonymous">
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>
  <link href="style-recruiter-profile.css" rel="stylesheet">
  <link rel="icon" href="images/logo.png" type="image/icon type">
  <title> Profile </title>
  <style>
  

    td {
      padding: 10px;
    }

    table {
      border-collapse: separate;
      border-spacing: 0 25px;
    }

    .form-control {
      height: 40px;
      border-radius: 5px;
      width: 300px;
    }
  </style>
</head>

<body>
  <div class="container-fluid">

    <?php
    include 'header.php';
    ?>

    <br><br><br>

    <?php
    $u = $_SESSION['email'];


    $records = "select * from admin where Username ='$u'";
    $sql = mysqli_query($con, $records);


    while ($data = mysqli_fetch_array($sql)) {
      $n1 = $data['Username'];
      $n2 = $data['Password'];
    }
    ?>



    <form method="post">

      <table cellspacing="20px" cellpadding="30px" style="margin-left:400px;">

        <tr>
          <td> <label for="unm"> Username :- </label> </td>
          <td> <input type="password" class="form-control" id="unm" name="unm" value="<?php echo "$n1"; ?>"> </td>
        </tr>

        <tr>
          <td><label for="pass"> Password :- </label> </td>
          <td> <input type="password" id="pass" class="form-control" name="pass" value="<?php echo "$n2"; ?>"> </td>
        </tr>

        <tr>
          <td></td>
          <td><input type="checkbox" id="show" onclick="hide()"> Show / Hide <br> </td>
        </tr>

      </table>

      <!-- <button type="submit" class="btn btn-success" name="base-save" style="margin-left:560px;width:150px;"> Update  </button> -->
    </form>
    <br><br><br>

    <script>
      function hide() {
        var y = document.getElementById("unm");
        var z = document.getElementById("pass");

        if (y.type === "password" & z.type === "password") {
          y.type = "text";
          z.type = "text";
        } else {
          y.type = "password";
          z.type = "password";
        }
      }
    </script>


    <?php
    include 'footer.php';
    ?>

  </div>
</body>

</html>

<?php
error_reporting(0); {
  $n = date("Y-m-d");
  //echo $n;

  $q = "delete from jobs where end_date <= '$n'";

  if ($con->query($q)) {
  }
  //echo "<script> alert ('Expired Jobs Removed Successfully ! ') </script>  ";
  //echo "<script> window.location='job-posts.php'</script>  ";
}

if (isset($_POST['exp-save'])) {
  $q1 = $_POST["unm"];
  $q2 = $_POST["pass"];


  $q = "UPDATE admin SET Username='$q1' , Password='$q2' WHERE Username='$u'";

  if ($con->query($q)) {

    echo "<script> alert ('Update Successfull ! ') </script>  ";
  }
}

?>