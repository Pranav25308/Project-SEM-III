<?php include 'connection.php'; ?>
<!DOCTYPE html>
<html>

<head>
    <meta charset="UTF-8">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>
    <link href="style-recruiter-profile.css" rel="stylesheet">
    <!-- <link rel="icon" href="images/Tlogo.png" type="image/icon type"> -->
    <title> Profile </title>
    <style>
        #int2,
        #int3,
        #cou3,
        #cou2,
        #lan2,
        #lan3,
        #lan4,
        #lan5,
        #tenth,
        #twelth,
        #gra,
        #pgra,
        #save,
        #lan-t2,
        #lang-t3 {
            display: none;
        }

        .form-control {
            width: 300px;
            margin-left: 600px;
        }
    </style>
</head>

<body>
    <div class="container-fluid">

        <div class="jumbotron">
            <h1 align="center"> Update Job post </h1>
        </div>

        <a href="job-posts.php"> Back To Applications </a>
        <br><br><br><br>

        <?php
        $r = $_GET['compna'];
        ?>

        <form method="post">
            <input type="text" value="<?php echo "$r"; ?>" name="post" class="form-control"> <br> <br>
            <button type="submit" class="btn btn-success" name="save" style="margin-left:660px;width:150px;"> Update </button>
        </form>

        <br><br><br><br>
        <?php
        include 'footer.php';
        ?>
s
    </div>
</body>

</html>

<?php
if (isset($_POST['save'])) {
    $q1 = $_POST["post"];
    $q2 = $_POST["post"];


    $q = "UPDATE post SET jobposts='$q1' WHERE jobposts='$q2'";
    if ($con->query($q)) {
        echo "<script> alert ('Updated ! ') </script>  ";

        //echo "<script> window.location='job-posts.php'</script>";
    } else {
        echo "ERROR";
    }
}
?>