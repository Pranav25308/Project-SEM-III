<div class="header"><br>
    <nav class="navbar navbar-expand-lg">
        <div>
            <ul class="nav navbar-nav" style="margin-left:220px;font-family:Verdana;">
                <li> <a href="admin-index.php" class="navi"> Profile </a> </li>

                <li class="nav-item dropdown" style="">
                    <a class="nav-link dropdown-toggle" href="#" style="margin-left: 75px;font-size: 18px;color: black;border-bottom: 1px solid black;" id="navbarDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                        View
                    </a>
                    <div class="dropdown-menu" aria-labelledby="navbarDropdown">
                        <a class="dropdown-item" style="font-size: 17px;" href="stu-reg.php"> Student Registrations</a>
                        <div class="dropdown-divider"></div>
                        <a class="dropdown-item" style="font-size: 17px;" href="com-reg.php">Company Registrations</a>
                        <div class="dropdown-divider"></div>
                        <a class="dropdown-item" style="font-size: 17px;" href="stu-pro.php">Student Profile</a>
                        <div class="dropdown-divider"></div>
                        <a class="dropdown-item" style="font-size: 17px;" href="job-app.php">Job Applications</a>
                        <div class="dropdown-divider"></div>
                        <a class="dropdown-item" style="font-size: 17px;" href="avail-job.php">Available jobs</a>

                    </div>
                </li>

                <li class="nav-item dropdown">
                    <a class="nav-link dropdown-toggle" style="margin-left: 75px;font-size: 18px;color: black;opacity: 0.8;border-bottom: 1px solid black;" href="#" id="navbarDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                        Manage
                    </a>
                    <div class="dropdown-menu" aria-labelledby="navbarDropdown">
                        <a class="dropdown-item" style="font-size: 17px;" href="stu-reg-mng.php"> Student Registrations</a>
                        <div class="dropdown-divider"></div>
                        <a class="dropdown-item" style="font-size: 17px;" href="com-reg-mng.php">Company Registrations</a>
                        <div class="dropdown-divider"></div>
                        <a class="dropdown-item" style="font-size: 17px;" href="stu-pro-mng.php">Student Profile</a>
                        <div class="dropdown-divider"></div>
                        <a class="dropdown-item" style="font-size: 17px;" href="queries.php">Queries</a>
                        <div class="dropdown-divider"></div>
                        <a class="dropdown-item" style="font-size: 17px;" href="job-posts.php"> Job Posts </a>
                    </div>
                </li>

                <li class="nav-item dropdown">
                    <a class="nav-link dropdown-toggle" style="margin-left: 75px;font-size: 18px;color: black;opacity: 0.8;border-bottom: 1px solid black;" href="#" id="navbarDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                        Reports
                    </a>
                    <div class="dropdown-menu" aria-labelledby="navbarDropdown">
                        <a class="dropdown-item" style="font-size: 17px;" href="stu-reg-rpt.php"> Student Registration Report</a>
                        <div class="dropdown-divider"></div>
                        <a class="dropdown-item" style="font-size: 17px;" href="com-reg-rpt.php">Company Registration Report</a>
                    </div>
                </li>

                <li> <a href="logout.php" class="navi"> Logout </a> </li>

            </ul>
        </div>
    </nav>
</div>