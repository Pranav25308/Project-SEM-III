

            <?php
            include 'connection.php';
            $r = $_GET['compna'];

            $q = "DELETE FROM contact Where Email='$r'";

            if ($con->query($q)) {
                echo "<script> alert ('Deleted ! ') </script>  ";
                echo "<script> window.location='queries.php'</script>  ";
            }
            ?>
