<?php include 'connection.php'; ?>
<!DOCTYPE html>
<html>

<head>
  <meta charset="UTF-8">
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>
  <link href="style-recruiter-profile.css" rel="stylesheet">
  <link rel="icon" href="images/logo.png" type="image/icon type">
  <title> Profile </title>
  <style>
  </style>
</head>

<body>
  <div class="container-fluid">

    <?php
    include 'header.php';
    ?>

    <br><br><br><br><br><br>

    <?php
    $u = $_SESSION['email'];

    $records = "select * from company_signup where Com_Email ='$u'";
    $sql = mysqli_query($con, $records);


    while ($data = mysqli_fetch_array($sql)) {
      $n1 = $data['Com_Name'];
      $n2 = $data['Com_Contact'];
    }
    ?>


    <div>
      <p> <label> Company Name :- </label> <?php echo "$n1"; ?> </p>
      <p> <label> Company Contact:- </label> <?php echo "$n2"; ?> </p>
    </div>
    <br><br><br><br><br><br><br><br><br><br><br>
    <?php
    include 'footer.php';
    ?>
  </div>
</body>

</html>