<?php include 'connection.php'; ?>
<!DOCTYPE html>
<html>

<head>
    <meta charset="UTF-8">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>
    <link href="style-recruiter-contact.css" rel="stylesheet">
    <link rel="icon" href="images/logo.png" type="image/icon type">
    <title> Contact Us </title>
    <style>
        .fa {
            padding: 15px;
            display: inline;
            font-size: 25px;
            width: 30px;
            border-radius: 8px;
        }

        .fa:hover {
            opacity: 0.7;
            cursor: pointer;
        }

        .fa-facebook {
            background-color: #3B5998;
            color: white;
            margin-left: 20px;
        }

        .fa-twitter {
            background-color: #55ACCE;
            color: white;
            margin-left: 5px;
        }

        .fa-pinterest {
            background-color: red;
            color: white;
            margin-left: 5px;
        }

        .fa-linkedin {
            background-color: #0e76a8;
            color: white;
            margin-left: 5px;
        }

        .fa-instagram {
            background: #f09433;
            background: -moz-linear-gradient(45deg, #f09433 0%, #e6683c 25%, #dc2743 50%, #cc2366 75%, #bc1888 100%);
            background: -webkit-linear-gradient(45deg, #f09433 0%, #e6683c 25%, #dc2743 50%, #cc2366 75%, #bc1888 100%);
            background: linear-gradient(45deg, #f09433 0%, #e6683c 25%, #dc2743 50%, #cc2366 75%, #bc1888 100%);
            filter: progid:DXImageTransform.Microsoft.gradient(startColorstr='#f09433', endColorstr='#bc1888', GradientType=1);
            color: white;
            margin-left: 5px;
        }

        .fa-skype {
            background-color: #00aff0;
            color: white;
            margin-left: 5px;

        }

        .fa-whatsapp {
            color: #fff;
            background:
                linear-gradient(#25d366, #25d366) 14% 84%/16% 16% no-repeat,
                radial-gradient(#25d366 60%, transparent 0);

            margin-left: 5px;
        }

        p {
            font-size: 17px;
        }

        p:hover {
            cursor: text;
            text-decoration: underline;
        }

        td {
            padding: 20px;
        }

        .form-control {
            width: 300px;
            height: 40px;
        }

        #submit {
            margin-left: 720px;
            height: 40px;
            width: 120px;
            font-size: 18px;
        }

        a:hover {
            text-decoration: none;
        }
    </style>
</head>

<body>
    <div class="container-fluid">

        <?php
        include 'header.php';
        ?>


        <div class="jumbotron">
            <h1 align="center">Contact Us</h1>
        </div>
        <br><br>
        <div>
            <label class=""><i class="fa fa-envelope"></i></label>
            <p style="display:inline;"> support.onlinejobportal@gmail.com </p> <br><br>


            <label><i class="fa fa-comments"></i></label>
            <p style="display:inline;"> +91 9089768976 , +91 9089768978 , +91 9089768979 , 020 - 897654. </p> <br>
            <br><br><br><br>

            <a href="https://www.facebook.com/" target="_blank"> <i class="fa fa-facebook"></i></a>
            <a href="https://twitter.com/" target="_blank"> <i class="fa fa-twitter"></i> </a>
            <a href="https://www.pinterest.com/" target="_blank"> <i class="fa fa-pinterest"></i> </a>
            <a href="https://www.linkedin.com/" target="_blank"> <i class="fa fa-linkedin"></i> </a>
            <a href="https://www.instagram.com/" target="_blank"> <i class="fa fa-instagram"></i></a>
            <a href="https://www.skype.com/en/" target="_blank"> <i class="fa fa-skype"></i> </a>
            <a href="https://www.whatsapp.com/" target="_blank"> <i class="fa fa-whatsapp"></i> </a>
        </div>

        <br><br><br><br><br><br><br><br><br><br>

        <div>
            <form method="post">
                <table align="center" cellspacing="10px" cellpadding="10px">
                    <tr>
                        <td> <label for="email">Email. </label>
                            <font color="red" size="4px"> * </font>
                        </td>
                        <td> <input type="email" id="email" class="form-control" placeholder="Enter your Email." name="email" required> </td>
                    </tr>

                    <tr>
                        <td> <label for="msg"> Message. </label>
                            <font color="red" size="4px"> * </font>
                        </td>
                        <td> <textarea id="msg" name="msg" class="form-control" rows="4" required> </textarea> </td>
                    </tr>

                </table> <br>
                <button type="submit" id="submit" name="submit" class="btn btn-primary"> Submit </button>
            </form>
        </div>

        <br>



        <br><br>

        <br>

        <?php
        include 'footer.php';
        ?>
    </div>
</body>

</html>
<?php
if (isset($_POST['submit'])) {
    $n1 = $_POST["email"];
    $n2 = $_POST["msg"];

    $q = "insert into contact values('$n1','$n2')";

    if ($con->query($q)) {

        echo "<script> alert ('Your Query has been recorded. Our team will reach at you shortly. Thank You.') </script>  ";
    } else {
        echo "ERROR";
    }
}
?>