<!DOCTYPE html>
<html>

<head>
    <meta charset="UTF-8">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>
    <link href="style-rc-com.css" rel="stylesheet">
    <!-- <link rel="icon" href="images/Tlogo.png" type="image/icon type"> -->
    <title> Complete / Update Profile </title>
    <style>


    </style>
</head>

<body>
    <div class="container-fluid">

        <?php
        include 'header.php';
        ?>
        <?php
        session_start();
        $eml = $_SESSION['email'];
        ?>

        <div class="jumbotron">
            <h2 align="center">You Can Complete or Edit Your Details Here ! </h2>
        </div>
        <br><br>

        <button class="basic-info-btn"> Basic Information </button>
        <button class="edu-info-btn"> Educational Information </button>
        <button class="other-info-btn"> Other Information </button>
        <button class="expr-info-btn"> Experience </button>
        <div class="content"><br><br><br>
            <div class="basic-info-content">
                <form method="post">

                    <table cellspacing="20px" cellpadding="20px" style="margin-left:130px;">
                        <tr>
                            <td colspan="2" align="center" style="background-color:#52afde;color:#f2f5f4;"> <b> <big> <big> Fill or Update Your Basic Details Here. !! </big></big> </b> </td>
                        </tr>
                        <tr>
                            <td> <label for="email"> Email : </label>
                                <font color="red" size="4px"> * </font>
                            </td>
                            <td> <input type="email" class="form-control" id="email" name="email" readonly value="<?php echo $_SESSION['email']; ?>"> </td>
                        </tr>
                        <tr><br>
                            <td><label for="name"> Company Full Name : </label>
                                <font color="red" size="4px"> * </font>
                            </td>
                            <td> <input type="text" id="name" class="form-control" name="name" required> </td>
                        </tr>

                        <tr>
                            <td> <label for="add"> Company Address : </label>
                                <font color="red" size="4px"> * </font>
                            </td>
                            <td> <textarea id="add" class="form-control" rows="4" cols="3"> </textarea></td>
                        </tr>

                        <tr>
                            <td> <label for="con"> Company Contact :</label>
                                <font color="red" size="2px"> * </font>
                            </td>
                            <td> <input type="text" class="form-control" id="con" name="con" pattern="(7|8|9)\d{9}" title="Please Enter 10 Digit Contact Number.It Must Be Start With 7 or 8 or 9 ." required> </td>
                        </tr>

                        <tr>
                            <td> <label for="pro-img"> Company Image : </label>
                                <font color="red" size="4px"> * </font>
                            </td>
                            <td> <input type="file" class="form-control" id="pro-img" name="pro-img" required> </td>
                        </tr>

                    </table>
                    <br>
                    <button type="submit" class="btn btn-success" name="base-save" style="margin-left:300px;"> Save </button>
                    <br><br><br>
                </form>
            </div>
            <script>
                $('.basic-info-btn').click(function() {
                    $('.basic-info-content').show();
                    $('.edu-info-content').hide();
                    $('.other-info-content').hide();
                    $('.expr-info-content').hide();
                    $('.basic-info-btn').css({
                        'border': '3px solid #4d86e8',
                    });
                    $('.edu-info-btn').css({
                        'border': 'none',
                    });
                    $('.other-info-btn').css({
                        'border': 'none',
                    });
                    $('.expr-info-btn').css({
                        'border': 'none',
                    });
                });
            </script>

            <div class="edu-info-content">
                <form method="post">

                    <table cellspacing="20px" cellpadding="20px" style="margin-left:130px;">
                        <tr>
                            <td colspan="2" align="center" style="background-color:#52afde;color:#f2f5f4;"> <b> <big> <big> Fill or Update Your Educational Details Here. !! </big></big> </b> </td>
                        </tr>

                        <tr>
                            <td> <label for="email"> Email : </label>
                                <font color="red" size="4px"> * </font>
                            </td>
                            <td> <input type="email" class="form-control" id="email" name="email" readonly value="<?php echo $_SESSION['email']; ?>"> </td>
                        </tr>
                    </table>

                    <hr style="border-top: 1px solid black;">
                    <h3 style="text-decoration:underline;margin-left:20px;"> 10th (X) Details </h3>

                    <table cellspacing="20px" cellpadding="20px" style="margin-left:130px;">
                        <tr>
                            <td> <label for="10-sch-nm"> School Name : </label>
                                <font color="red" size="4px"> * </font>
                            </td>
                            <td> <input type="text" class="form-control" id="10-sch-nm" name="10-sch-nm" required> </td>
                        </tr>

                        <tr>
                            <td> <label for="10-sch-uni"> University : </label>
                                <font color="red" size="4px"> * </font>
                            </td>
                            <td> <input type="text" class="form-control" id="10-sch-uni" name="10-sch-uni" required> </td>
                        </tr>

                        <tr>
                            <td> <label for="10-sch-from"> From : </label>
                                <font color="red" size="4px"> * </font>
                            </td>
                            <td> <input type="date" class="form-control" id="10-sch-from" name="10-sch-from" required> </td>
                        </tr>

                        <tr>
                            <td> <label for="10-sch-to"> To : </label>
                                <font color="red" size="4px"> * </font>
                            </td>
                            <td> <input type="date" class="form-control" id="10-sch-to" name="10-sch-to" required> </td>
                        </tr>

                        <tr>
                            <td> <label for="10-sch-grade"> Percentage / CGPA : </label>
                                <font color="red" size="4px"> * </font>
                            </td>
                            <td> <input type="text" class="form-control" id="10-sch-grade" name="10-sch-grade" required> </td>
                        </tr>

                        <tr>
                            <td> <label for="10-sch-period"> Period : </label>
                                <font color="red" size="4px"> * </font>
                            </td>
                            <td> <select class="form-control" id="10-sch-period" name="10-sch-period">
                                    <option value=""> -- Select --</option>
                                    <option value="part-time"> Part Time</option>
                                    <option value="full-time"> Full Time </option>
                                </select>
                            </td>
                        </tr>

                    </table>

                    <hr style="border-top: 1px solid black;">
                    <h3 style="text-decoration:underline;margin-left:20px;"> 12th (XII) Details </h3>

                    <table cellspacing="20px" cellpadding="20px" style="margin-left:130px;">
                        <tr>
                            <td> <label for="12-sch-nm"> School / College Name : </label>
                                <font color="red" size="4px"> * </font>
                            </td>
                            <td> <input type="text" class="form-control" id="12-sch-nm" name="12-sch-nm" required> </td>
                        </tr>

                        <tr>
                            <td> <label for="12-sch-fld"> Stream : </label>
                                <font color="red" size="4px"> * </font>
                            </td>
                            <td> <select id="12-sch-fld" name="12-sch-fld" required class="form-control">
                                    <option> -- Select --</option>
                                    <option value="science"> Science </option>
                                    <option value="commerce"> Commerce </option>
                                    <option value="arts"> Arts </option>
                                </select> </td>
                        </tr>

                        <tr>
                            <td> <label for="12-sch-uni"> University : </label>
                                <font color="red" size="4px"> * </font>
                            </td>
                            <td> <input type="text" class="form-control" id="12-sch-uni" name="12-sch-uni" required> </td>
                        </tr>

                        <tr>
                            <td> <label for="12-sch-from"> From : </label>
                                <font color="red" size="4px"> * </font>
                            </td>
                            <td> <input type="date" class="form-control" id="12-sch-from" name="12-sch-from" required> </td>
                        </tr>

                        <tr>
                            <td> <label for="12-sch-to"> To : </label>
                                <font color="red" size="4px"> * </font>
                            </td>
                            <td> <input type="date" class="form-control" id="12-sch-to" name="12-sch-to" required> </td>
                        </tr>

                        <tr>
                            <td> <label for="12-sch-grade"> Percentage / CGPA : </label>
                                <font color="red" size="4px"> * </font>
                            </td>
                            <td> <input type="text" class="form-control" id="12-sch-grade" name="12-sch-grade" required> </td>
                        </tr>

                        <tr>
                            <td> <label for="12-sch-period"> Period : </label>
                                <font color="red" size="4px"> * </font>
                            </td>
                            <td> <select class="form-control" id="12-sch-period" name="12-sch-period" required>
                                    <option value=""> -- Select --</option>
                                    <option value="part-time"> Part Time</option>
                                    <option value="full-time"> Full Time </option>
                                </select>
                            </td>
                        </tr>

                    </table>

                    <hr style="border-top: 1px solid black;">
                    <h3 style="text-decoration:underline;margin-left:20px;"> Graduation Details </h3>

                    <table cellspacing="20px" cellpadding="20px" style="margin-left:130px;">
                        <tr>
                            <td> <label for="gra-cou"> Course : </label>
                                <font color="red" size="4px"> * </font>
                            </td>
                            <td> <select class="form-control" id="gra-cou" name="gra-cou" required>
                                    <option> -- Select -- </option>
                                    <option value="BE"> B.E </option>
                                    <option value="BTech"> B.Tech </option>
                                    <option value="BArch"> B.Arch </option>
                                    <option value="BCA"> BCA </option>
                                    <option value="BCS"> BCS </option>
                                    <option value="BSC"> BSC </option>
                                    <option value="BPharma"> BPharma </option>
                                    <option value="BCom"> B.COM </option>
                                    <option value="BBA"> BBA </option>
                                    <option value="BA"> BA </option>
                                </select> </td>
                        </tr>

                        <tr>
                            <td> <label for="gra-sch-nm"> College Name : </label>
                                <font color="red" size="4px"> * </font>
                            </td>
                            <td> <input type="text" class="form-control" id="gra-sch-nm" name="gra-sch-nm" required> </td>
                        </tr>

                        <tr>
                            <td> <label for="gra-sch-uni"> University : </label>
                                <font color="red" size="4px"> * </font>
                            </td>
                            <td> <input type="text" class="form-control" id="gra-sch-uni" name="gra-sch-uni" required> </td>
                        </tr>

                        <tr>
                            <td> <label for="gra-sch-from"> From : </label>
                                <font color="red" size="4px"> * </font>
                            </td>
                            <td> <input type="date" class="form-control" id="gra-sch-from" name="gra-sch-from" required> </td>
                        </tr>

                        <tr>
                            <td> <label for="gra-sch-to"> To : </label>
                                <font color="red" size="4px"> * </font>
                            </td>
                            <td> <input type="date" class="form-control" id="gra-sch-to" name="gra-sch-to" required> </td>
                        </tr>

                        <tr>
                            <td> <label for="gra-sch-grade"> Percentage / CGPA : </label>
                                <font color="red" size="4px"> * </font>
                            </td>
                            <td> <input type="text" class="form-control" id="gra-sch-grade" name="gra-sch-grade" required> </td>
                        </tr>

                        <tr>
                            <td> <label for="gra-sch-period"> Period : </label>
                                <font color="red" size="4px"> * </font>
                            </td>
                            <td> <select class="form-control" id="gra-sch-period" name="gra-sch-period" required>
                                    <option value=""> -- Select --</option>
                                    <option value="part-time"> Part Time</option>
                                    <option value="full-time"> Full Time </option>
                                </select>
                            </td>
                        </tr>

                    </table>

                    <hr style="border-top: 1px solid black;">
                    <h3 style="text-decoration:underline;margin-left:20px;"> Post Graduation Details </h3>

                    <table cellspacing="20px" cellpadding="20px" style="margin-left:130px;">
                        <tr>
                            <td> <label for="pg-cou"> Course : </label>
                                <font color="red" size="4px"> * </font>
                            </td>
                            <td> <select class="form-control" id="pg-cou" name="pg-cou" required>
                                    <option> -- Select -- </option>
                                    <option value="ME"> M.E </option>
                                    <option value="MTech"> M.Tech </option>
                                    <option value="MArch"> M.Arch </option>
                                    <option value="MCA"> MCA </option>
                                    <option value="MCS"> MCS </option>
                                    <option value="MSC"> MSC </option>
                                    <option value="MPharma"> MPharma </option>
                                    <option value="MCom"> M.COM </option>
                                    <option value="MBA"> MBA </option>
                                    <option value="MA"> MA </option>
                                </select> </td>
                        </tr>
                        <tr>
                            <td> <label for="pg-sch-nm"> College Name : </label> </td>
                            <td> <input type="text" class="form-control" id="pg-sch-nm" name="pg-sch-nm"> </td>
                        </tr>

                        <tr>
                            <td> <label for="pg-sch-uni"> University : </label> </td>
                            <td> <input type="text" class="form-control" id="pg-sch-uni" name="pg-sch-uni"> </td>
                        </tr>

                        <tr>
                            <td> <label for="pg-sch-from"> From : </label> </td>
                            <td> <input type="date" class="form-control" id="pg-sch-from" name="pg-sch-from"> </td>
                        </tr>

                        <tr>
                            <td> <label for="pg-sch-to"> To : </label> </td>
                            <td> <input type="date" class="form-control" id="pg-sch-to" name="pg-sch-to"> </td>
                        </tr>

                        <tr>
                            <td> <label for="pg-sch-grade"> Percentage / CGPA : </label> </td>
                            <td> <input type="text" class="form-control" id="pg-sch-grade" name="pg-sch-grade"> </td>
                        </tr>

                        <tr>
                            <td> <label for="pg-sch-period"> Period : </label></td>
                            <td> <select class="form-control" id="pg-sch-period" name="pg-sch-period">
                                    <option value=""> -- Select --</option>
                                    <option value="part-time"> Part Time</option>
                                    <option value="full-time"> Full Time </option>
                                </select>
                            </td>
                        </tr>

                    </table>
                    <br>
                    <button type="submit" class="btn btn-success" name="base-save" style="margin-left:300px;"> Save </button>
                    <br><br><br>
                </form>
            </div>
            <script>
                $('.edu-info-btn').click(function() {
                    $('.edu-info-content').show();
                    $('.basic-info-content').hide();
                    $('.other-info-content').hide();
                    $('.expr-info-content').hide();
                    $('.edu-info-btn').css({
                        'border': '3px solid #4d86e8',
                    });
                    $('.basic-info-btn').css({
                        'border': 'none',
                    });
                    $('.other-info-btn').css({
                        'border': 'none',
                    });
                    $('.expr-info-btn').css({
                        'border': 'none',
                    });
                });
            </script>

            <div class="other-info-content">
                <form method="post">

                    <table cellspacing="20px" cellpadding="20px" style="margin-left:130px;">
                        <tr>
                            <td colspan="2" align="center" style="background-color:#52afde;color:#f2f5f4;"> <b> <big> <big> Fill or Update Other Details Here. !! </big></big> </b> </td>
                        </tr>
                        <tr>
                            <td> <label for="email"> Email : </label>
                                <font color="red" size="4px"> * </font>
                            </td>
                            <td> <input type="email" class="form-control" id="email" name="email" readonly value="<?php echo $_SESSION['email']; ?>"> </td>
                        </tr>
                    </table>

                    <hr style="border-top: 1px solid black;">
                    <h3 style="text-decoration:underline;margin-left:20px;"> Interests </h3>

                    <table cellspacing="20px" cellpadding="20px" style="margin-left:130px;">
                        <tr>
                            <td> <label for="hobby1"> 1 : </label>
                                <font color="red" size="4px"> * </font>
                            </td>
                            <td> <input type="text" class="form-control" id="hobby1" name="hobby1" required> </td>
                        </tr>

                        <tr>
                            <td> <label for="hobby2"> 2 : </label>
                                <font color="red" size="4px"> * </font>
                            </td>
                            <td> <input type="text" class="form-control" id="hobby2" name="hobby2" required> </td>
                        </tr>

                        <tr>
                            <td> <label for="hobby3"> 3 : </label>
                                <font color="red" size="4px"> * </font>
                            </td>
                            <td> <input type="text" class="form-control" id="hobby3" name="hobby3" required> </td>
                        </tr>

                    </table>

                    <hr style="border-top: 1px solid black;">
                    <h3 style="text-decoration:underline;margin-left:20px;"> Certifications </h3>

                    <table cellspacing="20px" cellpadding="20px" style="margin-left:130px;">
                        <tr>
                            <td> <label for="course1"> Course Name (1): </label> </td>
                            <td> <input type="text" class="form-control" id="course1" name="course1"> </td>
                        </tr>

                        <tr>
                            <td> <label for="inst_nm1"> Institute Name : </label> </td>
                            <td> <input type="text" class="form-control" id="inst_nm1" name="inst_nm1"> </td>
                        </tr>

                        <tr>
                            <td> <label for="course1_from"> From : </label> </td>
                            <td> <input type="date" class="form-control" id="course1_from" name="course1_from"> </td>
                        </tr>

                        <tr>
                            <td> <label for="course1_to"> To : </label> </td>
                            <td> <input type="date" class="form-control" id="course1_to" name="course1_to"> </td>
                        </tr>

                        <tr>
                            <td> <label for="course1_per"> Percentage / CGPA: </label> </td>
                            <td> <input type="text" class="form-control" id="course1_per" name="course1_per"> </td>
                        </tr>

                        <tr>
                            <td> <label for="course2"> Course Name (2): </label> </td>
                            <td> <input type="text" class="form-control" id="course2" name="course2"> </td>
                        </tr>

                        <tr>
                            <td> <label for="inst_nm2"> Institute Name : </label> </td>
                            <td> <input type="text" class="form-control" id="inst_nm2" name="inst_nm2"> </td>
                        </tr>

                        <tr>
                            <td> <label for="course2_from"> From : </label> </td>
                            <td> <input type="date" class="form-control" id="course2_from" name="course2_from"> </td>
                        </tr>

                        <tr>
                            <td> <label for="course2_to"> To (1): </label> </td>
                            <td> <input type="date" class="form-control" id="course2_to" name="course2_to"> </td>
                        </tr>

                        <tr>
                            <td> <label for="course2_per"> Percentage / CGPA: </label>
                                <font color="red" size="4px"> * </font>
                            </td>
                            <td> <input type="text" class="form-control" id="course2_per" name="course2_per"> </td>
                        </tr>

                    </table>

                    <hr style="border-top: 1px solid black;">
                    <table cellspacing="20px" cellpadding="20px" style="margin-left:130px;">
                        <tr>
                            <td> <label for="info"> Tell Us About Yourself : </label> </td>
                            <td> <textarea class="form-control" id="info" name="info" rows="4" cols="5" required></textarea>
                            </td>
                        </tr>

                    </table>

                    <hr style="border-top: 1px solid black;">
                    <h3 style="text-decoration:underline;margin-left:20px;"> Post You are Interested to Work As </h3>

                    <table cellspacing="20px" cellpadding="20px" style="margin-left:130px;">
                        <tr>
                            <td>
                                <font color="red" size="4px"> * </font>
                            </td>
                            <td> <select class="form-control" id="post1" name="post1" required>
                                    <option>-- Select --</option>
                                    <option> Full Stack Developer </option>
                                </select> </td>
                        </tr>

                    </table>

                    <br>
                    <button type="submit" class="btn btn-success" name="base-save" style="margin-left:300px;"> Save </button>
                    <br><br><br>
                </form>

            </div>

            <script>
                $('.other-info-btn').click(function() {
                    $('.other-info-content').show();
                    $('.edu-info-content').hide();
                    $('.basic-info-content').hide();
                    $('.expr-info-content').hide();
                    $('.other-info-btn').css({
                        'border': '3px solid #4d86e8',
                    });
                    $('.edu-info-btn').css({
                        'border': 'none',
                    });
                    $('.basic-info-btn').css({
                        'border': 'none',
                    });
                    $('.expr-info-btn').css({
                        'border': 'none',
                    });
                });
            </script>

            <div class="expr-info-content">
                <form method="post">

                    <table cellspacing="20px" cellpadding="20px" style="margin-left:130px;">
                        <tr>
                            <td colspan="2" align="center" style="background-color:#52afde;color:#f2f5f4;"> <b> <big> <big> Fill or Update Experience Details Here. !! </big></big> </b> </td>
                        </tr>

                        <tr>
                            <td> <label for="email"> Email : </label>
                                <font color="red" size="4px"> * </font>
                            </td>
                            <td> <input type="email" class="form-control" id="email" name="email" readonly value="<?php echo $_SESSION['email']; ?>"> </td>
                        </tr>

                        <tr>
                            <td> <label for="did"> Did you have any Working Experience ? </label>
                                <font color="red" size="4px"> * </font>
                            </td>
                            <td> <select class="form-control" id="did" name="did" required>
                                    <option value=""> -- Select -- </option>
                                    <option value="yes"> Yes </option>
                                    <option value="no"> No </option>
                                </select>
                            </td>
                        </tr>
                    </table>
                    <script>
                        $('#did').on('change', function(event) {
                            var i = $('#did').val();
                            if (i == "yes") {
                                $('.expr').css({
                                    'display': 'block'
                                });
                            } else {
                                $('.expr').css({
                                    'display': 'none'
                                });
                            }
                        });
                    </script>

                    <table cellspacing="20px" class="expr" cellpadding="20px" style="margin-left:130px;display:none;">
                        <tr>
                            <td> <label for="exp-com"> Company : </label>
                                <font color="red" size="4px"> * </font>
                            </td>
                            <td> <input type="text" id="exp-com" name="exp-com" class="form-control" required> </td>
                        </tr>

                        <tr>
                            <td> <label for="exp-post"> Post : </label>
                                <font color="red" size="4px"> * </font>
                            </td>
                            <td> <input type="text" id="exp-post" name="exp-post" class="form-control" required> </td>
                        </tr>

                        <tr>
                            <td> <label for="exp-dur"> Duration : </label>
                                <font color="red" size="4px"> * </font>
                            </td>
                            <td> <input type="text" id="exp-dur" name="exp-dur" class="form-control" required> </td>
                        </tr>

                    </table>

                    <br>
                    <button type="submit" class="btn btn-success" name="base-save" style="margin-left:300px;"> Save </button>
                    <br><br><br>
                </form>
            </div>

            <script>
                $('.expr-info-btn').click(function() {
                    $('.expr-info-content').show();
                    $('.basic-info-content').hide();
                    $('.edu-info-content').hide();
                    $('.other-info-content').hide();
                    $('.expr-info-btn').css({
                        'border': '3px solid #4d86e8',
                    });
                    $('.edu-info-btn').css({
                        'border': 'none',
                    });
                    $('.other-info-btn').css({
                        'border': 'none',
                    });
                    $('.basic-info-btn').css({
                        'border': 'none',
                    });
                });
            </script>

        </div>
        <br>

        <?php
        include 'footer.php';
        ?>
    </div>
</body>

</html>