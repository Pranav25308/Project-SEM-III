<?php include 'connection.php'; ?>
<!DOCTYPE html>
<html>

<head>
    <meta charset="UTF-8">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>
    <link href="style-recruiter-job.css" rel="stylesheet">
    <link rel="icon" href="images/logo.png" type="image/icon type">
    <title> Job Applications </title>
    <style>
        .job {
            border: 0px solid black;
            border-radius: 25px;
            width: 70%;
            margin-left: 200px;
            padding: 25px;
            box-shadow: 10px 10px 15px 5px #b9bcbd;
        }

        .job_title {
            color: #0a6cff;
            font-size: 28px;
            font-weight: bold;
            font-family: Verdana, Geneva, Tahoma, sans-serif;
            text-decoration: underline;
        }

        .com {
            font-size: 15px;
            font-family: Verdana, Geneva, Tahoma, sans-serif;
        }

        .j_d,
        .e_c {
            font-size: 15px;
            font-family: Verdana, Geneva, Tahoma, sans-serif;
            font-weight: bold;
        }

        .j_d2,
        .e_c2 {
            font-size: 14px;
            font-family: Verdana, Geneva, Tahoma, sans-serif;
        }

        .btn {
            width: 200px;
            height: 45px;
            margin-left: 400px;
        }
    </style>
</head>

<body>
    <div class="container-fluid">

        <?php
        include 'header.php';
        $u = $_SESSION['email'];
        ?>

        <div class="jumbotron">
            <h1 align="center"> Job Applications </h1>
            <p align="center"> From Job Seekers. </p>
        </div>

        <?php

        $records = "select * from company_signup where Com_Email ='$u'";

        $sql = mysqli_query($con, $records);
        while ($data = mysqli_fetch_array($sql)) {
            $m1 = $data['Com_Name'];

            $records1 = "select * from applications where com_name ='$m1'";

            $sql1 = mysqli_query($con, $records1);
            while ($data1 = mysqli_fetch_array($sql1)) {
                $n1 = $data1['seeker_email'];
                $n2 = $data1['job_title'];
                $n3 = $data1['location'];


                $records2 = "select * from student_signup where Email ='$n1'";

                $sql2 = mysqli_query($con, $records2);
                while ($data2 = mysqli_fetch_array($sql2)) {
                    $r1 = $data2['Name'];
                    $r2 = $data2['Contact'];

        ?>

                    <div class="job">
                        <?php
                        echo '<h3 class="job_title" name="jobtitle"> <a href="seeker_details.php?compna=' . urlencode($n1) . '">' . $r1 . '</a></h3>';
                        ?>

                        <br>
                        <h5 class="com"> Email : <?php echo "$n1"; ?> </h5>
                        <h5 class="com"> Contact : <?php echo "$r2"; ?> </h5>
                        <h5 class="com"> Title : <?php echo "$n2"; ?> </h5>
                        <h5 class="com"> Location : <?php echo "$n3"; ?> </h5>
                        <br>
                    </div>

        <?php
                }
            }
        }
        ?>


        <?php
        include 'footer.php';
        ?>
    </div>
</body>

</html>