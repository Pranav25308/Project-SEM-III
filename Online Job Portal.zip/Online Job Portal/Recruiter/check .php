<?php
include 'connection.php';


$u = $_SESSION['email'];

$records = "select * from applicant_profile where Email ='$u'"; 
$sql = mysqli_query($con,$records);

if (mysqli_num_rows($sql) > 0)
{
    echo "<script> window.location='Applicant/profile.php'</script>  ";
}
else
{
    echo "<script> window.location='Applicant/complete-profile.php'</script>  ";
}
