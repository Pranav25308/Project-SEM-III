<div class="header">
    <br>
    <nav class="navbar">
        <div>
            <ul class="nav navbar-nav" style="margin-left:150px;font-family:Verdana;">
                <li> <a href="recruiter-profile.php" class="navi"> Profile </a> </li>
                <li> <a href="post-a-job.php" class="navi"> Post a job </a> </li>
                <li> <a href="posted-job.php" class="navi"> Posted Jobs </a> </li>
                <li> <a href="recruiter-applications.php" class="navi"> Applications </a> </li>
                <li> <a href="recruiter-contact.php" class="navi"> Contact Us </a> </li>
                <li> <a href="logout.php" class="navi"> Logout <i class="glyphicon glyphicon-log-out"></i> </a> </li>
            </ul>
        </div>
    </nav>

    <br><br><br><br><br>
</div>