<?php include 'connection.php'; ?>
<!DOCTYPE html>
<html>

<head>
    <meta charset="UTF-8">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>
    <link href="style-recruiter-job.css" rel="stylesheet">
    <link rel="icon" href="images/logo.png" type="image/icon type">
    <title> Post a Job </title>
    <style>

    </style>
</head>

<body>
    <div class="container-fluid">

        <?php
        include 'header.php';

        $u = $_SESSION['email'];

        $records = "select * from company_signup where Com_Email ='$u'";
        $sql = mysqli_query($con, $records);


        while ($data = mysqli_fetch_array($sql)) {
            $n1 = $data['Com_Name'];
        }
        ?>


        <div class="jumbotron">
            <h1 align="center">Post New Job Here !</h1>
        </div>
        <br>

        <form method="POST">
            <table align="center" cellspacing="10px" cellpadding="10px">

                <tr>
                    <td> <label for="name"> Email. </label>
                        <font color="red" size="4px"> * </font>
                    </td>
                    <td> <input type="text" id="name" class="form-control" name="email" value="<?php echo $_SESSION['email']; ?>" readonly> </td>
                </tr>

                <tr>
                    <td> <label for="name"> Company Name. </label>
                        <font color="red" size="4px"> * </font>
                    </td>
                    <td> <input type="text" id="name" class="form-control" name="cname" value="<?php echo "$n1"; ?>" readonly> </td>
                </tr>

                <tr>
                    <td> <label for="name"> Company Website. </label>
                        <font color="red" size="4px"> * </font>
                    </td>
                    <td> <input type="text" id="name" class="form-control" name="cwebsite" placeholder="Paste Your Company Website." required> </td>
                </tr>

                <tr>
                    <td> <label for="job_title"> Job Title. </label>
                        <font color="red" size="4px"> * </font>
                    </td>
                    <td> <select class="form-control" name="job_title">
                            <option> -- Select -- </option>
                            <?php

                            $records = "select * from post";
                            $sql = mysqli_query($con, $records);


                            while ($data = mysqli_fetch_array($sql)) {
                                $r1 = $data['jobposts'];

                            ?>

                                <option value="<?php echo "$r1"; ?>"> <?php echo "$r1"; ?></option>
                            <?php
                            }

                            ?>
                        </select> </td>
                </tr>

                <tr>
                    <td> <label for="name"> Job Description. </label>
                        <font color="red" size="4px"> * </font>
                    </td>
                    <td> <textarea rows="5" cols="30" name="job_desc"> </textarea> </td>
                </tr>

                <tr>
                    <td> <label for="name"> Eigibility Criteria. </label>
                        <font color="red" size="4px"> * </font>
                    </td>
                    <td> <textarea rows="5" cols="30" name="job_eli"> </textarea> </td>
                </tr>

                <tr>
                    <td> <label for="type"> Job Type. </label>
                        <font color="red" size="2px"> * </font>
                    </td>
                    <td> <select class="form-control" name="job_type" id="type" required>
                            <option> --Select--</option>
                            <option> Part Time </option>
                            <option> Full Time </option>
                        </select>
                    </td>
                </tr>

                <tr>
                    <td> <label for="email">End Date. </label>
                        <font color="red" size="4px"> * </font>
                    </td>
                    <td> <input type="date" id="email" name="end_date" class="form-control" required> </td>
                </tr>

                <tr>
                    <td> <label for="pass">Location. </label>
                        <font color="red" size="4px"> * </font>
                    </td>
                    <td> <input type="text" id="pass" name="loc" class="form-control" placeholder="Enter Job Location." required> </td>
                </tr>

            </table> <br> <br> <br> <br>
            <button type="submit" id="submit" name="post" class="btn btn-primary"> Post </button>
        </form>

        <br><br>

        <br>

        <br>

        <?php
        include 'footer.php';
        ?>
    </div>
</body>

</html>

<?php

//error_reporting(0); 

if (isset($_POST['post'])) {
    $n1 = $_POST["email"];
    $n2 = $_POST["cname"];
    $n3 = $_POST["cwebsite"];
    $n4 = $_POST["job_title"];
    $n5 = $_POST["job_desc"];
    $n6 = $_POST["job_eli"];
    $n7 = $_POST["job_type"];
    $n8 = $_POST["end_date"];
    $n9 = $_POST["loc"];

    $q = "insert into jobs values('$n1','$n2','$n3','$n4','$n5','$n6','$n7','$n8','$n9')";

    if ($con->query($q)) {

        echo "<script> alert ('Job Posted Successfully ! ') </script>  ";
    } else {
        echo "ERROR";
    }
}

?>