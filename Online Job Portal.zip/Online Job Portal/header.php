<div class="header">
                <br>
                <nav class="navbar">
                    <div>
                        <ul class="nav navbar-nav" style="margin-left:150px;font-family:Verdana;">
                        <li> <a href="index.php" style="margin-left: -120px;margin-top:-15px;"> <img src="images/logo2.png" height="65px" width="65px" style="border-radius:45px;">  </a> </li>    
                        <li> <a href="index.php" class="navi"> Home </a> </li>
                            <li> <a href="jobs.php" class="navi"> Jobs </a> </li>
                            <li> <a href="companies.php" class="navi"> Companies </a> </li>               
                            <li> <a href="contact.php" class="navi"> Contact Us </a> </li>
                            <li> <button id="login" onclick="window.location.href='login.php';"> Log In | <i class="glyphicon glyphicon-log-in"></i> </button> </li>
                            <li> <button id="signup" onclick="window.location.href='signup.php';"> Sign Up | <i class="glyphicon glyphicon-hand-right"></i> </button> </li>
                        </ul>   
                    </div>
                </nav>

                <br><br><br><br><br><br><br><br><br><br><br><br><br><br>
                
                <br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br>
            </div>