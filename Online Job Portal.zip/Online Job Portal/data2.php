<!DOCTYPE html>
<html>
    <head>
    <script src="https://smtpjs.com/v3/smtp.js"></script>  
    <meta charset="UTF-8">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>
    <link href="style-signup.css" rel="stylesheet">
    <!-- <link rel="icon" href="images/Tlogo.png" type="image/icon type"> -->
    <title> Sign Up </title>
    <style> 

    </style>

                    
    </head>
    <body>
        <div class="container-fluid">

            <?php 
             include 'header2.php';
            ?>
            
           

            <br><br>
            <div class="iam">
                <label for="iam"> </label>
                <select id="iam" name="iam" class="form-control">
                    <option value=""> -- select -- </option>
                    <option value="user"> Job Seeker </option>
                    <option value="company"> Company </option>
                </select><br><br>
                <font>Already Registered ? <a href="login.php"> Login Here ! </a></font>
            </div> <br>
            <br><br>
                            <script> 
                            $('#iam').on('change' , function(event){
                                var i = $('#iam').val();
                                if(i=="user")
                                {
                                    $('.Seeker').css({
                                        'display':'block'
                                    });
                                    $('.Company').css({
                                        'display':'none'
                                    });
                                }
                                else if(i=="company")
                                {
                                    $('.Company').css({
                                        'display':'block'
                                    });
                                    $('.Seeker').css({
                                        'display':'none'
                                    });
                                }
                                else {
                                    $('.Seeker').css({
                                        'display':'none'
                                    });
                                    $('.Company').css({
                                        'display':'none'
                                    });
                                }
                            });

                            </script>


            <div class="Seeker" style="display:none;">
            <br>
                <!-- <form  method="post" name="f1"> 
                <table align="center" cellspacing="10px" cellpadding="10px">

                    <tr> 
                    <td> <label for="aname"> Name. </label><font color="red" size="4px"> * </font> </td>
                    <td> <input type="text" id="aname" class="form-control" name="name" placeholder="Enter Your Full Name." pattern="[a-zA-Z ]+" title="Please use alphabets only." required>  </td>
                    </tr>

                    <tr> 
                        <td> <label for="acon"> Contact No. </label> <font color="red" size="2px"> * </font> </td>
                        <td> <input type="text" id="acon" class="form-control" placeholder="Enter Your Contact Number." name="pcon" pattern="(7|8|9)\d{9}" title="Please Enter 10 Digit Contact Number.It Must Be Start With 7 or 8 or 9 ." required> </td>
                    </tr>

                    <tr> 
                    <td> <label for="aemail">Email. </label><font color="red" size="4px"> * </font> </td>
                    <td> <input type="email" id="aemail" class="form-control" placeholder="Enter your Email." name="email" required>  </td>
                    </tr>

                    <tr> 
                    <td> <label for="apass">Password.  </label><font color="red" size="4px"> * </font> </td>
                    <td> <input type="password" id="apass" class="form-control" placeholder="Enter a password." name="pass" pattern="(?=.*\d)(?=.*[a-z])(?=.*[A-Z]).{8,}" title="Must contain at least one number and one uppercase and lowercase letter, and at least 8 or more characters" required>  </td>
                    </tr>

                </table> <br> 
                <button type="submit" name="Seeke_btn" onclick="mail()" id="signup1"> Sign Up </button>
                </form>
                <script>
                      function mail(){
                        var x = f1.name.value
                        var y = f1.email.value
                        var z = f1.pass.value
                        alert(x)
                        alert(y)
                        alert(z)
                            Email.send({
                                SecureToken:"fbf31702-bb7f-4a4e-9c1c-4ccf17ee777f",
                                To: y,
                                From: "pranavydv79@gmail.com",
                                Subject: "About Registration Process.",
                                Body: ` <h3> Hello , <h3> <font color="green"> <h1> ${x} </font> </h1> <h3> ${y} Congratulations for registering yourself on our platform. Please continue the ${z} process by logging in and complete your profile. Your Login Email is and Login Password is  . </h3> <h4> <a href="http://localhost/Online%20Job%20Portal/login.php"> Click Here to Login </a> </h4>.`
                            }).then(
                                message =>{
                                    //console.log (message);
                                    if(message=='OK'){
                                    alert('m');
                                    }
                                    else{
                                        console.error(message);
                                        alert('Error')   
                                    }
                                }
                            );
                        }
            </script> -->

            <form  method="post" name="f1"> 
                <table align="center" cellspacing="10px" cellpadding="10px">

                    <tr> 
                    <td> <label for="aname"> Name. </label><font color="red" size="4px"> * </font> </td>
                    <td> <input type="text" id="aname" class="form-control" name="name" placeholder="Enter Your Full Name." pattern="[a-zA-Z ]+" title="Please use alphabets only.">  </td>
                    </tr>

                    <tr> 
                        <td> <label for="acon"> Contact No. </label> <font color="red" size="2px"> * </font> </td>
                        <td> <input type="text" id="acon" class="form-control" placeholder="Enter Your Contact Number." name="pcon" pattern="(7|8|9)\d{9}" title="Please Enter 10 Digit Contact Number.It Must Be Start With 7 or 8 or 9 ."> </td>
                    </tr>

                    <tr> 
                    <td> <label for="aemail">Email. </label><font color="red" size="4px"> * </font> </td>
                    <td> <input type="email" id="aemail" class="form-control" placeholder="Enter your Email." name="email">  </td>
                    </tr>

                    <tr> 
                    <td> <label for="apass">Password.  </label><font color="red" size="4px"> * </font> </td>
                    <td> <input type="password" id="apass" class="form-control" placeholder="Enter a password." name="pass" pattern="(?=.*\d)(?=.*[a-z])(?=.*[A-Z]).{8,}" title="Must contain at least one number and one uppercase and lowercase letter, and at least 8 or more characters" required>  </td>
                    </tr>

                </table> <br> 
                <button type="submit" name="Seeker_btn" onclick="mail()" id="signup1"> Sign Up </button>
                </form>
                <script>
                      function mail(){
                        var x = f1.name.value
                        var y = f1.email.value
                            Email.send({
                                SecureToken:"fbf31702-bb7f-4a4e-9c1c-4ccf17ee777f",
                                To: y,
                                From: "pranavydv79@gmail.com",
                                Subject: "About Registration Process.2",
                                Body: ` <h3> Hello , <h3> <font color="green"> <h1> ${x} </font> </h1> <h3>  Congratulations for registering yourself on our platform. Please continue the process by logging in and complete your profile. Thank You. </h3> <h4> <a href="#"> Click Here to Login </a> </h4>.`
                            }).then(
                                message =>{
                                    //console.log (message);
                                    if(message=='OK'){
                                    alert('m');
                                    }
                                    else{
                                        console.error(message);
                                        alert('m')   
                                    }
                                }
                            );
                        }
            </script>
                          <br>
            </div>


            <div class="Company" style="display:none;">
                <br>
                <!-- <form method="post" name="f2">  
                <table align="center" cellspacing="10px" cellpadding="10px">

                    <tr> 
                    <td> <label for="name"> Company Name. </label><font color="red" size="4px"> * </font> </td>
                    <td> <input type="text" id="name" class="form-control" name="cname" placeholder="Enter Your Full Name." pattern="[a-zA-Z ]+" title="Please use alphabets only." required>  </td>
                    </tr>

                    <tr> 
                        <td> <label for="pcon"> Comany Contact No. </label> <font color="red" size="2px"> * </font> </td>
                        <td> <input type="text" id="pcon" class="form-control" placeholder="Enter Mobile Number." name="ccon" pattern="(7|8|9)\d{9}" title="Please Enter 10 Digit Contact Number.It Must Be Start With 7 or 8 or 9 ." required> </td>
                    </tr>

                    <tr> 
                    <td> <label for="email">Email. </label><font color="red" size="4px"> * </font> </td>
                    <td> <input type="email" id="email" class="form-control" placeholder="Enter your Email." name="cemail" required>  </td>
                    </tr>

                    <tr> 
                    <td> <label for="pass">Password.  </label><font color="red" size="4px"> * </font> </td>
                    <td> <input type="password" id="pass" class="form-control" placeholder="Enter a password." name="cpass" pattern="(?=.*\d)(?=.*[a-z])(?=.*[A-Z]).{8,}" title="Must contain at least one number and one uppercase and lowercase letter, and at least 8 or more characters" required>  </td>
                    </tr>

                </table> <br> 
                <button type="submit" id="signup2" onclick="mail0()" name="company_btn"> Sign Up </button>
                </form>

                <script>
                      function mail0(){
                        var x = f2.cname.value
                        var y = f2.cemail.value
                            Email.send({
                                SecureToken:"fbf31702-bb7f-4a4e-9c1c-4ccf17ee777f",
                                To: y,
                                From: "pranavydv79@gmail.com",
                                Subject: "About Registration Process.",
                                Body: ` <h3> Hello , <h3> <font color="green"> <h1> ${x} </font> </h1> <h3>  Congratulations for registering yourself on our platform. Please continue the process by logging in and complete your profile. Thank You. </h3> <h4> <a href="http://localhost/Online%20Job%20Portal/login.php"> Click Here to Login </a> </h4>.`
                            }).then(
                                message =>{
                                    //console.log (message);
                                    if(message=='OK'){
                                    alert('m');
                                    }
                                    else{
                                        console.error(message);
                                        alert('m')   
                                    }
                                }
                            );
                        }
            </script>
                          <br>
            </div>

            <br><br><br><br><br><br><br>
            <!-- <form method="post" name="f3">
            <table align="center" cellspacing="10px" cellpadding="10px">

            <tr> 
            <td> <label for="aname"> Name. </label><font color="red" size="4px"> * </font> </td>
            <td> <input type="text" id="aname" class="form-control" name="mname" placeholder="Enter Your Full Name." pattern="[a-zA-Z ]+" title="Please use alphabets only.">  </td>
            </tr>

            <tr> 
            <td> <label for="aemail">Email. </label><font color="red" size="4px"> * </font> </td>
            <td> <input type="email" id="aemail" class="form-control" placeholder="Enter your Email." name="memail">  </td>
            </tr>

            <tr> 
            <td> <label for="apass">Password.  </label><font color="red" size="4px"> * </font> </td>
            <td> <input type="password" id="apass" class="form-control" placeholder="Enter a password." name="mpass" pattern="(?=.*\d)(?=.*[a-z])(?=.*[A-Z]).{8,}" title="Must contain at least one number and one uppercase and lowercase letter, and at least 8 or more characters">  </td>
            </tr>

            </table>
            <button type="submit" onclick="mail1()" id="signup1"> Send Mail </button> 
            </form>

             <button type="submit" onclick="mail3()" id="signup1"> Send Mail </button> 
                <script>
                      function mail1(){
                        var x = f3.mname.value
                        var y = f3.memail.value
                        var z = f3.mpass.value
                            Email.send({
                                SecureToken:"fbf31702-bb7f-4a4e-9c1c-4ccf17ee777f",
                                To: "pranavyadav700@gmail.com",
                                From: "pranavydv79@gmail.com",
                                Subject: "About Registration Process.",
                                Body: ` <h3> Hello , <h3> <font color="green"> <h1> ${x} </font> </h1> <h3>  Congratulations for registering yourself on our platform. Please continue the process by logging in and complete your profile. Thank You. Email: ${y} and Password: ${z} </h3> <h4> <a href="#"> Click Here to Login </a> </h4>.`
                            }).then(
                                message =>{
                                    //console.log (message);
                                    if(message=='OK'){
                                    alert('m');
                                    }
                                    else{
                                        console.error(message);
                                        alert('Error')   
                                    }
                                }
                            );
                        }
            </script> -->

            <?php  
             include 'footer.php';
            ?>
        </div>
    </body>
</html>


<?php

error_reporting(0); 

/*if(isset($_POST['Seeker_btn']))
{
    $n1=$_POST["name"];
    $n2=$_POST["pcon"];
    $n3=$_POST["email"];
    $n4=$_POST["pass"];

    $cn=mysql_connect("localhost","root");
    $db=mysql_select_db("job",$cn);

    $sql = "select * from student_signup where Email='$n3' OR Contact='$n2'";
    $result = mysql_query($sql);
    if (mysql_num_rows($result) > 0)
    {
        echo "<script> alert('This Email or Contact is already registered , Try to Login with Same or Use Another Email or Contact to Register.') </script>";
    }
    else
    {
        $q="insert into student_signup values('$n1','$n2','$n3','$n4')";

        echo "<script> alert ('Your have Registered Successfully.You Can Login to Your Account Using Registred Email and Password to complete the profile. ') </script>  ";
        echo "<script> window.location='login.php'</script>  ";

        mysql_query($q);
        mysql_query($cn);
    }
}


if(isset($_POST['company_btn']))
{
    $n5=$_POST["cname"];
    $n6=$_POST["ccon"];
    $n7=$_POST["cemail"];
    $n8=$_POST["cpass"];

    $cn=mysql_connect("localhost","root");
    $db=mysql_select_db("job",$cn);

    $sql0 = "select * from company_signup where Com_Email='$n7' OR Com_Contact='$n6'";
    $result0 = mysql_query($sql0);
    
    if (mysql_num_rows($result0) > 0)
    {
        echo "<script> alert('This Email or Contact is already registered , Try to Login with Same or Use Another Email or Contact to Register.') </script>";
    }
    else
    {
    $q="insert into company_signup values('$n5','$n6','$n7','$n8')";

    echo "<script> alert ('Your Registration Process is Completed.You Can Login to Your Account Using Registred Username and Password. ') </script>  ";
    echo "<script> window.location='login.php'</script>  ";

    mysql_query($q);
    mysql_query($cn);
    }
}

*/?>

