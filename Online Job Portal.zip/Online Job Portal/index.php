<!DOCTYPE html>
<html>
        <head>
        <meta charset="UTF-8">
        <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>
    <link href="style-index.css" rel="stylesheet">
    <link rel="icon" href="images/logo.png" type="image/icon type">
    <title> Home </title>
    <style> 
.heading 
{
    font-size: 25px;
    margin-right: 25px;
}
  
  .fa {
    font-size: 25px;
  }
  
  .checked {
    color: orange;
  }
  
  /* Three column layout */
  .side {
    float: left;
    width: 15%;
    margin-top:10px;
  }
  
  .middle {
    margin-top:10px;
    float: left;
    width: 70%;
  }
  
  /* Place text to the right */
  .right {
    text-align: right;
  }
  
  /* Clear floats after the columns */
  .row:after {
    content: "";
    display: table;
    clear: both;
  }
  
  /* The bar container */
  .bar-container {
    width: 100%;
    background-color: #f1f1f1;
    text-align: center;
    color: white;
  }
  
  .bar-5 {width: 60%; height: 18px; background-color: #04AA6D;}
  .bar-4 {width: 30%; height: 18px; background-color: #2196F3;}
  .bar-3 {width: 10%; height: 18px; background-color: #00bcd4;}
  .bar-2 {width: 4%; height: 18px; background-color: #ff9800;}
  .bar-1 {width: 15%; height: 18px; background-color: #f44336;}
  
  /* Responsive layout - make the columns stack on top of each other instead of next to each other */
  @media (max-width: 400px) {
    .side, .middle {
      width: 100%;
    }
    .right {
      display: none;
    }
  }

.user_rating
{
    font-family: Arial;
  margin: 0 auto; /* Center website */
  max-width: 800px; /* Max width */
  padding: 20px;
}
.card-wrapper {
  margin: 5% 0;
}

/* You can adjust the image size by increasing/decreasing the width, height */
.custom-circle-image {
  width: 20vw; /* note i used vw not px for better responsive */
  height: 20vw;
}
</style>
        </head>
    <body>
        <div class="container-fluid">

            <?php 
             include 'header.php';
            ?>

            
            <div class="jumbotron" align="center">
                <h1> Online Job Portal Welcomes you , </h1>
                <p>Hope this little guide will help you to be comfortable with our system , please be free to ask us , Thank You. 😊</p>    
            </div>
            <div class="steps">
                <table align="center">
                    <tr>
                        <td align="center"> <img src="Images/emloyee_path.jpg" class="img" width="90%"></td>
                        <td align="center"> <img src="Images/Recruiter_path.jpg" class="img" width="90%"></td>
                    </tr>
                </table>
            </div>
            <br><br><br><br><br><br>

            <div>
                <marquee direction="left" hspace=20px>
                    <img src="Images/mnc1.jpg" height="200px" width="200px"> 
                    <img src="Images/mnc2.png" height="200px" width="200px" style="margin-left:20px;-webkit-box-shadow:none;-moz-box-shadow:none;box-shadow:none;"> 
                    <img src="Images/mnc3.webp" height="200px" width="200px" style="margin-left:20px;-webkit-box-shadow:none;-moz-box-shadow:none;box-shadow:none;">
                    <img src="Images/mbc4.png" height="200px" width="200px" style="margin-left:20px;-webkit-box-shadow:none;-moz-box-shadow:none;box-shadow:none;">
                    <img src="Images/mnc5.png" height="200px" width="200px" style="margin-left:20px;-webkit-box-shadow:none;-moz-box-shadow:none;box-shadow:none;">
                    <img src="Images/mnc6.jpg" height="200px" width="200px" style="margin-left:20px;-webkit-box-shadow:none;-moz-box-shadow:none;box-shadow:none;">
                    <img src="Images/mnc7.jfif" height="200px" width="200px" style="margin-left:20px;-webkit-box-shadow:none;-moz-box-shadow:none;box-shadow:none;">
                    <img src="Images/mnc8.png" height="200px" width="200px" style="margin-left:20px;-webkit-box-shadow:none;-moz-box-shadow:none;box-shadow:none;">
                    <img src="Images/mnc9.png" height="200px" width="200px" style="margin-left:20px;-webkit-box-shadow:none;-moz-box-shadow:none;box-shadow:none;">
                    <img src="Images/mnc10.png" height="200px" width="200px" style="margin-left:20px;-webkit-box-shadow:none;-moz-box-shadow:none;box-shadow:none;">
                    <img src="Images/mnc11.png" height="200px" width="200px" style="margin-left:20px;-webkit-box-shadow:none;-moz-box-shadow:none;box-shadow:none;">
                    <img src="Images/mnc12.png" height="200px" width="200px" style="margin-left:20px;-webkit-box-shadow:none;-moz-box-shadow:none;box-shadow:none;">
                </marquee>  
            </div>


            <br><br>
            <div class="jumbotron" align="center">
                <h1> Some Reviews </h1>
                <p>By Old or Current users. Both Recruiter's and Seeker's Reviews are involved.</p>    
            </div>
            <br>


            <div class="user_rating">

                <span class="heading">User Rating</span>
                <span class="fa fa-star checked"></span>
                <span class="fa fa-star checked"></span>
                <span class="fa fa-star checked"></span>
                <span class="fa fa-star checked"></span>
                <span class="fa fa-star"></span>

                <p>4.1 average based on 100 reviews.</p>
                <hr style="border:3px solid #f1f1f1">

                <div class="row">
                    <div class="side">
                        <div> 5 Star </div>
                    </div>
                    <div class="middle">
                        <div class="bar-container">
                            <div class="bar-5"></div>
                        </div>
                    </div>
                    <div class="side right">
                        <div>38</div>
                    </div>
                    <div class="side">
                        <div>4 star</div>
                    </div>
                    <div class="middle">
                        <div class="bar-container">
                            <div class="bar-4"></div>     
                        </div>
                    </div>
                    <div class="side right">
                        <div>21</div>
                    </div>
                    <div class="side">
                        <div>3 star</div>
                    </div>
                    <div class="middle">
                        <div class="bar-container">
                            <div class="bar-3"></div>
                        </div>
                    </div>
                    <div class="side right">
                        <div>3</div>
                    </div>
                    <div class="side">
                        <div>2 star</div>
                    </div>
                    <div class="middle">
                        <div class="bar-container">             
                            <div class="bar-2"></div>
                        </div>
                    </div>
                    <div class="side right">
                        <div>18</div>
                    </div>
                    <div class="side">
                        <div>1 star</div>
                    </div>
                    <div class="middle">
                        <div class="bar-container">
                            <div class="bar-1"></div>
                        </div>
                    </div>
                    <div class="side right">
                        <div>20</div>
                    </div>
                </div>
            </div>
            </div>
                <br><br><br><br><br><br><br><br>
            <div class="review_card">
                <div class="row">
                    <div class="col-md-4" style="border:3px solid #4398e8;margin-left:300px;border-radius:40px;height:300px;width:400px;">
                        <img src="Images/user.png" height="150px" width="200px" class="rounded-circle" style="border-radius:50%;margin-top:-70px;margin-left:85px;">
                        <h2 align="center" style="font-weight:bold;"> Pranav Yadav </h2>
                        <br> <br> 
                        <p align="justify"> I have started to find a job as Full Stack Developer on June 2019.I have started to find a job as Full Stack Developer on June 2019. I have started to find a job as Full Stack Developer on June 2019.</p>
                    </div>
                    <div class="col-md-4" style="border:3px solid #1fff2e;margin-left:250px;border-radius:40px;height:300px;width:400px;">
                        <img src="Images/user2.png" height="150px" width="200px" class="rounded-circle" style="border-radius:50%;margin-top:-70px;margin-left:85px;">
                        <h2 align="center" style="font-weight:bold;"> Kajal Chalke </h2>
                        <br> <br> 
                        <p align="justify"> I have started to find a job as Full Stack Developer on June 2019.I have started to find a job as Full Stack Developer on June 2019. I have started to find a job as Full Stack Developer on June 2019.</p>
                    </div>
                </div>
                
                <br><br><br><br><br><br><br><br>
                
                <div class="row">
                    <div class="col-md-4" style="border:3px solid #dbe82a;margin-left:300px;border-radius:40px;height:300px;width:400px;">
                        <img src="Images/user3.png" height="150px" width="200px" class="rounded-circle" style="border-radius:50%;margin-top:-70px;margin-left:85px;">
                        <h2 align="center" style="font-weight:bold;"> Suyash Lohar </h2>
                        <br> <br> 
                        <p align="justify"> I have started to find a job as Full Stack Developer on June 2019.I have started to find a job as Full Stack Developer on June 2019. I have started to find a job as Full Stack Developer on June 2019.</p>
                    </div>
                    <div class="col-md-4" style="border:3px solid #f26363;margin-left:250px;border-radius:40px;height:300px;width:400px;">
                        <img src="Images/user4.png" height="150px" width="200px" class="rounded-circle" style="border-radius:50%;margin-top:-70px;margin-left:85px;">
                        <h2 align="center" style="font-weight:bold;"> Mitali Konde </h2>
                        <br> <br> 
                        <p align="justify"> I have started to find a job as Full Stack Developer on June 2019.I have started to find a job as Full Stack Developer on June 2019. I have started to find a job as Full Stack Developer on June 2019.</p>
                    </div>
                </div>

                <br><br><br><br><br><br><br><br>
                
                <div class="row">
                    <div class="col-md-4" style="border:3px solid #4ce0d4;margin-left:300px;border-radius:40px;height:300px;width:400px;">
                        <img src="Images/user5.png" height="150px" width="200px" class="rounded-circle" style="border-radius:50%;margin-top:-70px;margin-left:85px;">
                        <h2 align="center" style="font-weight:bold;"> Shubham Karve </h2>
                        <br> <br> 
                        <p align="justify"> I have started to find a job as Full Stack Developer on June 2019.I have started to find a job as Full Stack Developer on June 2019. I have started to find a job as Full Stack Developer on June 2019.</p>
                    </div>
                    <div class="col-md-4" style="border:3px solid #f2ae5a;margin-left:250px;border-radius:40px;height:300px;width:400px;">
                        <img src="Images/user6.png" height="150px" width="200px" class="rounded-circle" style="border-radius:50%;margin-top:-70px;margin-left:85px;">
                        <h2 align="center" style="font-weight:bold;"> Swarali Magare </h2>
                        <br> <br> 
                        <p align="justify"> I have started to find a job as Full Stack Developer on June 2019.I have started to find a job as Full Stack Developer on June 2019. I have started to find a job as Full Stack Developer on June 2019.</p>
                    </div>
                </div>

                <br><br><br><br><br><br><br><br>
                
                <div class="row">
                    <div class="col-md-4" style="border:3px solid #7562f0;margin-left:300px;border-radius:40px;height:300px;width:400px;">
                        <img src="Images/rc1.png" height="150px" width="200px" class="rounded-circle" style="border-radius:50%;margin-top:-70px;margin-left:85px;">
                        <h2 align="center" style="font-weight:bold;"> Capgemini </h2>
                        <br> <br> 
                        <p align="justify"> I have started to find a job as Full Stack Developer on June 2019.I have started to find a job as Full Stack Developer on June 2019. I have started to find a job as Full Stack Developer on June 2019.</p>
                    </div>
                    <div class="col-md-4" style="border:3px solid #b44df0;margin-left:250px;border-radius:40px;height:300px;width:400px;">
                        <img src="Images/rc2.png" height="150px" width="200px" class="img rounded-circle" style="border-radius:50%;margin-top:-70px;margin-left:85px;">
                        <h2 align="center" style="font-weight:bold;"> Cognizant Pvt. Ltd. </h2>
                        <br> <br> 
                        <p align="justify"> I have started to find a job as Full Stack Developer on June 2019.I have started to find a job as Full Stack Developer on June 2019. I have started to find a job as Full Stack Developer on June 2019.</p>
                    </div>
                </div>

                <br><br><br><br><br><br><br><br>
                
                <div class="row">
                    <div class="col-md-4" style="border:3px solid #f04db9;margin-left:300px;border-radius:40px;height:300px;width:400px;">
                        <img src="Images/rc3.png" height="150px" width="200px" class="rounded-circle" style="border-radius:50%;margin-top:-70px;margin-left:85px;">
                        <h2 align="center" style="font-weight:bold;"> Mindtree Pvt . Ltd. </h2>
                        <br> <br> 
                        <p align="justify"> I have started to find a job as Full Stack Developer on June 2019.I have started to find a job as Full Stack Developer on June 2019. I have started to find a job as Full Stack Developer on June 2019.</p>
                    </div>
                    <div class="col-md-4" style="border:3px solid #acf04d;margin-left:250px;border-radius:40px;height:300px;width:400px;">
                        <img src="Images/rc4.png" height="150px" width="200px" class="rounded-circle" style="border-radius:50%;margin-top:-70px;margin-left:85px;">
                        <h2 align="center" style="font-weight:bold;"> Birlasoft Pvt. Ltd. </h2>
                        <br> <br> 
                        <p align="justify"> I have started to find a job as Full Stack Developer on June 2019.I have started to find a job as Full Stack Developer on June 2019. I have started to find a job as Full Stack Developer on June 2019.</p>
                    </div>
                </div>

                <br><br><br><br><br><br><br><br>
                
                <div class="row">
                    <div class="col-md-4" style="border:3px solid #4398e8;margin-left:300px;border-radius:40px;height:300px;width:400px;">
                        <img src="Images/rc5.png" height="150px" width="200px" class="rounded-circle" style="border-radius:50%;margin-top:-70px;margin-left:85px;">
                        <h2 align="center" style="font-weight:bold;"> Cybage </h2>
                        <br> <br> 
                        <p align="justify"> I have started to find a job as Full Stack Developer on June 2019.I have started to find a job as Full Stack Developer on June 2019. I have started to find a job as Full Stack Developer on June 2019.</p>
                    </div>
                    <div class="col-md-4" style="border:3px solid #1fff2e;margin-left:250px;border-radius:40px;height:300px;width:400px;">
                        <img src="Images/rc6.jpg" height="150px" width="200px" class="rounded-circle" style="border-radius:50%;margin-top:-70px;margin-left:85px;">
                        <h2 align="center" style="font-weight:bold;"> Persistant Pvt. Ltd. </h2>
                        <br> <br> 
                        <p align="justify"> I have started to find a job as Full Stack Developer on June 2019.I have started to find a job as Full Stack Developer on June 2019. I have started to find a job as Full Stack Developer on June 2019.</p>
                    </div>
                </div>
            </div>
            <br>

            <?php  
             include 'footer.php';
            ?>
        </div>
    </body>
</html>