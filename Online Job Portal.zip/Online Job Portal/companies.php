<?php 
include 'connection.php';
?>
<!DOCTYPE html>

<html>
        <head>
        <meta charset="UTF-8">
        <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>
    <link href="style-company.css" rel="stylesheet">
    <link rel="icon" href="images/logo.png" type="image/icon type">
    <title> Companies </title>
    <style> 

    </style>
        </head>
    <body>
        <div class="container-fluid">

            <?php 
             include 'header.php';
            ?>

            <br><br><br><br><br><br>
            
            <div class="jumbotron" align="center">
                <h1> Some Companies  </h1>
                <p> which are currently posting jobs on our website are - </p>    
            </div>

            <br><br><br><br><br><br>
            <table class="table table-hover">
            <tr>
                <th> Company Name </th>
            </tr>

            <?php

        $sql="select * from company_signup";
        $result=mysqli_query($con,$sql);

        while ($data = mysqli_fetch_array($result))
        {
          $m1 = $data['Com_Name'];
        ?>

            <tr>
                <td> <?php echo "$m1"; ?> </td>
            </tr>
       
<?php
    }
        ?>
 </table>
            <!--
            <div>
                <marquee direction="left" hspace=20px>
                    <img src="Images/mnc1.jpg" height="200px" width="200px"> 
                    <img src="Images/mnc2.png" height="200px" width="200px" style="margin-left:20px;-webkit-box-shadow:none;-moz-box-shadow:none;box-shadow:none;"> 
                    <img src="Images/mnc3.webp" height="200px" width="200px" style="margin-left:20px;-webkit-box-shadow:none;-moz-box-shadow:none;box-shadow:none;">
                    <img src="Images/mbc4.png" height="200px" width="200px" style="margin-left:20px;-webkit-box-shadow:none;-moz-box-shadow:none;box-shadow:none;">
                    <img src="Images/mnc5.png" height="200px" width="200px" style="margin-left:20px;-webkit-box-shadow:none;-moz-box-shadow:none;box-shadow:none;">
                    <img src="Images/mnc6.jpg" height="200px" width="200px" style="margin-left:20px;-webkit-box-shadow:none;-moz-box-shadow:none;box-shadow:none;">
                    <img src="Images/mnc7.jfif" height="200px" width="200px" style="margin-left:20px;-webkit-box-shadow:none;-moz-box-shadow:none;box-shadow:none;">
                    <img src="Images/mnc8.png" height="200px" width="200px" style="margin-left:20px;-webkit-box-shadow:none;-moz-box-shadow:none;box-shadow:none;">
                    <img src="Images/mnc9.png" height="200px" width="200px" style="margin-left:20px;-webkit-box-shadow:none;-moz-box-shadow:none;box-shadow:none;">
                    <img src="Images/mnc10.png" height="200px" width="200px" style="margin-left:20px;-webkit-box-shadow:none;-moz-box-shadow:none;box-shadow:none;">
                    <img src="Images/mnc11.png" height="200px" width="200px" style="margin-left:20px;-webkit-box-shadow:none;-moz-box-shadow:none;box-shadow:none;">
                    <img src="Images/mnc12.png" height="200px" width="200px" style="margin-left:20px;-webkit-box-shadow:none;-moz-box-shadow:none;box-shadow:none;">
                </marquee>  
            </div>
    -->


            <br><br>
            
            <br>

            
            
                
            <br>

            <?php  
             include 'footer.php';
            ?>
                

            
           























        </div>
    </body>
</html>