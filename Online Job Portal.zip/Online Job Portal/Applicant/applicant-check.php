<?php
include 'connection.php';
session_start();

$u = $_SESSION['email'];

$records = "select * from applicant_profile where Email ='$u'"; 
$sql = mysqli_query($con,$records);

if (mysqli_num_rows($sql) > 0)
{
    echo "<script> window.location='applicant-profile.php'</script>  ";
}
else
{
    echo "<script> window.location='complete-profile.php'</script>  ";
}
