<?php
include 'connection.php';
?>
<!DOCTYPE html>
<html>

<head>
    <meta charset="UTF-8">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>
    <link href="style-applicant-complete.css" rel="stylesheet">
    <link rel="icon" href="images/logo.png" type="image/icon type">
    <title> Update Profile </title>
    <style>
   
    </style>
</head>

<body>
    <div class="container-fluid">

        <?php
        include 'header.php';
        ?>
        <?php
        $eml = $_SESSION['email'];
        ?>
        <?php
        $u = $_SESSION['email'];

        $records = "select * from applicant_profile where Email ='$u'";
        $sql = mysqli_query($con, $records);


        while ($data = mysqli_fetch_array($sql)) {
            $n = $data['Name'];
            $n2 = $data['Address'];
            $n3 = $data['Contact'];
            $n4 = $data['gender'];
            $n5 = $data['DOB'];
        }
        ?>

        <div class="jumbotron">
            <h2 align="center">You Can Update Your Details Here ! </h2>
        </div>
        <br><br>

        <button class="basic-info-btn"> Basic Information </button>
        <button class="edu-info-btn"> Educational Information </button>
        <button class="other-info-btn"> Other Information </button>
        <button class="expr-info-btn"> Experience </button>
        <div class="content"><br><br><br>
            <div class="basic-info-content">
                <form method="post" enctype="multipart/form-data" action="">

                    <table cellspacing="20px" cellpadding="20px" style="margin-left:130px;">
                        <!-- <tr>  
                            <td colspan="2" align="center" style="background-color:#52afde;color:#f2f5f4;"> <b> <big> <big> Fill or Update Your Basic Details Here. !!  </big></big> </b>  </td> 
                            </tr> -->
                        <tr>
                            <td> <label for="email"> Email : </label>
                                <font color="red" size="4px"> * </font>
                            </td>
                            <td> <input type="email" class="form-control" id="email" name="email" readonly value="<?php echo $_SESSION['email']; ?>"> </td>
                        </tr>
                        <tr><br>
                            <td><label for="name"> Full Name : </label>
                                <font color="red" size="4px"> * </font>
                            </td>
                            <td> <input type="text" id="name" class="form-control" name="name" value="<?php echo $n; ?>" required> </td>
                        </tr>

                        <tr>
                            <td> <label for="add"> Address : </label>
                                <font color="red" size="4px"> * </font>
                            </td>
                            <td> <textarea id="add" class="form-control" rows="4" cols="3" name="add"><?php echo $n2; ?></textarea></td>
                        </tr>

                        <tr>
                            <td> <label for="con"> Contact :</label>
                                <font color="red" size="2px"> * </font>
                            </td>
                            <td> <input type="text" class="form-control" id="con" name="con" value="<?php echo $n3; ?>" pattern="(7|8|9)\d{9}" title="Please Enter 10 Digit Contact Number.It Must Be Start With 7 or 8 or 9 ." required> </td>
                        </tr>

                        <tr>
                            <td> <label> Gender : </label>
                                <font color="red" size="4px"> * </font>
                            </td>
                            <td> <input type="radio" name="gender" value="male" required style="margin-left:20px;" <?= $n4 == "male" ? "checked" : "" ?>> Male
                                <input type="radio" name="gender" value="female" required style="margin-left:20px;" <?= $n4 == "female" ? "checked" : "" ?>> Female
                                <input type="radio" name="gender" value="other" required style="margin-left:20px;" <?= $n4 == "other" ? "checked" : "" ?>> Other
                            </td>
                        </tr>

                        <tr>
                            <td> <label for="dob"> DOB : </label>
                                <font color="red" size="4px"> * </font>
                            </td>
                            <td> <input type="date" class="form-control" id="dob" name="dob" required value="<?php echo $n5; ?>"> </td>
                        </tr>

                        <tr>
                            <td> <label for="pro-img"> Image : </label>
                                <font color="red" size="4px"> * </font>
                            </td>
                            <td> <input type="file" class="form-control" id="pro" name="pro"> </td>
                        </tr>

                        <tr>
                            <td> <label for="cv"> CV / Resume : </label>
                                <font color="red" size="4px"> * </font>
                            </td>
                            <td> <input type="file" class="form-control" id="cv" name="cv"> </td>
                        </tr>



                    </table>
                    <br>
                    <button type="submit" class="btn btn-success" name="base-save" style="margin-left:300px;"> Update </button>
                    <br><br><br>
                </form>
            </div>
            <script>
                $('.basic-info-btn').click(function() {
                    $('.basic-info-content').show();
                    $('.edu-info-content').hide();
                    $('.other-info-content').hide();
                    $('.expr-info-content').hide();
                    $('.basic-info-btn').css({
                        'border': '3px solid #4d86e8',
                    });
                    $('.edu-info-btn').css({
                        'border': 'none',
                    });
                    $('.other-info-btn').css({
                        'border': 'none',
                    });
                    $('.expr-info-btn').css({
                        'border': 'none',
                    });
                });
            </script>


            <?php
            $u = $_SESSION['email'];

            $records = "select * from applicant_edu where Email ='$u'";
            $sql = mysqli_query($con, $records);


            while ($data = mysqli_fetch_array($sql)) {
                $m1 = $data['10_sch_nm'];
                $m2 = $data['10_sch_uni'];
                $m3 = $data['10_sch_from'];
                $m4 = $data['10_sch_to'];
                $m5 = $data['10_sch_grade'];

                $m6 = $data['12_sch_nm'];
                $m7 = $data['12_sch_fld'];
                $m8 = $data['12_sch_uni'];
                $m9 = $data['12_sch_from'];
                $m10 = $data['12_sch_to'];
                $m11 = $data['12_sch_grade'];

                $m12 = $data['gra_cou'];
                $m13 = $data['gra_sch_nm'];
                $m14 = $data['gra_sch_uni'];
                $m15 = $data['gra_sch_from'];
                $m16 = $data['gra_sch_to'];
                $m17 = $data['gra_sch_grade'];

                $m18 = $data['pg_cou'];
                $m19 = $data['pg_sch_nm'];
                $m20 = $data['pg_sch_uni'];
                $m21 = $data['pg_sch_from'];
                $m22 = $data['pg_sch_to'];
                $m23 = $data['pg_sch_grade'];
            }
            ?>

            <div class="edu-info-content">
                <form method="post">

                    <table cellspacing="20px" cellpadding="20px" style="margin-left:130px;">
                        <!-- <tr>  
                            <td colspan="2" align="center" style="background-color:#52afde;color:#f2f5f4;"> <b> <big> <big> Fill or Update Your Educational Details Here. !!  </big></big> </b>  </td> 
                            </tr> -->

                        <tr>
                            <td> <label for="email"> Email : </label>
                                <font color="red" size="4px"> * </font>
                            </td>
                            <td> <input type="email" class="form-control" id="email" name="email" readonly value="<?php echo $_SESSION['email']; ?>"> </td>
                        </tr>
                    </table>

                    <hr style="border-top: 1px solid black;"> <br>
                    <h3 style="text-decoration:underline;" align="center"> 10th (X) Details </h3>

                    <table cellspacing="20px" cellpadding="20px" style="margin-left:130px;">
                        <tr>
                            <td> <label for="10-sch-nm"> School Name : </label>
                                <font color="red" size="4px"> * </font>
                            </td>
                            <td> <input type="text" class="form-control" id="10-sch-nm" name="10-sch-nm" required value="<?php echo $m1; ?>"> </td>
                        </tr>

                        <tr>
                            <td> <label for="10-sch-uni"> University : </label>
                                <font color="red" size="4px"> * </font>
                            </td>
                            <td> <input type="text" class="form-control" id="10-sch-uni" name="10-sch-uni" required value="<?php echo $m2; ?>"> </td>
                        </tr>

                        <tr>
                            <td> <label for="10-sch-from"> From : </label>
                                <font color="red" size="4px"> * </font>
                            </td>
                            <td> <input type="date" class="form-control" id="10-sch-from" name="10-sch-from" required value="<?php echo $m3; ?>"> </td>
                        </tr>

                        <tr>
                            <td> <label for="10-sch-to"> To : </label>
                                <font color="red" size="4px"> * </font>
                            </td>
                            <td> <input type="date" class="form-control" id="10-sch-to" name="10-sch-to" required value="<?php echo $m4; ?>"> </td>
                        </tr>

                        <tr>
                            <td> <label for="10-sch-grade"> Percentage / CGPA : </label>
                                <font color="red" size="4px"> * </font>
                            </td>
                            <td> <input type="text" class="form-control" id="10-sch-grade" name="10-sch-grade" required value="<?php echo $m5; ?>"> </td>
                        </tr>



                    </table>

                    <hr style="border-top: 1px solid black;"> <br>
                    <h3 style="text-decoration:underline;" align="center"> 12th (XII) Details </h3>

                    <table cellspacing="20px" cellpadding="20px" style="margin-left:130px;">
                        <tr>
                            <td> <label for="12-sch-nm"> School / College Name : </label>
                                <font color="red" size="4px"> * </font>
                            </td>
                            <td> <input type="text" class="form-control" id="12-sch-nm" name="12-sch-nm" required value="<?php echo $m6; ?>"> </td>
                        </tr>

                        <tr>
                            <td> <label for="12-sch-fld"> Stream : </label>
                                <font color="red" size="4px"> * </font>
                            </td>
                            <td> <select id="12-sch-fld" name="12-sch-fld" required class="form-control">
                                    <option value="<?php echo $m7; ?>"> <?php echo $m7; ?> </option>
                                    <option> -- Select --</option>
                                    <option value="Science"> Science </option>
                                    <option value="Commerce"> Commerce </option>
                                    <option value="Arts"> Arts </option>
                                </select>
                            </td>
                        </tr>

                        <tr>
                            <td> <label for="12-sch-uni"> University : </label>
                                <font color="red" size="4px"> * </font>
                            </td>
                            <td> <input type="text" class="form-control" id="12-sch-uni" name="12-sch-uni" required value="<?php echo $m8; ?>"> </td>
                        </tr>

                        <tr>
                            <td> <label for="12-sch-from"> From : </label>
                                <font color="red" size="4px"> * </font>
                            </td>
                            <td> <input type="date" class="form-control" id="12-sch-from" name="12-sch-from" required value="<?php echo $m9; ?>"> </td>
                        </tr>

                        <tr>
                            <td> <label for="12-sch-to"> To : </label>
                                <font color="red" size="4px"> * </font>
                            </td>
                            <td> <input type="date" class="form-control" id="12-sch-to" name="12-sch-to" required value="<?php echo $m10; ?>"> </td>
                        </tr>

                        <tr>
                            <td> <label for="12-sch-grade"> Percentage / CGPA : </label>
                                <font color="red" size="4px"> * </font>
                            </td>
                            <td> <input type="text" class="form-control" id="12-sch-grade" name="12-sch-grade" required value="<?php echo $m11; ?>"> </td>
                        </tr>

                    </table>

                    <hr style="border-top: 1px solid black;"> <br>
                    <h3 style="text-decoration:underline;" align="center"> Graduation Details </h3>

                    <table cellspacing="20px" cellpadding="20px" style="margin-left:130px;">
                        <tr>
                            <td> <label for="gra-cou"> Course : </label>
                                <font color="red" size="4px"> * </font>
                            </td>
                            <td> <select class="form-control" id="gra-cou" name="gra-cou" required>
                                    <option value="<?php echo $m12; ?>"> <?php echo $m12; ?> </option>
                                    <option> -- Select -- </option>
                                    <option value="BE"> B.E </option>
                                    <option value="BTech"> B.Tech </option>
                                    <option value="BArch"> B.Arch </option>
                                    <option value="BCA"> BCA </option>
                                    <option value="BCS"> BCS </option>
                                    <option value="BSC"> BSC </option>
                                    <option value="BPharma"> BPharma </option>
                                    <option value="BCom"> B.COM </option>
                                    <option value="BBA"> BBA </option>
                                    <option value="BA"> BA </option>
                                </select> </td>
                        </tr>

                        <tr>
                            <td> <label for="gra-sch-nm"> College Name : </label>
                                <font color="red" size="4px"> * </font>
                            </td>
                            <td> <input type="text" class="form-control" id="gra-sch-nm" name="gra-sch-nm" required value="<?php echo $m13; ?>"> </td>
                        </tr>

                        <tr>
                            <td> <label for="gra-sch-uni"> University : </label>
                                <font color="red" size="4px"> * </font>
                            </td>
                            <td> <input type="text" class="form-control" id="gra-sch-uni" name="gra-sch-uni" required value="<?php echo $m14; ?>"> </td>
                        </tr>

                        <tr>
                            <td> <label for="gra-sch-from"> From : </label>
                                <font color="red" size="4px"> * </font>
                            </td>
                            <td> <input type="date" class="form-control" id="gra-sch-from" name="gra-sch-from" required value="<?php echo $m15; ?>"> </td>
                        </tr>

                        <tr>
                            <td> <label for="gra-sch-to"> To : </label>
                                <font color="red" size="4px"> * </font>
                            </td>
                            <td> <input type="date" class="form-control" id="gra-sch-to" name="gra-sch-to" required value="<?php echo $m16; ?>"> </td>
                        </tr>

                        <tr>
                            <td> <label for="gra-sch-grade"> Percentage / CGPA : </label>
                                <font color="red" size="4px"> * </font>
                            </td>
                            <td> <input type="text" class="form-control" id="gra-sch-grade" name="gra-sch-grade" required value="<?php echo $m17; ?>"> </td>
                        </tr>

                    </table>

                    <hr style="border-top: 1px solid black;"> <br>
                    <h3 style="text-decoration:underline;" align="center"> Post Graduation Details </h3>

                    <table cellspacing="20px" cellpadding="20px" style="margin-left:130px;">
                        <tr>
                            <td> <label for="pg-cou"> Course : </label>
                                <font color="red" size="4px"> * </font>
                            </td>
                            <td> <select class="form-control" id="pg-cou" name="pg-cou" required>
                                    <option value="<?php echo $m18; ?>"> <?php echo $m18; ?> </option>
                                    <option> -- Select -- </option>
                                    <option value="ME"> M.E </option>
                                    <option value="MTech"> M.Tech </option>
                                    <option value="MArch"> M.Arch </option>
                                    <option value="MCA"> MCA </option>
                                    <option value="MCS"> MCS </option>
                                    <option value="MSC"> MSC </option>
                                    <option value="MPharma"> MPharma </option>
                                    <option value="MCom"> M.COM </option>
                                    <option value="MBA"> MBA </option>
                                    <option value="MA"> MA </option>
                                </select> </td>
                        </tr>
                        <tr>
                            <td> <label for="pg-sch-nm"> College Name : </label> </td>
                            <td> <input type="text" class="form-control" id="pg-sch-nm" name="pg-sch-nm" value="<?php echo $m19; ?>"> </td>
                        </tr>

                        <tr>
                            <td> <label for="pg-sch-uni"> University : </label> </td>
                            <td> <input type="text" class="form-control" id="pg-sch-uni" name="pg-sch-uni" value="<?php echo $m20; ?>"> </td>
                        </tr>

                        <tr>
                            <td> <label for="pg-sch-from"> From : </label> </td>
                            <td> <input type="date" class="form-control" id="pg-sch-from" name="pg-sch-from" value="<?php echo $m21; ?>"> </td>
                        </tr>

                        <tr>
                            <td> <label for="pg-sch-to"> To : </label> </td>
                            <td> <input type="date" class="form-control" id="pg-sch-to" name="pg-sch-to" value="<?php echo $m22; ?>"> </td>
                        </tr>

                        <tr>
                            <td> <label for="pg-sch-grade"> Percentage / CGPA : </label> </td>
                            <td> <input type="text" class="form-control" id="pg-sch-grade" name="pg-sch-grade" value="<?php echo $m23; ?>"> </td>
                        </tr>

                    </table>
                    <br>
                    <button type="submit" class="btn btn-success" name="edu-save" style="margin-left:300px;"> Update </button>
                    <br><br><br>
                </form>
            </div>
            <script>
                $('.edu-info-btn').click(function() {
                    $('.edu-info-content').show();
                    $('.basic-info-content').hide();
                    $('.other-info-content').hide();
                    $('.expr-info-content').hide();
                    $('.edu-info-btn').css({
                        'border': '3px solid #4d86e8',
                    });
                    $('.basic-info-btn').css({
                        'border': 'none',
                    });
                    $('.other-info-btn').css({
                        'border': 'none',
                    });
                    $('.expr-info-btn').css({
                        'border': 'none',
                    });
                });
            </script>

            <?php
            $u = $_SESSION['email'];

            $records = "select * from applicant_other where Email ='$u'";
            $sql = mysqli_query($con, $records);


            while ($data = mysqli_fetch_array($sql)) {
                $r1 = $data['interest1'];
                $r2 = $data['interest2'];
                $r3 = $data['interest3'];

                $r4 = $data['course1'];
                $r5 = $data['inst_name1'];
                $r6 = $data['course1_fromm'];
                $r7 = $data['course1_too'];
                $r8 = $data['course1_per'];

                $r9 = $data['course2'];
                $r10 = $data['inst_name2'];
                $r11 = $data['course2_fromm'];
                $r12 = $data['course2_too'];
                $r13 = $data['course2_per'];

                $r14 = $data['course3'];
                $r15 = $data['inst_name3'];
                $r16 = $data['course3_fromm'];
                $r17 = $data['course3_too'];
                $r18 = $data['course3_per'];

                $r19 = $data['lang_t1'];
                $r20 = $data['lant_t1_lvl'];

                $r21 = $data['lang_t2'];
                $r22 = $data['lang_t2_lvl'];

                $r23 = $data['lang_t3'];
                $r24 = $data['lang_t3_lvl'];

                $r25 = $data['lang1'];
                $r26 = $data['lang1_lvl'];

                $r27 = $data['lang2'];
                $r28 = $data['lang2_lvl'];

                $r29 = $data['lang3'];
                $r30 = $data['lang3_lvl'];

                $r31 = $data['lang4'];
                $r32 = $data['lang4_lvl'];

                $r33 = $data['lang5'];
                $r34 = $data['lang5_lvl'];

                $r35 = $data['info'];
                $r36 = $data['post'];
            }
            ?>


            <div class="other-info-content">
                <form method="post">

                    <table cellspacing="20px" cellpadding="20px" style="margin-left:130px;">
                        <!-- <tr>  
                            <td colspan="2" align="center" style="background-color:#52afde;color:#f2f5f4;"> <b> <big> <big> Fill or Update Other Details Here. !!  </big></big> </b>  </td> 
                            </tr> -->
                        <tr>
                            <td> <label for="email"> Email : </label>
                                <font color="red" size="4px"> * </font>
                            </td>
                            <td> <input type="email" class="form-control" id="email" name="email" readonly value="<?php echo $_SESSION['email']; ?>"> </td>
                        </tr>
                    </table>

                    <hr style="border-top: 1px solid black;"> <br>
                    <h3 style="text-decoration:underline;" align="center"> Interests </h3>

                    <table cellspacing="20px" cellpadding="20px" style="margin-left:130px;" id="int">
                        <tr>
                            <td> <label for="interest1"> Interest 1 : </label>
                                <font color="red" size="4px"> * </font>
                            </td>
                            <td> <input type="text" class="form-control" id="interest1" name="interest1" required value="<?php echo $r1; ?>"> </td>
                        </tr>
                    </table>

                    <table cellspacing="20px" cellpadding="20px" style="margin-left:130px;">
                        <tr>
                            <td> <label for="interest2"> Interest 2 : </label>
                                <font color="red" size="4px"> * </font>
                            </td>
                            <td> <input type="text" class="form-control" id="interest2" name="interest2" value="<?php echo $r2; ?>"> </td>
                        </tr>
                    </table>

                    <table cellspacing="20px" cellpadding="20px" style="margin-left:130px;">
                        <tr>
                            <td> <label for="interest3"> Interest 3 : </label>
                                <font color="red" size="4px"> * </font>
                            </td>
                            <td> <input type="text" class="form-control" id="interest3" name="interest3" value="<?php echo $r3; ?>"> </td>
                        </tr>
                    </table>


                    <hr style="border-top: 1px solid black;"> <br>
                    <h3 style="text-decoration:underline;" align="center"> Certifications </h3>

                    <table cellspacing="20px" cellpadding="20px" style="margin-left:130px;">
                        <tr>
                            <td> <label for="course1"> Course 1: </label>
                                <font color="red" size="4px"> * </font>
                            </td>
                            <td> <input type="text" class="form-control" id="course1" name="course1" required value="<?php echo $r4; ?>"> </td>
                        </tr>

                        <tr>
                            <td> <label for="inst_nm1"> Institute Name : </label>
                                <font color="red" size="4px"> * </font>
                            </td>
                            <td> <input type="text" class="form-control" id="inst_nm1" name="inst_nm1" required value="<?php echo $r5; ?>"> </td>
                        </tr>

                        <tr>
                            <td> <label for="course1_from"> From : </label>
                                <font color="red" size="4px"> * </font>
                            </td>
                            <td> <input type="date" class="form-control" id="course1_from" name="course1_from" required value="<?php echo $r6; ?>"> </td>
                        </tr>

                        <tr>
                            <td> <label for="course1_to"> To : </label>
                                <font color="red" size="4px"> * </font>
                            </td>
                            <td> <input type="date" class="form-control" id="course1_to" name="course1_to" required value="<?php echo $r7; ?>"> </td>
                        </tr>

                        <tr>
                            <td> <label for="course1_per"> Percentage / CGPA: </label>
                                <font color="red" size="4px"> * </font>
                            </td>
                            <td> <input type="text" class="form-control" id="course1_per" name="course1_per" required value="<?php echo $r8; ?>"> </td>
                        </tr>
                    </table>

                    <table cellspacing="20px" cellpadding="20px" style="margin-left:130px;">
                        <tr>
                            <td> <label for="course2"> Course 2: </label>
                                <font color="red" size="4px"> * </font>
                            </td>
                            <td> <input type="text" class="form-control" id="course2" name="course2" value="<?php echo $r9; ?>"> </td>
                        </tr>

                        <tr>
                            <td> <label for="inst_nm2"> Institute Name : </label>
                                <font color="red" size="4px"> * </font>
                            </td>
                            <td> <input type="text" class="form-control" id="inst_nm2" name="inst_nm2" value="<?php echo $r10; ?>"> </td>
                        </tr>

                        <tr>
                            <td> <label for="course2_from"> From : </label>
                                <font color="red" size="4px"> * </font>
                            </td>
                            <td> <input type="date" class="form-control" id="course2_from" name="course2_from" value="<?php echo $r11; ?>"> </td>
                        </tr>

                        <tr>
                            <td> <label for="course2_to"> To : </label>
                                <font color="red" size="4px"> * </font>
                            </td>
                            <td> <input type="date" class="form-control" id="course2_to" name="course2_to" value="<?php echo $r12; ?>"> </td>
                        </tr>

                        <tr>
                            <td> <label for="course2_per"> Percentage / CGPA: </label>
                                <font color="red" size="4px"> * </font>
                            </td>
                            <td> <input type="text" class="form-control" id="course2_per" name="course2_per" value="<?php echo $r13; ?>"> </td>
                        </tr>
                    </table>
                    <table cellspacing="20px" cellpadding="20px" style="margin-left:130px;">
                        <tr>
                            <td> <label for="course3"> Course 3: </label>
                                <font color="red" size="4px"> * </font>
                            </td>
                            <td> <input type="text" class="form-control" id="course3" name="course3" value="<?php echo $r14; ?>"> </td>
                        </tr>

                        <tr>
                            <td> <label for="inst_nm3"> Institute Name : </label>
                                <font color="red" size="4px"> * </font>
                            </td>
                            <td> <input type="text" class="form-control" id="inst_nm3" name="inst_nm3" value="<?php echo $r15; ?>"> </td>
                        </tr>

                        <tr>
                            <td> <label for="course3_from"> From : </label>
                                <font color="red" size="4px"> * </font>
                            </td>
                            <td> <input type="date" class="form-control" id="course3_from" name="course3_from" value="<?php echo $r16; ?>"> </td>
                        </tr>

                        <tr>
                            <td> <label for="course3_to"> To : </label>
                                <font color="red" size="4px"> * </font>
                            </td>
                            <td> <input type="date" class="form-control" id="course3_to" name="course3_to" value="<?php echo $r17; ?>"> </td>
                        </tr>

                        <tr>
                            <td> <label for="course3_per"> Percentage / CGPA: </label>
                                <font color="red" size="4px"> * </font>
                            </td>
                            <td> <input type="text" class="form-control" id="course3_per" name="cp" value="<?php echo $r18; ?>"> </td>
                        </tr>
                    </table>

                    <hr style="border-top: 1px solid black;"> <br>
                    <h3 style="text-decoration:underline;" align="center"> Languages known </h3>

                    <table cellspacing="20px" cellpadding="20px" style="margin-left:130px;">
                        <tr>
                            <td> <label for="lang-t1"> Language 1 : </label>
                                <font color="red" size="4px"> * </font>
                            </td>
                            <td> <input type="text" class="form-control" id="lang-t1" name="lang-t1" required value="<?php echo $r19; ?>"> </td>
                        </tr>

                        <tr>
                            <td> </td>
                            <td> <select class="form-control" name="lang-t1_lvl" id="lang-t1_lvl" required>
                                    <option value="<?php echo $r20; ?>"> <?php echo $r20; ?> </option>
                                    <option> -- Select skill --</option>
                                    <option value="talk">Talk </option>
                                    <option value="write">Write</option>
                                    <option value="talk-and-write">Talk & Write</option>
                                </select>
                            </td>
                        </tr>
                    </table>
                    <table cellspacing="20px" cellpadding="20px" style="margin-left:130px;" id="lan-t2">
                        <tr>
                            <td> <label for="lang-t2"> Language 2 : </label>
                                <font color="red" size="4px"> * </font>
                            </td>
                            <td> <input type="text" class="form-control" id="lang-t2" name="lang-t2" value="<?php echo $r21; ?>"> </td>
                        </tr>

                        <tr>
                            <td> </td>
                            <td> <select class="form-control" name="lang-t2_lvl" id="lang-t2_lvl">
                                    <option value="<?php echo $r22; ?>"> <?php echo $r22; ?> </option>
                                    <option> -- Select skill --</option>
                                    <option value="talk">Talk </option>
                                    <option value="write">Write</option>
                                    <option value="talk-and-write">Talk & Write</option>
                                </select> </td>
                        </tr>
                    </table>
                    <table cellspacing="20px" cellpadding="20px" style="margin-left:130px;" id="lang-t3">
                        <tr>
                            <td> <label for="langg-t3"> Language 3 : </label>
                                <font color="red" size="4px"> * </font>
                            </td>
                            <td> <input type="text" class="form-control" id="langg-t3" name="lang-t3" value="<?php echo $r23; ?>"> </td>
                        </tr>

                        <tr>
                            <td> </td>
                            <td> <select class="form-control" name="langt3_lvl" id="lang3_lvl">
                                    <option value="<?php echo $r24; ?>"> <?php echo $r24; ?> </option>
                                    <option> -- Select skill --</option>
                                    <option value="talk">Talk </option>
                                    <option value="write">Write</option>
                                    <option value="talk-and-write">Talk & Write</option>
                                </select> </td>
                        </tr>
                    </table>

                    <hr style="border-top: 1px solid black;"> <br>
                    <h3 style="text-decoration:underline;" align="center"> Computer Languages known </h3>

                    <table cellspacing="20px" cellpadding="20px" style="margin-left:130px;">
                        <tr>
                            <td> <label for="lang1"> Language 1 : </label>
                                <font color="red" size="4px"> * </font>
                            </td>
                            <td> <input type="text" class="form-control" id="lang1" name="lang1" required value="<?php echo $r25; ?>"> </td>
                        </tr>

                        <tr>
                            <td> </td>
                            <td> <select class="form-control" name="lang1_lvl" id="lang1_lvl" required>
                                    <option value="<?php echo $r26; ?>"> <?php echo $r26; ?> </option>
                                    <option> -- Select Level --</option>
                                    <option value="beginner">Beginner</option>
                                    <option value="intermediate">Intermediate</option>
                                    <option value="expert">Expert</option>
                                </select>
                            </td>
                        </tr>
                    </table>
                    <table cellspacing="20px" cellpadding="20px" style="margin-left:130px;">
                        <tr>
                            <td> <label for="lang2"> Language 2 : </label>
                                <font color="red" size="4px"> * </font>
                            </td>
                            <td> <input type="text" class="form-control" id="lang2" name="lang2" value="<?php echo $r27; ?>"> </td>
                        </tr>

                        <tr>
                            <td> </td>
                            <td> <select class="form-control" name="lang2_lvl" id="lang2_lvl">
                                    <option value="<?php echo $r28; ?>"> <?php echo $r28; ?> </option>
                                    <option> -- Select Level --</option>
                                    <option value="beginner">Beginner</option>
                                    <option value="intermediate">Intermediate</option>
                                    <option value="expert">Expert</option>
                                </select> </td>
                        </tr>
                    </table>
                    <table cellspacing="20px" cellpadding="20px" style="margin-left:130px;">
                        <tr>
                            <td> <label for="lang3"> Language 3 : </label>
                                <font color="red" size="4px"> * </font>
                            </td>
                            <td> <input type="text" class="form-control" id="lang3" name="lang3" value="<?php echo $r29; ?>"> </td>
                        </tr>

                        <tr>
                            <td> </td>
                            <td> <select class="form-control" name="lang3_lvl" id="lang3_lvl">
                                    <option value="<?php echo $r30; ?>"> <?php echo $r30; ?> </option>
                                    <option> -- Select Level --</option>
                                    <option value="beginner">Beginner</option>
                                    <option value="intermediate">Intermediate</option>
                                    <option value="expert">Expert</option>
                                </select> </td>
                        </tr>
                    </table>
                    <table cellspacing="20px" cellpadding="20px" style="margin-left:130px;">
                        <tr>
                            <td> <label for="lang4"> Language 4 : </label>
                                <font color="red" size="4px"> * </font>
                            </td>
                            <td> <input type="text" class="form-control" id="lang4" name="lang4" value="<?php echo $r31; ?>"> </td>
                        </tr>

                        <tr>
                            <td> </td>
                            <td> <select class="form-control" name="lang4_lvl" id="lang4_lvl">
                                    <option value="<?php echo $r32; ?>"> <?php echo $r32; ?> </option>
                                    <option> -- Select Level --</option>
                                    <option value="beginner">Beginner</option>
                                    <option value="intermediate">Intermediate</option>
                                    <option value="expert">Expert</option>
                                </select> </td>
                        </tr>
                    </table>
                    <table cellspacing="20px" cellpadding="20px" style="margin-left:130px;">
                        <tr>
                            <td> <label for="lang5"> Language 5 : </label>
                                <font color="red" size="4px"> * </font>
                            </td>
                            <td> <input type="text" class="form-control" id="lang5" name="lang5" value="<?php echo $r33; ?>"> </td>
                        </tr>

                        <tr>
                            <td> </td>
                            <td> <select class="form-control" name="lang5_lvl" id="lang5_lvl">
                                    <option value="<?php echo $r34; ?>"> <?php echo $r34; ?> </option>
                                    <option> -- Select Level --</option>
                                    <option value="beginner">Beginner</option>
                                    <option value="intermediate">Intermediate</option>
                                    <option value="expert">Expert</option>
                                </select> </td>
                        </tr>
                    </table>




                    <hr style="border-top: 1px solid black;"> <br>
                    <h3 style="text-decoration:underline;" align="center"> Tell Us About Yourself </h3> <br> <br>
                    <textarea class="form-control" id="info" name="info" rows="4" cols="1" required style="margin-left: 220px;"><?php echo $r35; ?></textarea>

                    <hr style="border-top: 1px solid black;"> <br>
                    <h3 style="text-decoration:underline;" align="center"> Post You are Interested to Work As </h3>
                    <br>
                    <select class="form-control" id="post1" name="post1" required style="margin-left:220px;">
                        <option value="<?php echo $r36; ?>"> <?php echo $r36; ?> </option>
                        <option>-- Select --</option>
                        <?php

                        $records = "select * from post";
                        $sql = mysqli_query($con, $records);


                        while ($data = mysqli_fetch_array($sql)) {
                            $r1 = $data['jobposts'];

                        ?>

                            <option value="<?php echo "$r1"; ?>"> <?php echo "$r1"; ?></option>
                        <?php
                        }

                        ?>
                    </select>

                    <br>
                    <button type="submit" class="btn btn-success" name="other-save" style="margin-left:300px;"> Update </button>
                    <br><br><br>
                </form>

            </div>
            <script>
                $('.other-info-btn').click(function() {
                    $('.other-info-content').show();
                    $('.edu-info-content').hide();
                    $('.basic-info-content').hide();
                    $('.expr-info-content').hide();
                    $('.other-info-btn').css({
                        'border': '3px solid #4d86e8',
                    });
                    $('.edu-info-btn').css({
                        'border': 'none',
                    });
                    $('.basic-info-btn').css({
                        'border': 'none',
                    });
                    $('.expr-info-btn').css({
                        'border': 'none',
                    });
                });
            </script>
            <?php
            $u = $_SESSION['email'];

            $records = "select * from applicant_exp where Email ='$u'";
            $sql = mysqli_query($con, $records);


            while ($data = mysqli_fetch_array($sql)) {
                $q1 = $data['did'];
                $q2 = $data['exp_com'];
                $q3 = $data['exp_post'];
                $q4 = $data['exp_duration'];
            }
            ?>



            <div class="expr-info-content">
                <form method="post">

                    <table cellspacing="20px" cellpadding="20px" style="margin-left:130px;">
                        <!-- <tr>  
                            <td colspan="2" align="center" style="background-color:#52afde;color:#f2f5f4;margin-right:30px;"> <b> <big> <big> Fill Experience Details Here. !!  </big></big> </b>  </td> 
                            </tr> -->

                        <tr>
                            <td> <label for="email"> Email : </label>
                                <font color="red" size="4px"> * </font>
                            </td>
                            <td> <input type="email" class="form-control" id="email" name="email" readonly value="<?php echo $_SESSION['email']; ?>"> </td>
                        </tr>

                        <tr>
                            <td> <label for="did"> Did you have any Working Experience ? </label>
                                <font color="red" size="4px"> * </font>
                            </td>
                            <td> <select class="form-control" id="did" name="did" required>
                                    <option value="<?php echo $q1; ?>"> <?php echo $q1; ?> </option>
                                    <option value=""> -- Select -- </option>
                                    <option value="Yes"> Yes </option>
                                    <option value="No"> No </option>
                                </select>
                            </td>
                        </tr>
                    </table>
                    <script>
                        $('#did').on('change', function(event) {
                            var i = $('#did').val();
                            if (i == "Yes") {
                                $('.expr').css({
                                    'display': 'block'
                                });
                            } else {
                                $('.expr').css({
                                    'display': 'none'
                                });
                            }
                        });
                    </script>

                    <table cellspacing="20px" class="expr" cellpadding="20px" style="margin-left:130px;display:none;">
                        <tr>
                            <td> <label for="exp-com"> Company : </label>
                                <font color="red" size="4px"> * </font>
                            </td>
                            <td> <input type="text" id="exp-com" name="exp-com" class="form-control" value="<?php echo $q2; ?>"> </td>
                        </tr>

                        <tr>
                            <td> <label for="exp-post"> Post : </label>
                                <font color="red" size="4px"> * </font>
                            </td>
                            <td> <input type="text" id="exp-post" name="exp-post" class="form-control" value="<?php echo $q3; ?>"> </td>
                        </tr>

                        <tr>
                            <td> <label for="exp-dur"> Duration : </label>
                                <font color="red" size="4px"> * </font>
                            </td>
                            <td> <input type="text" id="exp-dur" name="exp-dur" class="form-control" value="<?php echo $q4; ?>"> </td>
                        </tr>

                    </table>

                    <br>
                    <button type="submit" class="btn btn-success" name="exp-save" style="margin-left:300px;"> Update </button>
                    <br><br><br>
                </form>
            </div>

            <script>
                $('.expr-info-btn').click(function() {
                    $('.expr-info-content').show();
                    $('.basic-info-content').hide();
                    $('.edu-info-content').hide();
                    $('.other-info-content').hide();
                    $('.expr-info-btn').css({
                        'border': '3px solid #4d86e8',
                    });
                    $('.edu-info-btn').css({
                        'border': 'none',
                    });
                    $('.other-info-btn').css({
                        'border': 'none',
                    });
                    $('.basic-info-btn').css({
                        'border': 'none',
                    });
                });
            </script>

        </div>
        <br>






        <?php
        include 'footer.php';
        ?>
    </div>
</body>

</html>

<?php
//error_reporting(0); 

if (isset($_POST['base-save'])) {

    $n1 = $_POST["email"];
    $n2 = $_POST["name"];
    $n3 = $_POST["add"];
    $n4 = $_POST["con"];
    $n5 = $_POST["gender"];
    $n6 = $_POST["dob"];
    $n7 = $_POST["pro"];

    $q = "UPDATE applicant_profile SET Email='$n1',Name='$n2',Address='$n3',Contact='$n4',gender='$n5',DOB='$n6' WHERE Email = '$n1'";

    if ($con->query($q)) {

        echo "<script> alert('Basic Details Updated Successfully !') </script>";
        //header("Refresh:0");
    } else {
        echo "ERROR";
    }

    //echo "<script> window.location='login.php'</script>  "; 
}

if (isset($_POST['edu-save'])) {
    $m1 = $_POST["email"];

    $m2 = $_POST["10-sch-nm"];
    $m3 = $_POST["10-sch-uni"];
    $m4 = $_POST["10-sch-from"];
    $m5 = $_POST["10-sch-to"];
    $m6 = $_POST["10-sch-grade"];

    $m7 = $_POST["12-sch-nm"];
    $m8 = $_POST["12-sch-fld"];
    $m9 = $_POST["12-sch-uni"];
    $m10 = $_POST["12-sch-from"];
    $m11 = $_POST["12-sch-to"];
    $m12 = $_POST["12-sch-grade"];

    $m13 = $_POST["gra-cou"];
    $m14 = $_POST["gra-sch-nm"];
    $m15 = $_POST["gra-sch-uni"];
    $m16 = $_POST["gra-sch-from"];
    $m17 = $_POST["gra-sch-to"];
    $m18 = $_POST["gra-sch-grade"];

    $m19 = $_POST["pg-cou"];
    $m20 = $_POST["pg-sch-nm"];
    $m21 = $_POST["pg-sch-uni"];
    $m22 = $_POST["pg-sch-from"];
    $m23 = $_POST["pg-sch-to"];
    $m24 = $_POST["pg-sch-grade"];


    $q = "UPDATE applicant_edu SET 10_sch_nm='$m2',10_sch_uni='$m3',10_sch_from='$m4',10_sch_to='$m5',10_sch_grade='$m6',
    12_sch_nm='$m7',12_sch_fld='$m8' , 12_sch_uni='$m9',12_sch_from='$m10' , 12_sch_to='$m11',12_sch_grade='$m12' , 
    gra_cou='$m13',gra_sch_nm='$m14' , gra_sch_uni='$m15',gra_sch_from='$m16' ,gra_sch_to='$m17',gra_sch_grade='$m18' ,
    pg_cou='$m19',pg_sch_nm='$m20' ,pg_sch_uni='$m21',pg_sch_from='$m22' ,pg_sch_to='$m23',pg_sch_grade='$m24' WHERE email = '$m1'";

    if ($con->query($q)) {

        echo "<script> alert('Educational Details Updated Successfully !') </script>";
        //header("Refresh:0");
    } else {
        echo "ERROR";
    }

    //echo "<script> window.location='login.php'</script>  ";

}

if (isset($_POST['other-save'])) {
    $p1 = $_POST["email"];

    $p2 = $_POST["interest1"];
    $p3 = $_POST["interest2"];
    $p4 = $_POST["interest3"];

    $p5 = $_POST["course1"];
    $p6 = $_POST["inst_nm1"];
    $p7 = $_POST["course1_from"];
    $p8 = $_POST["course1_to"];
    $p9 = $_POST["course1_per"];

    $p10 = $_POST["course2"];
    $p11 = $_POST["inst_nm2"];
    $p12 = $_POST["course2_from"];
    $p13 = $_POST["course2_to"];
    $p14 = $_POST["course2_per"];

    $p15 = $_POST["course3"];
    $p16 = $_POST["inst_nm3"];
    $p17 = $_POST["course3_from"];
    $p18 = $_POST["course3_to"];
    $p19 = $_POST["cp"];

    $p20 = $_POST["lang-t1"];
    $p21 = $_POST["lang-t1_lvl"];

    $p22 = $_POST["lang-t2"];
    $p23 = $_POST["lang-t2_lvl"];

    $p24 = $_POST["lang-t3"];
    $p25 = $_POST["langt3_lvl"];

    $p26 = $_POST["lang1"];
    $p27 = $_POST["lang1_lvl"];

    $p28 = $_POST["lang2"];
    $p29 = $_POST["lang2_lvl"];

    $p30 = $_POST["lang3"];
    $p31 = $_POST["lang3_lvl"];

    $p32 = $_POST["lang4"];
    $p33 = $_POST["lang4_lvl"];

    $p34 = $_POST["lang5"];
    $p35 = $_POST["lang5_lvl"];

    $p36 = $_POST["info"];
    $p37 = $_POST["post1"];

    $q = "UPDATE applicant_other SET interest1='$p2' , interest2='$p3' , interest3='$p4' , 
    course1 ='$p5' , inst_name1='$p6' , course1_fromm='$p7' , course1_too='$p8', course1_per='$p9' ,
    course2 ='$p10' , inst_name2='$p11' , course2_fromm='$p12' , course2_too='$p13' , course2_per='$p14' , 
    course3 ='$p15' , inst_name3='$p16' , course3_fromm='$p17' , course3_too='$p18' , course3_per='$p19' ,
    lang_t1 ='$p20' , lant_t1_lvl='$p21' , lang_t2='$p22' , lang_t2_lvl='$p23' ,  lang_t3='$p24' , lang_t3_lvl='$p25' ,
    lang1 ='$p26' , lang1_lvl='$p27' , lang2='$p28' , lang2_lvl='$p29' ,  lang3='$p30' , lang3_lvl='$p31' , lang4='$p32' , lang4_lvl='$p33' ,
    lang5 ='$p34' , lang5_lvl='$p35' , info='$p36' , post='$p37'
    WHERE email = '$p1'";

    if ($con->query($q)) {

        echo "<script> alert('Other Details Updated Successfully !') </script>";
        //header("Refresh:0");
    } else {
        echo "ERROR";
    }
}

if (isset($_POST['exp-save'])) {
    $q1 = $_POST["email"];
    $q2 = $_POST["did"];
    $q3 = $_POST["exp-com"];
    $q4 = $_POST["exp-post"];
    $q5 = $_POST["exp-dur"];


    $q = "UPDATE applicant_exp SET did='$q2' , exp_com='$q3' , exp_post='$q4' , exp_duration='$q5' WHERE email='$q1'";

    if ($con->query($q)) {
        echo "<script> alert ('Experience Details Updated Successfully ! ') </script>  ";
        // header("Refresh:0");
    } else {
        echo "ERROR";
    }
}
?>