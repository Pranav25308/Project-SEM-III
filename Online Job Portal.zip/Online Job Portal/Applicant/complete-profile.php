<?php
include 'connection.php';
?>
<!DOCTYPE html>
<html>

<head>
    <meta charset="UTF-8">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>
    <link href="style-applicant-complete.css" rel="stylesheet">
    <!-- <link rel="icon" href="images/Tlogo.png" type="image/icon type"> -->
    <title> Complete Your Profile </title>
    <style>
        #int2,
        #int3,
        #cou3,
        #cou2,
        #lan2,
        #lan3,
        #lan4,
        #lan5,
        #tenth,
        #twelth,
        #gra,
        #pgra,
        #save,
        #lan-t2,
        #lang-t3 {
            display: none;
        }
    </style>
</head>

<body>
    <div class="container-fluid">

        <?php
        $eml = $_SESSION['email'];
        ?>
        <?php
        $u = $_SESSION['email'];

        $records = "select * from student_signup where Email ='$u'";
        $sql = mysqli_query($con, $records);


        while ($data = mysqli_fetch_array($sql)) {
            $n1 = $data['Name'];
            $n2 = $data['Contact'];
            $n3 = $data['Email'];
            $n4 = $data['Password'];
        }
        ?>

        <div class="jumbotron">
            <h2 align="center"> Please , Complete Your Profile. </h2>
        </div>
        <br><br>

        <button class="basic-info-btn"> Basic Information </button>
        <button class="edu-info-btn"> Educational Information </button>
        <button class="other-info-btn"> Other Information </button>
        <button class="expr-info-btn"> Experience </button>
        <div class="content"><br><br><br>
            <div class="basic-info-content">
                <form method="post">

                    <table cellspacing="20px" cellpadding="20px" style="margin-left:130px;">
                        <!-- <tr>  
                            <td colspan="2" align="center" style="background-color:#52afde;color:#f2f5f4;"> <b> <big> <big> Fill Your Basic Details Here. !!  </big></big> </b>  </td> 
                            </tr> -->
                        <tr>
                            <td> <label for="email"> Email : </label>
                                <font color="red" size="4px"> * </font>
                            </td>
                            <td> <input type="email" class="form-control" id="email" name="email" readonly value="<?php echo $_SESSION['email']; ?>"> </td>
                        </tr>
                        <tr><br>
                            <td><label for="name"> Full Name : </label>
                                <font color="red" size="4px"> * </font>
                            </td>
                            <td> <input type="text" id="name" class="form-control" name="name" required value="<?php echo "$n1"; ?>"> </td>
                        </tr>

                        <tr>
                            <td> <label for="add"> Address : </label>
                                <font color="red" size="4px"> * </font>
                            </td>
                            <td> <textarea id="add" class="form-control" rows="4" cols="3" name="add"></textarea></td>
                        </tr>

                        <tr>
                            <td> <label for="con"> Contact :</label>
                                <font color="red" size="2px"> * </font>
                            </td>
                            <td> <input type="text" class="form-control" id="con" name="con" value="<?php echo "$n2"; ?>" pattern="(7|8|9)\d{9}" title="Please Enter 10 Digit Contact Number.It Must Be Start With 7 or 8 or 9 ." required> </td>
                        </tr>

                        <tr>
                            <td> <label> Gender : </label>
                                <font color="red" size="4px"> * </font>
                            </td>
                            <td> <input type="radio" name="gender" value="male" required style="margin-left:20px;"> Male
                                <input type="radio" name="gender" value="female" required style="margin-left:20px;"> Female
                                <input type="radio" name="gender" value="other" required style="margin-left:20px;"> Other
                            </td>
                        </tr>

                        <tr>
                            <td> <label for="dob"> DOB : </label>
                                <font color="red" size="4px"> * </font>
                            </td>
                            <td> <input type="date" class="form-control" id="dob" name="dob" required> </td>
                        </tr>

                    </table>
                    <br>
                    <button type="submit" class="btn btn-success" name="base-save" style="margin-left:300px;"> Save </button>
                    <br><br><br>
                </form>
            </div>
            <script>
                $('.basic-info-btn').click(function() {
                    $('.basic-info-content').show();
                    $('.edu-info-content').hide();
                    $('.other-info-content').hide();
                    $('.expr-info-content').hide();
                    $('.basic-info-btn').css({
                        'border': '3px solid #4d86e8',
                    });
                    $('.edu-info-btn').css({
                        'border': 'none',
                    });
                    $('.other-info-btn').css({
                        'border': 'none',
                    });
                    $('.expr-info-btn').css({
                        'border': 'none',
                    });
                });
            </script>

            <div class="edu-info-content">
                <form method="post">

                    <table cellspacing="20px" cellpadding="20px" style="margin-left:130px;">
                        <!-- <tr>  
                            <td colspan="2" align="center" style="background-color:#52afde;color:#f2f5f4;"> <b> <big> <big> Fill Your Educational Details Here. !!  </big></big> </b>  </td> 
                            </tr> -->

                        <tr>
                            <td> <label for="email"> Email : </label>
                                <font color="red" size="4px"> * </font>
                            </td>
                            <td> <input type="email" class="form-control" id="email" name="email" readonly value="<?php echo $_SESSION['email']; ?>"> </td>
                        </tr>

                        <tr>
                            <td> <label for="1"> Highest Education : </label>
                                <font color="red" size="4px"> * </font>
                            </td>
                            <td> <select id="1" name="1" required class="form-control">
                                    <option> -- Select --</option>
                                    <option value="graduation"> Graduation </option>
                                    <option value="p-graduation"> Post Graduation</option>
                                </select> </td>
                        </tr>
                    </table>
                    <br>
                    <script>
                        $('#1').on('change', function(event) {
                            var i = $('#1').val();
                            if (i == "graduation") {
                                $('#tenth').show();
                                $('#twelth').show();
                                $('#gra').show();
                                $('#save').show();

                            } else if (i == "p-graduation") {
                                $('#tenth').show();
                                $('#twelth').show();
                                $('#gra').show();
                                $('#pgra').show();
                                $('#save').show();
                            } else {
                                $('#tenth').hide();
                                $('#twelth').hide();
                                $('#gra').hide();
                                $('#pgra').hide();
                                $('#save').hide();

                            }
                        });
                    </script>

                    <div id="tenth">
                        <hr style="border-top: 1px solid black;"> <br>
                        <h3 style="text-decoration:underline;" align="center"> 10th (X) Details </h3>

                        <table cellspacing="20px" cellpadding="20px" style="margin-left:130px;">
                            <tr>
                                <td> <label for="10-sch-nm"> School Name : </label>
                                    <font color="red" size="4px"> * </font>
                                </td>
                                <td> <input type="text" class="form-control" id="10-sch-nm" name="10-sch-nm" required> </td>
                            </tr>

                            <tr>
                                <td> <label for="10-sch-uni"> University : </label>
                                    <font color="red" size="4px"> * </font>
                                </td>
                                <td> <input type="text" class="form-control" id="10-sch-uni" name="10-sch-uni" required> </td>
                            </tr>

                            <tr>
                                <td> <label for="10-sch-from"> From : </label>
                                    <font color="red" size="4px"> * </font>
                                </td>
                                <td> <input type="date" class="form-control" id="10-sch-from" name="10-sch-from" required> </td>
                            </tr>

                            <tr>
                                <td> <label for="10-sch-to"> To : </label>
                                    <font color="red" size="4px"> * </font>
                                </td>
                                <td> <input type="date" class="form-control" id="10-sch-to" name="10-sch-to" required> </td>
                            </tr>

                            <tr>
                                <td> <label for="10-sch-grade"> Percentage / CGPA : </label>
                                    <font color="red" size="4px"> * </font>
                                </td>
                                <td> <input type="text" class="form-control" id="10-sch-grade" name="10-sch-grade" required> </td>
                            </tr>

                        </table><br>
                    </div>

                    <div id="twelth">
                        <hr style="border-top: 1px solid black;"> <br>
                        <h3 style="text-decoration:underline;" align="center"> 12th (XII) Details </h3>

                        <table cellspacing="20px" cellpadding="20px" style="margin-left:130px;">
                            <tr>
                                <td> <label for="12-sch-nm"> School / College Name : </label>
                                    <font color="red" size="4px"> * </font>
                                </td>
                                <td> <input type="text" class="form-control" id="12-sch-nm" name="12-sch-nm" required> </td>
                            </tr>

                            <tr>
                                <td> <label for="12-sch-fld"> Stream : </label>
                                    <font color="red" size="4px"> * </font>
                                </td>
                                <td> <select id="12-sch-fld" name="12-sch-fld" required class="form-control">
                                        <option> -- Select --</option>
                                        <option value="science"> Science </option>
                                        <option value="commerce"> Commerce </option>
                                        <option value="arts"> Arts </option>
                                    </select> </td>
                            </tr>

                            <tr>
                                <td> <label for="12-sch-uni"> University : </label>
                                    <font color="red" size="4px"> * </font>
                                </td>
                                <td> <input type="text" class="form-control" id="12-sch-uni" name="12-sch-uni" required> </td>
                            </tr>

                            <tr>
                                <td> <label for="12-sch-from"> From : </label>
                                    <font color="red" size="4px"> * </font>
                                </td>
                                <td> <input type="date" class="form-control" id="12-sch-from" name="12-sch-from" required> </td>
                            </tr>

                            <tr>
                                <td> <label for="12-sch-to"> To : </label>
                                    <font color="red" size="4px"> * </font>
                                </td>
                                <td> <input type="date" class="form-control" id="12-sch-to" name="12-sch-to" required> </td>
                            </tr>

                            <tr>
                                <td> <label for="12-sch-grade"> Percentage / CGPA : </label>
                                    <font color="red" size="4px"> * </font>
                                </td>
                                <td> <input type="text" class="form-control" id="12-sch-grade" name="12-sch-grade" required> </td>
                            </tr>

                        </table><br>
                    </div>

                    <div id="gra">
                        <hr style="border-top: 1px solid black;"> <br>
                        <h3 style="text-decoration:underline;" align="center"> Graduation Details </h3>

                        <table cellspacing="20px" cellpadding="20px" style="margin-left:130px;">
                            <tr>
                                <td> <label for="gra-cou"> Course : </label>
                                    <font color="red" size="4px"> * </font>
                                </td>
                                <td> <select class="form-control" id="gra-cou" name="gra-cou" required>
                                        <option> -- Select -- </option>
                                        <option value="BE"> B.E </option>
                                        <option value="BTech"> B.Tech </option>
                                        <option value="BArch"> B.Arch </option>
                                        <option value="BCA"> BCA </option>
                                        <option value="BCS"> BCS </option>
                                        <option value="BSC"> BSC </option>
                                        <option value="BPharma"> BPharma </option>
                                        <option value="BCom"> B.COM </option>
                                        <option value="BBA"> BBA </option>
                                        <option value="BA"> BA </option>
                                    </select> </td>
                            </tr>

                            <tr>
                                <td> <label for="gra-sch-nm"> College Name : </label>
                                    <font color="red" size="4px"> * </font>
                                </td>
                                <td> <input type="text" class="form-control" id="gra-sch-nm" name="gra-sch-nm" required> </td>
                            </tr>

                            <tr>
                                <td> <label for="gra-sch-uni"> University : </label>
                                    <font color="red" size="4px"> * </font>
                                </td>
                                <td> <input type="text" class="form-control" id="gra-sch-uni" name="gra-sch-uni" required> </td>
                            </tr>

                            <tr>
                                <td> <label for="gra-sch-from"> From : </label>
                                    <font color="red" size="4px"> * </font>
                                </td>
                                <td> <input type="date" class="form-control" id="gra-sch-from" name="gra-sch-from" required> </td>
                            </tr>

                            <tr>
                                <td> <label for="gra-sch-to"> To : </label>
                                    <font color="red" size="4px"> * </font>
                                </td>
                                <td> <input type="date" class="form-control" id="gra-sch-to" name="gra-sch-to" required> </td>
                            </tr>

                            <tr>
                                <td> <label for="gra-sch-grade"> Percentage / CGPA : </label>
                                    <font color="red" size="4px"> * </font>
                                </td>
                                <td> <input type="text" class="form-control" id="gra-sch-grade" name="gra-sch-grade" required> </td>
                            </tr>

                        </table><br>
                    </div>

                    <div id="pgra">
                        <hr style="border-top: 1px solid black;"> <br>
                        <h3 style="text-decoration:underline;" align="center"> Post Graduation Details </h3>

                        <table cellspacing="20px" cellpadding="20px" style="margin-left:130px;">
                            <tr>
                                <td> <label for="pg-cou"> Course : </label> </td>
                                <td> <select class="form-control" id="pg-cou" name="pg-cou">
                                        <option> -- Select -- </option>
                                        <option value="ME"> M.E </option>
                                        <option value="MTech"> M.Tech </option>
                                        <option value="MArch"> M.Arch </option>
                                        <option value="MCA"> MCA </option>
                                        <option value="MCS"> MCS </option>
                                        <option value="MSC"> MSC </option>
                                        <option value="MPharma"> MPharma </option>
                                        <option value="MCom"> M.COM </option>
                                        <option value="MBA"> MBA </option>
                                        <option value="MA"> MA </option>
                                    </select> </td>
                            </tr>
                            <tr>
                                <td> <label for="pg-sch-nm"> College Name : </label>
                                    <font color="red" size="4px"> * </font>
                                </td>
                                <td> <input type="text" class="form-control" id="pg-sch-nm" name="pg-sch-nm"> </td>
                            </tr>

                            <tr>
                                <td> <label for="pg-sch-uni"> University : </label>
                                    <font color="red" size="4px"> * </font>
                                </td>
                                <td> <input type="text" class="form-control" id="pg-sch-uni" name="pg-sch-uni"> </td>
                            </tr>

                            <tr>
                                <td> <label for="pg-sch-from"> From : </label>
                                    <font color="red" size="4px"> * </font>
                                </td>
                                <td> <input type="date" class="form-control" id="pg-sch-from" name="pg-sch-from"> </td>
                            </tr>

                            <tr>
                                <td> <label for="pg-sch-to"> To : </label>
                                    <font color="red" size="4px"> * </font>
                                </td>
                                <td> <input type="date" class="form-control" id="pg-sch-to" name="pg-sch-to"> </td>
                            </tr>

                            <tr>
                                <td> <label for="pg-sch-grade"> Percentage / CGPA : </label>
                                    <font color="red" size="4px"> * </font>
                                </td>
                                <td> <input type="text" class="form-control" id="pg-sch-grade" name="pg-sch-grade"> </td>
                            </tr>

                        </table>
                    </div>
                    <br><br><br>
                    <button type="submit" class="btn btn-success" name="edu-save" style="margin-left:300px;" id="save"> Save </button>
                    <br><br><br>
                </form>
            </div>
            <script>
                $('.edu-info-btn').click(function() {
                    $('.edu-info-content').show();
                    $('.basic-info-content').hide();
                    $('.other-info-content').hide();
                    $('.expr-info-content').hide();
                    $('.edu-info-btn').css({
                        'border': '3px solid #4d86e8',
                    });
                    $('.basic-info-btn').css({
                        'border': 'none',
                    });
                    $('.other-info-btn').css({
                        'border': 'none',
                    });
                    $('.expr-info-btn').css({
                        'border': 'none',
                    });
                });
            </script>

            <div class="other-info-content">
                <form method="post">

                    <table cellspacing="20px" cellpadding="20px" style="margin-left:130px;">
                        <!-- <tr>  
                            <td colspan="2" align="center" style="background-color:#52afde;color:#f2f5f4;"> <b> <big> <big> Fill Other Details Here. !!  </big></big> </b>  </td> 
                            </tr> -->
                        <tr>
                            <td> <label for="email"> Email : </label> </td>
                            <td> <input type="email" class="form-control" id="email" name="email" readonly value="<?php echo $_SESSION['email']; ?>"> </td>
                        </tr>
                    </table> <br>

                    <hr style="border-top: 1px solid black;"> <br>
                    <h3 style="text-decoration:underline;" align="center"> Interests </h3>

                    <table cellspacing="20px" cellpadding="20px" style="margin-left:130px;" id="int">
                        <tr>
                            <td> <label for="interest1"> Interest 1 : </label>
                                <font color="red" size="4px"> * </font>
                            </td>
                            <td> <input type="text" class="form-control" id="interest1" name="interest1" pattern="[a-zA-Z ]+" title="Please use alphabets only." required> </td>
                        </tr>
                    </table>

                    <table cellspacing="20px" cellpadding="20px" style="margin-left:130px;" id="int2">
                        <tr>
                            <td> <label for="interest2"> Interest 2 : </label>
                                <font color="red" size="4px"> * </font>
                            </td>
                            <td> <input type="text" class="form-control" id="interest2" pattern="[a-zA-Z ]+" title="Please use alphabets only." name="interest2"> </td>
                        </tr>
                    </table>

                    <table cellspacing="20px" cellpadding="20px" style="margin-left:130px;" id="int3">
                        <tr>
                            <td> <label for="interest3"> Interest 3 : </label>
                                <font color="red" size="4px"> * </font>
                            </td>
                            <td> <input type="text" class="form-control" id="interest3" pattern="[a-zA-Z ]+" title="Please use alphabets only." name="interest3"> </td>
                        </tr>
                    </table>

                    <input type="button" style="margin-left:300px;width:150px;height:35px;" class="btn btn-warning" id="btn-int" value="ADD NEW">
                    <input type="button" style="margin-left:300px;width:150px;height:35px;display:none;" class="btn btn-warning" id="btn-int2" value="ADD NEW">

                    <script>
                        $('#btn-int').click(function() {
                            $('#int2').show();
                            $('#btn-int').hide();
                            $('#btn-int2').show();
                        });

                        $('#btn-int2').click(function() {
                            $('#int3').show();
                            $('#btn-int2').hide();
                        });
                    </script>

                    <br><br><br>
                    <hr style="border-top: 1px solid black;"> <br>
                    <h3 style="text-decoration:underline;" align="center"> Certifications </h3>

                    <table cellspacing="20px" cellpadding="20px" style="margin-left:130px;" id="cou1">
                        <tr>
                            <td> <label for="course1"> Course 1: </label>
                                <font color="red" size="4px"> * </font>
                            </td>
                            <td> <input type="text" class="form-control" id="course1" name="course1"> </td>
                        </tr>

                        <tr>
                            <td> <label for="inst_nm1"> Institute Name : </label>
                                <font color="red" size="4px"> * </font>
                            </td>
                            <td> <input type="text" class="form-control" id="inst_nm1" name="inst_nm1"> </td>
                        </tr>

                        <tr>
                            <td> <label for="course1_from"> From : </label>
                                <font color="red" size="4px"> * </font>
                            </td>
                            <td> <input type="date" class="form-control" id="course1_from" name="course1_from"> </td>
                        </tr>

                        <tr>
                            <td> <label for="course1_to"> To : </label>
                                <font color="red" size="4px"> * </font>
                            </td>
                            <td> <input type="date" class="form-control" id="course1_to" name="course1_to"> </td>
                        </tr>

                        <tr>
                            <td> <label for="course1_per"> Percentage / CGPA: </label>
                                <font color="red" size="4px"> * </font>
                            </td>
                            <td> <input type="text" class="form-control" id="course1_per" name="course1_per"> </td>
                        </tr>
                    </table>

                    <table cellspacing="20px" cellpadding="20px" style="margin-left:130px;" id="cou2">
                        <tr>
                            <td> <label for="course2"> Course 2: </label>
                                <font color="red" size="4px"> * </font>
                            </td>
                            <td> <input type="text" class="form-control" id="course2" name="course2"> </td>
                        </tr>

                        <tr>
                            <td> <label for="inst_nm2"> Institute Name : </label>
                                <font color="red" size="4px"> * </font>
                            </td>
                            <td> <input type="text" class="form-control" id="inst_nm2" name="inst_nm2"> </td>
                        </tr>

                        <tr>
                            <td> <label for="course2_from"> From : </label>
                                <font color="red" size="4px"> * </font>
                            </td>
                            <td> <input type="date" class="form-control" id="course2_from" name="course2_from"> </td>
                        </tr>

                        <tr>
                            <td> <label for="course2_to"> To : </label>
                                <font color="red" size="4px"> * </font>
                            </td>
                            <td> <input type="date" class="form-control" id="course2_to" name="course2_to"> </td>
                        </tr>

                        <tr>
                            <td> <label for="course2_per"> Percentage / CGPA: </label>
                                <font color="red" size="4px"> * </font>
                            </td>
                            <td> <input type="text" class="form-control" id="course2_per" name="course2_per"> </td>
                        </tr>
                    </table>
                    <table cellspacing="20px" cellpadding="20px" style="margin-left:130px;" id="cou3">
                        <tr>
                            <td> <label for="course3"> Course 3: </label>
                                <font color="red" size="4px"> * </font>
                            </td>
                            <td> <input type="text" class="form-control" id="course3" name="course3"> </td>
                        </tr>

                        <tr>
                            <td> <label for="inst_nm3"> Institute Name : </label>
                                <font color="red" size="4px"> * </font>
                            </td>
                            <td> <input type="text" class="form-control" id="inst_nm3" name="inst_nm3"> </td>
                        </tr>

                        <tr>
                            <td> <label for="course3_from"> From : </label>
                                <font color="red" size="4px"> * </font>
                            </td>
                            <td> <input type="date" class="form-control" id="course3_from" name="course3_from"> </td>
                        </tr>

                        <tr>
                            <td> <label for="course3_to"> To : </label>
                                <font color="red" size="4px"> * </font>
                            </td>
                            <td> <input type="date" class="form-control" id="course3_to" name="course3_to"> </td>
                        </tr>

                        <tr>
                            <td> <label for="course3_per"> Percentage / CGPA: </label>
                                <font color="red" size="4px"> * </font>
                            </td>
                            <td> <input type="text" class="form-control" id="course3_per" name="cp"> </td>
                        </tr>
                    </table>

                    <input type="button" style="margin-left:300px;width:150px;height:35px;" class="btn btn-warning" id="btn-cou" value="ADD NEW">
                    <input type="button" style="margin-left:300px;width:150px;height:35px;display:none;" class="btn btn-warning" id="btn-cou2" value="ADD NEW">
                    <script>
                        $('#btn-cou').click(function() {
                            $('#cou2').show();
                            $('#btn-cou').hide();
                            $('#btn-cou2').show();
                        });

                        $('#btn-cou2').click(function() {
                            $('#cou3').show();
                            $('#btn-cou2').hide();
                        });
                    </script>

                    <br><br>
                    <hr style="border-top: 1px solid black;"> <br>
                    <h3 style="text-decoration:underline;" align="center"> Languages known </h3>

                    <table cellspacing="20px" cellpadding="20px" style="margin-left:130px;">
                        <tr>
                            <td> <label for="lang-t1"> Language 1 : </label>
                                <font color="red" size="4px"> * </font>
                            </td>
                            <td> <input type="text" class="form-control" id="lang-t1" name="lang-t1" required> </td>
                        </tr>

                        <tr>
                            <td> </td>
                            <td> <select class="form-control" name="lang-t1_lvl" id="lang-t1_lvl" required>
                                    <option> -- Select skill --</option>
                                    <option value="talk">Talk </option>
                                    <option value="write">Write</option>
                                    <option value="talk-and-write">Talk & Write</option>
                                </select>
                            </td>
                        </tr>
                    </table>
                    <table cellspacing="20px" cellpadding="20px" style="margin-left:130px;" id="lan-t2">
                        <tr>
                            <td> <label for="lang-t2"> Language 2 : </label>
                                <font color="red" size="4px"> * </font>
                            </td>
                            <td> <input type="text" class="form-control" id="lang-t2" name="lang-t2"> </td>
                        </tr>

                        <tr>
                            <td> </td>
                            <td> <select class="form-control" name="lang-t2_lvl" id="lang-t2_lvl">
                                    <option> -- Select skill --</option>
                                    <option value="talk">Talk </option>
                                    <option value="write">Write</option>
                                    <option value="talk-and-write">Talk & Write</option>
                                </select> </td>
                        </tr>
                    </table>
                    <table cellspacing="20px" cellpadding="20px" style="margin-left:130px;" id="lang-t3">
                        <tr>
                            <td> <label for="langg-t3"> Language 3 : </label>
                                <font color="red" size="4px"> * </font>
                            </td>
                            <td> <input type="text" class="form-control" id="langg-t3" name="lang-t3"> </td>
                        </tr>

                        <tr>
                            <td> </td>
                            <td> <select class="form-control" name="langt3_lvl" id="lang3_lvl">
                                    <option> -- Select skill --</option>
                                    <option value="talk">Talk </option>
                                    <option value="write">Write</option>
                                    <option value="talk-and-write">Talk & Write</option>
                                </select> </td>
                        </tr>
                    </table>

                    <input type="button" style="margin-left:300px;width:150px;height:35px;" class="btn btn-warning" id="btn-lan-t2" value="ADD NEW">
                    <input type="button" style="margin-left:300px;width:150px;height:35px;display:none;" class="btn btn-warning" id="btn-lan-t3" value="ADD NEW">

                    <script>
                        $('#btn-lan-t2').click(function() {
                            $('#lan-t2').show();
                            $('#btn-lan-t2').hide();
                            $('#btn-lan-t3').show();
                        });

                        $('#btn-lan-t3').click(function() {
                            $('#lang-t3').show();
                            $('#btn-lan-t3').hide();
                        });
                    </script>

                    <hr style="border-top: 1px solid black;"> <br>
                    <h3 style="text-decoration:underline;" align="center"> Computer Languages known </h3>

                    <table cellspacing="20px" cellpadding="20px" style="margin-left:130px;">
                        <tr>
                            <td> <label for="lang1"> Language 1 : </label>
                                <font color="red" size="4px"> * </font>
                            </td>
                            <td> <input type="text" class="form-control" id="lang1" name="lang1" required> </td>
                        </tr>

                        <tr>
                            <td> </td>
                            <td> <select class="form-control" name="lang1_lvl" id="lang1_lvl" required>
                                    <option> -- Select Level --</option>
                                    <option value="beginner">Beginner</option>
                                    <option value="intermediate">Intermediate</option>
                                    <option value="expert">Expert</option>
                                </select>
                            </td>
                        </tr>
                    </table>
                    <table cellspacing="20px" cellpadding="20px" style="margin-left:130px;" id="lan2">
                        <tr>
                            <td> <label for="lang2"> Language 2 : </label>
                                <font color="red" size="4px"> * </font>
                            </td>
                            <td> <input type="text" class="form-control" id="lang2" name="lang2"> </td>
                        </tr>

                        <tr>
                            <td> </td>
                            <td> <select class="form-control" name="lang2_lvl" id="lang2_lvl">
                                    <option> -- Select Level --</option>
                                    <option value="beginner">Beginner</option>
                                    <option value="intermediate">Intermediate</option>
                                    <option value="expert">Expert</option>
                                </select> </td>
                        </tr>
                    </table>
                    <table cellspacing="20px" cellpadding="20px" style="margin-left:130px;" id="lan3">
                        <tr>
                            <td> <label for="lang3"> Language 3 : </label>
                                <font color="red" size="4px"> * </font>
                            </td>
                            <td> <input type="text" class="form-control" id="lang3" name="lang3"> </td>
                        </tr>

                        <tr>
                            <td> </td>
                            <td> <select class="form-control" name="lang3_lvl" id="lang3_lvl">
                                    <option> -- Select Level --</option>
                                    <option value="beginner">Beginner</option>
                                    <option value="intermediate">Intermediate</option>
                                    <option value="expert">Expert</option>
                                </select> </td>
                        </tr>
                    </table>
                    <table cellspacing="20px" cellpadding="20px" style="margin-left:130px;" id="lan4">
                        <tr>
                            <td> <label for="lang4"> Language 4 : </label>
                                <font color="red" size="4px"> * </font>
                            </td>
                            <td> <input type="text" class="form-control" id="lang4" name="lang4"> </td>
                        </tr>

                        <tr>
                            <td> </td>
                            <td> <select class="form-control" name="lang4_lvl" id="lang4_lvl">
                                    <option> -- Select Level --</option>
                                    <option value="beginner">Beginner</option>
                                    <option value="intermediate">Intermediate</option>
                                    <option value="expert">Expert</option>
                                </select> </td>
                        </tr>
                    </table>
                    <table cellspacing="20px" cellpadding="20px" style="margin-left:130px;" id="lan5">
                        <tr>
                            <td> <label for="lang5"> Language 5 : </label>
                                <font color="red" size="4px"> * </font>
                            </td>
                            <td> <input type="text" class="form-control" id="lang5" name="lang5"> </td>
                        </tr>

                        <tr>
                            <td> </td>
                            <td> <select class="form-control" name="lang5_lvl" id="lang5_lvl">
                                    <option> -- Select Level --</option>
                                    <option value="beginner">Beginner</option>
                                    <option value="intermediate">Intermediate</option>
                                    <option value="expert">Expert</option>
                                </select> </td>
                        </tr>
                    </table>
                    <input type="button" style="margin-left:300px;width:150px;height:35px;" class="btn btn-warning" id="btn-lan2" value="ADD NEW">
                    <input type="button" style="margin-left:300px;width:150px;height:35px;display:none;" class="btn btn-warning" id="btn-lan3" value="ADD NEW">
                    <input type="button" style="margin-left:300px;width:150px;height:35px;display:none;" class="btn btn-warning" id="btn-lan4" value="ADD NEW">
                    <input type="button" style="margin-left:300px;width:150px;height:35px;display:none;" class="btn btn-warning" id="btn-lan5" value="ADD NEW">
                    <script>
                        $('#btn-lan2').click(function() {
                            $('#lan2').show();
                            $('#btn-lan2').hide();
                            $('#btn-lan3').show();
                        });

                        $('#btn-lan3').click(function() {
                            $('#lan3').show();
                            $('#btn-lan3').hide();
                            $('#btn-lan4').show();
                        });

                        $('#btn-lan4').click(function() {
                            $('#lan4').show();
                            $('#btn-lan4').hide();
                            $('#btn-lan5').show();
                        });

                        $('#btn-lan5').click(function() {
                            $('#lan5').show();
                            $('#btn-lan5').hide();
                        });
                    </script>

                    <hr style="border-top: 1px solid black;"> <br>
                    <h3 style="text-decoration:underline;" align="center"> Tell Us About Yourself </h3>
                    <br>
                    <textarea class="form-control" id="info" name="info" rows="4" cols="1" required style="margin-left: 220px;"></textarea>
                    <br>

                    <hr style="border-top: 1px solid black;"> <br>
                    <h3 style="text-decoration:underline;" align="center"> Post You are Interested to Work As </h3>
                    <br>
                    <select class="form-control" name="post1">
                        <option> -- Select -- </option>
                        <?php

                        $records = "select * from post";
                        $sql = mysqli_query($con, $records);


                        while ($data = mysqli_fetch_array($sql)) {
                            $r1 = $data['jobposts'];

                        ?>

                            <option value="<?php echo "$r1"; ?>"> <?php echo "$r1"; ?></option>
                        <?php
                        }

                        ?>
                    </select>
                    <br>
                    <b<br><br><br>
                        <button type="submit" class="btn btn-success" name="other-save" style="margin-left:300px;"> Save </button>
                        <br><br><br>
                </form>

            </div>
            <script>
                $('.other-info-btn').click(function() {
                    $('.other-info-content').show();
                    $('.edu-info-content').hide();
                    $('.basic-info-content').hide();
                    $('.expr-info-content').hide();
                    $('.other-info-btn').css({
                        'border': '3px solid #4d86e8',
                    });
                    $('.edu-info-btn').css({
                        'border': 'none',
                    });
                    $('.basic-info-btn').css({
                        'border': 'none',
                    });
                    $('.expr-info-btn').css({
                        'border': 'none',
                    });
                });
            </script>

            <div class="expr-info-content">
                <form method="post">

                    <table cellspacing="20px" cellpadding="20px" style="margin-left:130px;">
                        <!-- <tr>  
                            <td colspan="2" align="center" style="background-color:#52afde;color:#f2f5f4;margin-right:30px;"> <b> <big> <big> Fill Experience Details Here. !!  </big></big> </b>  </td> 
                            </tr> -->

                        <tr>
                            <td> <label for="email"> Email : </label>
                                <font color="red" size="4px"> * </font>
                            </td>
                            <td> <input type="email" class="form-control" id="email" name="email" readonly value="<?php echo $_SESSION['email']; ?>"> </td>
                        </tr>

                        <tr>
                            <td> <label for="did"> Did you have any Working Experience ? </label>
                                <font color="red" size="4px"> * </font>
                            </td>
                            <td> <select class="form-control" id="did" name="did" required>
                                    <option value=""> -- Select -- </option>
                                    <option value="yes"> Yes </option>
                                    <option value="no"> No </option>
                                </select>
                            </td>
                        </tr>
                    </table>
                    <script>
                        $('#did').on('change', function(event) {
                            var i = $('#did').val();
                            if (i == "yes") {
                                $('.expr').css({
                                    'display': 'block'
                                });
                            } else {
                                $('.expr').css({
                                    'display': 'none'
                                });
                            }
                        });
                    </script>

                    <table cellspacing="20px" class="expr" cellpadding="20px" style="margin-left:130px;display:none;">
                        <tr>
                            <td> <label for="exp-com"> Company : </label>
                                <font color="red" size="4px"> * </font>
                            </td>
                            <td> <input type="text" id="exp-com" name="exp-com" class="form-control"> </td>
                        </tr>

                        <tr>
                            <td> <label for="exp-post"> Post : </label>
                                <font color="red" size="4px"> * </font>
                            </td>
                            <td> <input type="text" id="exp-post" name="exp-post" class="form-control"> </td>
                        </tr>

                        <tr>
                            <td> <label for="exp-dur"> Duration : </label>
                                <font color="red" size="4px"> * </font>
                            </td>
                            <td> <input type="text" id="exp-dur" name="exp-dur" class="form-control"> </td>
                        </tr>

                    </table>

                    <br>
                    <button type="submit" class="btn btn-success" name="exp-save" style="margin-left:300px;"> Save </button>
                    <br><br><br>
                </form>
            </div>
            <script>
                $('.expr-info-btn').click(function() {
                    $('.expr-info-content').show();
                    $('.basic-info-content').hide();
                    $('.edu-info-content').hide();
                    $('.other-info-content').hide();
                    $('.expr-info-btn').css({
                        'border': '3px solid #4d86e8',
                    });
                    $('.edu-info-btn').css({
                        'border': 'none',
                    });
                    $('.other-info-btn').css({
                        'border': 'none',
                    });
                    $('.basic-info-btn').css({
                        'border': 'none',
                    });
                });
            </script>
        </div>
        <br>
    </div>
</body>

</html>

<?php

error_reporting(0);

if (isset($_POST['base-save'])) {
    $n1 = $_POST["email"];
    $n2 = $_POST["name"];
    $n3 = $_POST["add"];
    $n4 = $_POST["con"];
    $n5 = $_POST["gender"];
    $n6 = $_POST["dob"];

    $q = "insert into applicant_profile values('$n1','$n2','$n3','$n4','$n5','$n6')";
    if ($con->query($q)) {
        echo "<script> alert ('Basic Details Saved Successfully ! Please Fill Out Education Details. ') </script>  ";
        //echo "<script> window.location='login.php'</script>  ";
    }
}

if (isset($_POST['edu-save'])) {
    $m1 = $_POST["email"];

    $m2 = $_POST["10-sch-nm"];
    $m3 = $_POST["10-sch-uni"];
    $m4 = $_POST["10-sch-from"];
    $m5 = $_POST["10-sch-to"];
    $m6 = $_POST["10-sch-grade"];

    $m7 = $_POST["12-sch-nm"];
    $m8 = $_POST["12-sch-fld"];
    $m9 = $_POST["12-sch-uni"];
    $m10 = $_POST["12-sch-from"];
    $m11 = $_POST["12-sch-to"];
    $m12 = $_POST["12-sch-grade"];

    $m13 = $_POST["gra-cou"];
    $m14 = $_POST["gra-sch-nm"];
    $m15 = $_POST["gra-sch-uni"];
    $m16 = $_POST["gra-sch-from"];
    $m17 = $_POST["gra-sch-to"];
    $m18 = $_POST["gra-sch-grade"];

    $m19 = $_POST["pg-cou"];
    $m20 = $_POST["pg-sch-nm"];
    $m21 = $_POST["pg-sch-uni"];
    $m22 = $_POST["pg-sch-from"];
    $m23 = $_POST["pg-sch-to"];
    $m24 = $_POST["pg-sch-grade"];

    $q = "insert into applicant_edu values('$m1','$m2','$m3','$m4','$m5','$m6','$m7','$m8','$m9','$m10','$m11','$m12','$m13','$m14','$m15','$m16','$m17',
        '$m18','$m19','$m20','$m21','$m22','$m23','$m24')";

    if ($con->query($q)) {

        echo "<script> alert ('Eduacational Details Saved Successfully ! Please Fill Out Other Details.') </script>  ";
        //echo "<script> window.location='login.php'</script>  ";
    }
}

if (isset($_POST['other-save'])) {
    $p1 = $_POST["email"];

    $p2 = $_POST["interest1"];
    $p3 = $_POST["interest2"];
    $p4 = $_POST["interest3"];

    $p5 = $_POST["course1"];
    $p6 = $_POST["inst_nm1"];
    $p7 = $_POST["course1_from"];
    $p8 = $_POST["course1_to"];
    $p9 = $_POST["course1_per"];

    $p10 = $_POST["course2"];
    $p11 = $_POST["inst_nm2"];
    $p12 = $_POST["course2_from"];
    $p13 = $_POST["course2_to"];
    $p14 = $_POST["course2_per"];

    $p15 = $_POST["course3"];
    $p16 = $_POST["inst_nm3"];
    $p17 = $_POST["course3_from"];
    $p18 = $_POST["course3_to"];
    $p19 = $_POST["cp"];

    $p20 = $_POST["lang-t1"];
    $p21 = $_POST["lang-t1_lvl"];

    $p22 = $_POST["lang-t2"];
    $p23 = $_POST["lang-t2_lvl"];

    $p24 = $_POST["lang-t3"];
    $p25 = $_POST["langt3_lvl"];

    $p26 = $_POST["lang1"];
    $p27 = $_POST["lang1_lvl"];

    $p28 = $_POST["lang2"];
    $p29 = $_POST["lang2_lvl"];

    $p30 = $_POST["lang3"];
    $p31 = $_POST["lang3_lvl"];

    $p32 = $_POST["lang4"];
    $p33 = $_POST["lang4_lvl"];

    $p34 = $_POST["lang5"];
    $p35 = $_POST["lang5_lvl"];

    $p36 = $_POST["info"];
    $p37 = $_POST["post1"];

    $q = "insert into applicant_other values('$p1','$p2','$p3','$p4','$p5','$p6','$p7','$p8','$p9','$p10','$p11','$p12','$p13','$p14','$p15','$p16','$p17','$p18','$p19',
    '$p20','$p21','$p22','$p23','$p24','$p25','$p26','$p27','$p28','$p29','$p30','$p31','$p32','$p33','$p34','$p35','$p36','$p37')";

    if ($con->query($q)) {

        echo "<script> alert ('Other Details Saved Successfully !Please Fill Out Experience Details. ') </script>  ";
        //echo "<script> window.location='login.php'</script>  ";
    }
}

if (isset($_POST['exp-save'])) {
    $r1 = $_POST["email"];
    $r2 = $_POST["did"];
    $r3 = $_POST["exp-com"];
    $r4 = $_POST["exp-post"];
    $r5 = $_POST["exp-dur"];


    $q = "insert into applicant_exp values('$r1','$r2','$r3','$r4','$r5')";

    if ($con->query($q)) {

        echo "<script> alert ('Experience Details Saved Successfully !  ') </script>  ";
        echo "<script> window.location='applicant-profile.php'</script>  ";
    }
}
?>