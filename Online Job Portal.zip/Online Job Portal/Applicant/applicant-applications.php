<?php include 'connection.php'; ?>
<!DOCTYPE html>
<html>

<head>
    <meta charset="UTF-8">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>
    <link href="style-applicant-applications.css" rel="stylesheet">
    <link rel="icon" href="images/logo.png" type="image/icon type">
    <title> Applications </title>
    <style>
        .job {
            border: 0px solid black;
            border-radius: 25px;
            width: 70%;
            margin-left: 200px;
            padding: 25px;
            box-shadow: 10px 10px 15px 5px #b9bcbd;
        }

        .job_title {
            color: #0a6cff;
            font-size: 28px;
            font-weight: bold;
            font-family: Verdana, Geneva, Tahoma, sans-serif;
            text-decoration: underline;
        }

        .com {
            font-size: 15px;
            font-family: Verdana, Geneva, Tahoma, sans-serif;
        }

        .j_d,
        .e_c {
            font-size: 15px;
            font-family: Verdana, Geneva, Tahoma, sans-serif;
            font-weight: bold;
        }

        .j_d2,
        .e_c2 {
            font-size: 14px;
            font-family: Verdana, Geneva, Tahoma, sans-serif;
        }

        .btn {
            width: 200px;
            height: 45px;
            margin-left: 400px;


        }
    </style>
</head>

<body>
    <div class="container-fluid">

        <?php
        include 'header.php';
        ?>


        <div class="jumbotron" align="center">
            <h1>Applications </h1>
            <p> The jobs you have applied. </p>
        </div>

        <?php
        $u = $_SESSION['email'];
        //echo "$u";

        $records = "select * from applications where seeker_email ='$u'";
        $sql = mysqli_query($con, $records);
        while ($data = mysqli_fetch_array($sql)) {
            $m1 = $data['seeker_email'];
            $m2 = $data['com_name'];
            $m3 = $data['com_website'];
            $m4 = $data['job_title'];
            $m5 = $data['job_desc'];
            $m6 = $data['job_eli'];
            $m7 = $data['job_type'];
            $m8 = $data['location'];
        ?>
            <form method="post">
                <div class="job">
                    <h3 class="job_title" name="jobtitle"> <?php echo "$m4"; ?> </h3>
                    <br>
                    <h5 class="com"> Company : <?php echo "$m2"; ?> </h5>
                    <h5 class="com"> Website : <?php echo "$m3"; ?> </h5>
                    <h5 class="com"> Your Email : <?php echo "$m1"; ?> </h5>
                    <br>
                    <h5 class="j_d"> Job Description: </h5>
                    <p class="j_d2"> <?php echo "$m5"; ?> </p>
                    <br>
                    <h5 class="e_c"> Eligibility Crietria : </h5>
                    <p class="e_c2"> <?php echo "$m6"; ?> </p>
                    <br>
                    <h5 class="com"> Job Type : <?php echo "$m7"; ?> </h5>
                    <h5 class="com"> Location : <?php echo "$m8"; ?></h5>

                    <br>

                </div>
                <br><br><br><br><br>
            </form>

        <?php
        }
        ?>



        <br><br>

        <br>

        <br><br><br><br><br><br><br><br>

        <br>

        <?php
        include 'footer.php';
        ?>

    </div>
</body>

</html>