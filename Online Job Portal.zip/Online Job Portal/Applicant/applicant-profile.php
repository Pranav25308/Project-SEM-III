<?php
include 'connection.php';
?>
<!DOCTYPE html>
<html>

<head>
  <meta charset="UTF-8">
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>
  <link href="style-applicant-profile.css" rel="stylesheet">
  <link rel="icon" href="images/logo.png" type="image/icon type">
  <title> Profile </title>
  <style>
    #int2,
    #int3,
    #cou3,
    #cou2,
    #lan2,
    #lan3,
    #lan4,
    #lan5,
    #tenth,
    #twelth,
    #gra,
    #pgra,
    #save,
    #lan-t2,
    #lang-t3 {
      display: none;
    }
  </style>
</head>

<body>
  <div class="container-fluid">

    <?php
    include 'header.php';
    ?>

    <?php

    //echo $_SESSION['email'];
    ?>

    <?php
    $u = $_SESSION['email'];

    $records = "select * from applicant_profile where Email ='$u'";
    $sql = mysqli_query($con, $records);


    while ($data = mysqli_fetch_array($sql)) {
      $n1 = $data['Email'];
      $n2 = $data['Name'];
      $n3 = $data['Address'];
      $n4 = $data['Contact'];
      $n5 = $data['gender'];
      $n6 = $data['DOB'];
    }

    $records1 = "select * from applicant_edu where Email ='$u'";
    $sql1 = mysqli_query($con, $records1);


    while ($data1 = mysqli_fetch_array($sql1)) {
      $n7 = $data1['10_sch_nm'];
      $n8 = $data1['10_sch_uni'];
      $n9 = $data1['10_sch_from'];
      $n10 = $data1['10_sch_to'];
      $n11 = $data1['10_sch_grade'];

      $n12 = $data1['12_sch_nm'];
      $n13 = $data1['12_sch_fld'];
      $n14 = $data1['12_sch_uni'];
      $n15 = $data1['12_sch_from'];
      $n16 = $data1['12_sch_to'];
      $n17 = $data1['12_sch_grade'];

      $n18 = $data1['gra_cou'];
      $n19 = $data1['gra_sch_nm'];
      $n20 = $data1['gra_sch_uni'];
      $n21 = $data1['gra_sch_from'];
      $n22 = $data1['gra_sch_to'];
      $n23 = $data1['gra_sch_grade'];

      $n24 = $data1['pg_cou'];
      $n25 = $data1['pg_sch_nm'];
      $n26 = $data1['pg_sch_uni'];
      $n27 = $data1['pg_sch_from'];
      $n28 = $data1['pg_sch_to'];
      $n29 = $data1['pg_sch_grade'];
    }

    $records2 = "select * from applicant_other where Email ='$u'";
    $sql2 = mysqli_query($con, $records2);


    while ($data2 = mysqli_fetch_array($sql2)) {
      $n30 = $data2['interest1'];
      $n31 = $data2['interest2'];
      $n32 = $data2['interest3'];

      $n33 = $data2['course1'];
      $n34 = $data2['inst_name1'];
      $n35 = $data2['course1_fromm'];
      $n36 = $data2['course1_too'];
      $n37 = $data2['course1_per'];

      $n38 = $data2['course2'];
      $n39 = $data2['inst_name2'];
      $n40 = $data2['course2_fromm'];
      $n41 = $data2['course2_too'];
      $n42 = $data2['course2_per'];

      $n43 = $data2['course3'];
      $n44 = $data2['inst_name3'];
      $n45 = $data2['course3_fromm'];
      $n46 = $data2['course3_too'];
      $n47 = $data2['course3_per'];

      $n48 = $data2['lang_t1'];
      $n49 = $data2['lant_t1_lvl'];

      $n50 = $data2['lang_t2'];
      $n51 = $data2['lang_t2_lvl'];

      $n52 = $data2['lang_t3'];
      $n53 = $data2['lang_t3_lvl'];

      $n54 = $data2['lang1'];
      $n55 = $data2['lang1_lvl'];

      $n56 = $data2['lang2'];
      $n57 = $data2['lang2_lvl'];

      $n58 = $data2['lang3'];
      $n59 = $data2['lang3_lvl'];

      $n60 = $data2['lang4'];
      $n61 = $data2['lang4_lvl'];

      $n62 = $data2['lang5'];
      $n63 = $data2['lang5_lvl'];

      $n64 = $data2['info'];
      $n65 = $data2['post'];
    }

    $records3 = "select * from applicant_exp where Email ='$u'";
    $sql3 = mysqli_query($con, $records3);


    while ($data3 = mysqli_fetch_array($sql3)) {
      $n66 = $data3['did'];
      $n67 = $data3['exp_com'];
      $n68 = $data3['exp_post'];
      $n69 = $data3['exp_duration'];
    }
    ?>

    <!-- <div class="jumbotron" align="center">
                <h1> Basic Details <br>
              </div> <br> -->
    <div style="border-bottom:2px solid #02b6de;border-top:2px solid #02b6de;border-radius:20px;" class="container-fluid"> <br>
      <table class="table table-bordered">
        <thead>
          <tr>
            <th scope="col"> Name </th>
            <th scope="col"> Email </th>
            <th scope="col"> Contact </th>
          </tr>
        </thead>
        <tbody>
          <tr>
            <td> <?php echo "$n2"; ?> </td>
            <td> <?php echo "$n1"; ?> </td>
            <td> <?php echo "$n4"; ?> </td>
          </tr>
        </tbody>

      </table><br>
    </div>
    <br><br>

    <div class="jumbotron" align="center">
      <h1> Educational Details </h1> <br>
      <br>
    </div>

    <div style="border-bottom:2px solid #fcb13f;border-top:2px solid #fcb13f;border-radius:20px;" class="container-fluid">
      <h2 align="center" style="text-decoration:underline 2px;"> X Details </h2> <br>

      <table class="table table-bordered">
        <thead>
          <tr>
            <th> School Name </th>
            <th> University </th>
            <th> From </th>
            <th> To </th>
            <th> Grade/Percentage </th>
          </tr>
        </thead>
        <tbody>
          <tr>
            <td> <?php echo "$n7"; ?> </td>
            <td> <?php echo "$n8"; ?> </td>
            <td> <?php echo "$n9"; ?> </td>
            <td> <?php echo "$n10"; ?> </td>
            <td> <?php echo "$n11"; ?> </td>
          </tr>
        </tbody>

      </table>

      <br><br>
    </div>
    <br><br>
    <div style="border-bottom:2px solid #fcb13f;border-top:2px solid #fcb13f;border-radius:20px;" class="container-fluid">
      <h2 align="center" style="text-decoration:underline 2px;"> XII Details </h2> <br>
      <table class="table table-bordered">
        <thead>
          <tr>
            <th> School Name </th>
            <th> Stream </th>
            <th> University </th>
            <th> From </th>
            <th> To </th>
            <th> Grade/Percentage </th>
          </tr>
        </thead>
        <tbody>
          <tr>
            <td> <?php echo "$n12"; ?> </td>
            <td> <?php echo "$n13"; ?> </td>
            <td> <?php echo "$n14"; ?> </td>
            <td> <?php echo "$n15"; ?> </td>
            <td> <?php echo "$n16"; ?> </td>
            <td> <?php echo "$n17"; ?> </td>
          </tr>
        </tbody>
      </table>

      <br><br>
    </div>
    <br><br>
    <div style="border-bottom:2px solid #fcb13f;border-top:2px solid #fcb13f;border-radius:20px;" class="container-fluid">
      <h2 align="center" style="text-decoration:underline 2px;"> Graduation Details </h2> <br>
      <table class="table table-bordered">
        <thead>
          <tr>
            <th> Course </th>
            <th> School Name </th>
            <th> University </th>
            <th> From </th>
            <th> To </th>
            <th> Grade/Percentage </th>
          </tr>
        </thead>
        <tbody>
          <tr>
            <td> <?php echo "$n18"; ?> </td>
            <td> <?php echo "$n19"; ?> </td>
            <td> <?php echo "$n20"; ?> </td>
            <td> <?php echo "$n21"; ?> </td>
            <td> <?php echo "$n22"; ?> </td>
            <td> <?php echo "$n23"; ?> </td>
          </tr>
        </tbody>
      </table>
      <br><br>
    </div>
    <br><br>
    <div style="border-bottom:2px solid #fcb13f;border-top:2px solid #fcb13f;border-radius:20px;" class="container-fluid">
      <h2 align="center" style="text-decoration:underline 2px;"> Post-Graduation Details </h2> <br>
      <table class="table table-bordered">
        <thead>
          <tr>
            <th> Course </th>
            <th> School Name </th>
            <th> University </th>
            <th> From </th>
            <th> To </th>
            <th> Grade/Percentage </th>
          </tr>
        </thead>
        <tbody>
          <tr>
            <td> <?php echo "$n24"; ?> </td>
            <td> <?php echo "$n25"; ?> </td>
            <td> <?php echo "$n26"; ?> </td>
            <td> <?php echo "$n27"; ?> </td>
            <td> <?php echo "$n28"; ?> </td>
            <td> <?php echo "$n29"; ?> </td>
          </tr>
        </tbody>
      </table>
      <br><br>
    </div>
    <br><br>
    <div class="jumbotron" align="center">
      <h1> Other Details <br>
    </div> <br>
    <div style="border-bottom:2px solid #8a49f2;border-top:2px solid #8a49f2;border-radius:20px;" class="container-fluid">
      <h2 align="center" style="text-decoration:underline 2px;"> Interests </h2> <br>
      <table class="table table-bordered">
        <tr>
          <td> <?php echo "$n30"; ?> </td>
          <td> <?php echo "$n31"; ?> </td>
          <td> <?php echo "$n32"; ?> </td>
        </tr>

      </table><br>
    </div>
    <br><br>
    <div style="border-bottom:2px solid #8a49f2;border-top:2px solid #8a49f2;border-radius:20px;" class="container-fluid">
      <h2 align="center" style="text-decoration:underline 2px;"> Courses </h2><br>
      <table class="table table-bordered">
        <thead>
          <tr>
            <th> Course Name </th>
            <th> Institute Name </th>
            <th> From </th>
            <th> To </th>
            <th> Grade/Percentage </th>
          </tr>
        </thead>
        <tbody>
          <tr>
            <td> <?php echo "$n33"; ?> </td>
            <td> <?php echo "$n34"; ?> </td>
            <td> <?php echo "$n35"; ?> </td>
            <td> <?php echo "$n36"; ?> </td>
            <td> <?php echo "$n37"; ?> </td>
          </tr>

          <tr>
            <td> <?php echo "$n38"; ?> </td>
            <td> <?php echo "$n39"; ?> </td>
            <td> <?php echo "$n40"; ?> </td>
            <td> <?php echo "$n41"; ?> </td>
            <td> <?php echo "$n42"; ?> </td>
          </tr>

          <tr>
            <td> <?php echo "$n43"; ?> </td>
            <td> <?php echo "$n44"; ?> </td>
            <td> <?php echo "$n45"; ?> </td>
            <td> <?php echo "$n46"; ?> </td>
            <td> <?php echo "$n47"; ?> </td>
          </tr>
        </tbody>
      </table><br>
    </div>
    <br><br>
    <div style="border-bottom:2px solid #8a49f2;border-top:2px solid #8a49f2;border-radius:20px;" class="container-fluid">
      <h2 align="center" style="text-decoration:underline 2px;"> Languages Known </h2> <br>
      <table class="table table-bordered">
        <thead>
          <tr>
            <th> Language </th>
            <th> Details </th>
          </tr>
        </thead>
        <tbody>
          <tr>
            <td> <?php echo "$n48"; ?> </td>
            <td> <?php echo "$n49"; ?> </td>
          </tr>

          <tr>
            <td> <?php echo "$n50"; ?> </td>
            <td> <?php echo "$n51"; ?> </td>
          </tr>

          <tr>
            <td> <?php echo "$n52"; ?> </td>
            <td> <?php echo "$n53"; ?> </td>
          </tr>
        </tbody>
      </table><br>
    </div>
    <br><br>
    <div style="border-bottom:2px solid #8a49f2;border-top:2px solid #8a49f2;border-radius:35px;" class="container-fluid">
      <h2 align="center" style="text-decoration:underline 2px;"> Computer Languages Known </h2> <br>
      <table class="table table-bordered">
        <thead>
          <tr>
            <th> Language </th>
            <th> Details </th>
          </tr>
        </thead>
        <tbody>
          <tr>
            <td> <?php echo "$n54"; ?> </td>
            <td> <?php echo "$n55"; ?> </td>
          </tr>

          <tr>
            <td> <?php echo "$n56"; ?> </td>
            <td> <?php echo "$n57"; ?> </td>
          </tr>

          <tr>
            <td> <?php echo "$n58"; ?> </td>
            <td> <?php echo "$n59"; ?> </td>
          </tr>

          <tr>
            <td> <?php echo "$n60"; ?> </td>
            <td> <?php echo "$n61"; ?> </td>
          </tr>

          <tr>
            <td> <?php echo "$n62"; ?> </td>
            <td> <?php echo "$n63"; ?> </td>
          </tr>
        </tbody>
      </table><br>
    </div>
    <br><br>
    <div style="border-bottom:2px solid #8a49f2;border-top:2px solid #8a49f2;border-radius:20px;" class="container-fluid">
      <h2 align="center" style="text-decoration:underline 2px;"> About yourself </h2> <br>
      <p align="center"> <?php echo "$n64"; ?> </p><br>
    </div>
    <br><br>
    <div style="border-bottom:2px solid #8a49f2;border-top:2px solid #8a49f2;border-radius:35px;" class="container-fluid">
      <h2 align="center" style="text-decoration:underline 2px;"> Intersted in (Job Post ) </h2> <br>
      <table class="table table-bordered">
        <thead>

        </thead>
        <tbody>
          <tr>
            <td> <?php echo "$n65"; ?> </td>
          </tr>
        </tbody>
      </table><br>
    </div>
    <br><br>

    <div class="jumbotron" align="center">
      <h1> Experience Details <br>
    </div> <br>
    <div style="border-bottom:2px solid #02c733;border-top:2px solid #02c733;border-radius:20px;" class="container-fluid"> <br>
      <table class="table table-bordered">
        <thead>
          <tr>
            <th> Any Experience </th>
            <th> Company Name </th>
            <th> Post </th>
            <th> Duration </th>
          </tr>
        </thead>
        <tbody>
          <tr>
            <th> <?php echo "$n66"; ?> </th>
            <td> <?php echo "$n67"; ?> </td>
            <td> <?php echo "$n68"; ?> </td>
            <td> <?php echo "$n69"; ?> </td>
          </tr>
        </tbody>
      </table>

      <br>
    </div>

    <br> <br>



    <?php
    include 'footer.php';
    ?>

  </div>
</body>

</html>