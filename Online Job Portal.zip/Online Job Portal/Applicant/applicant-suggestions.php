<!DOCTYPE html>
<html>

<head>
    <meta charset="UTF-8">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>
    <link href="style-applicant-suggestions.css" rel="stylesheet">
    <!-- <link rel="icon" href="images/Tlogo.png" type="image/icon type"> -->
    <title> Suggestions </title>
    <style>

    </style>
</head>

<body>
    <div class="container-fluid">

        <?php
        include 'header.php';
        ?>

        <br><br><br><br><br><br>
        <div class="iwt">
            <label for="iwt"> I want to </label>
            <select id="iwt" name="iam" class="form-control">
                <option value=""> -- select -- </option>
                <option value="sch_name"> Suggest School Name. </option>
                <option value="clg_name"> Suggest College Name. </option>
                <option value="com_que"> Complaint / Query </option>
            </select>
        </div>

        <script>
            $('#iwt').on('change', function(event) {
                var i = $('#iwt').val();
                if (i == "sch_name") {
                    $('.sch_name').css({
                        'display': 'block'
                    });
                    $('.clg_name').css({
                        'display': 'none'
                    });
                    $('.com_que').css({
                        'display': 'none'
                    });
                } else if (i == "clg_name") {
                    $('.clg_name').css({
                        'display': 'block'
                    });
                    $('.sch_name').css({
                        'display': 'none'
                    });
                    $('.com_que').css({
                        'display': 'none'
                    });
                } else if (i == "com_que") {
                    $('.com_que').css({
                        'display': 'block'
                    });
                    $('.sch_name').css({
                        'display': 'none'
                    });
                    $('.clg_name').css({
                        'display': 'none'
                    });
                } else {
                    $('.sch_name').css({
                        'display': 'none'
                    });
                    $('.clg_name').css({
                        'display': 'none'
                    });
                    $('.com_que').css({
                        'display': 'none'
                    });
                }
            });
        </script>

        <div class="sch_name" style="display:none;">
            <h2>School Name</h2>
        </div>

        <div class="clg_name" style="display:none;">
            <h2>College Name</h2>
        </div>

        <div class="com_que" style="display:none;">
            <h2>Complaint / Query</h2>
        </div>


        <br><br>

        <br>



        <br><br><br><br><br><br><br><br>

        <br>

        <?php
        include 'footer.php';
        ?>

    </div>
</body>

</html>