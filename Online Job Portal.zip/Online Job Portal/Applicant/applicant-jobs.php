<?php include 'connection.php'; ?>
<!DOCTYPE html>
<html>

<head>
    <script src="https://smtpjs.com/v3/smtp.js"> </script>
    <meta charset="UTF-8">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>
    <link href="style-applicant-jobs.css" rel="stylesheet">
    <link rel="icon" href="images/logo.png" type="image/icon type">
    <title> Jobs </title>
    <style>
        .job {
            border: 0px solid black;
            border-radius: 25px;
            width: 1100px;
            margin-left: 200px;
            padding: 25px;
            box-shadow: 10px 10px 15px 5px #b9bcbd;
        }

        .job_title {
            color: #0a6cff;
            font-size: 28px;
            font-weight: bold;
            font-family: Verdana, Geneva, Tahoma, sans-serif;
            text-decoration: underline;
        }

        .com {
            font-size: 15px;
            font-family: Verdana, Geneva, Tahoma, sans-serif;
        }

        .j_d,
        .e_c {
            font-size: 15px;
            font-family: Verdana, Geneva, Tahoma, sans-serif;
            font-weight: bold;
        }

        .j_d2,
        .e_c2 {
            font-size: 14px;
            font-family: Verdana, Geneva, Tahoma, sans-serif;
        }

        .btn {
            width: 200px;
            height: 45px;
            margin-left: 400px;


        }
    </style>
</head>

<body>
    <div class="container-fluid">

        <?php
        include 'header.php';
        ?>

        <div class="jumbotron" align="center">
            <h1>Recent Jobs </h1>
            <p> Related to your information. </p>
        </div>
        <br>

        <?php
        $u = $_SESSION['email'];

        $records = "select * from applicant_other where Email ='$u'";
        $sql = mysqli_query($con, $records);


        while ($data = mysqli_fetch_array($sql)) {
            $n1 = $data['post'];
        }

        $records1 = "select * from jobs where job_title ='$n1'";
        $sql1 = mysqli_query($con, $records1);


        while ($data = mysqli_fetch_array($sql1)) {
            $m1 = $data['cname'];
            $m2 = $data['cwebsite'];
            $m3 = $data['job_title'];
            $m4 = $data['job_desc'];
            $m5 = $data['job_eligibility'];
            $m6 = $data['job_type'];
            $m7 = $data['end_date'];
            $m8 = $data['location'];
        ?>
            <form method="post">
                <div class="job">
                    <h3 class="job_title" name="jobtitle"> <?php echo "$m3"; ?> </h3>
                    <br>
                    <h5 class="com"> Company : <?php echo "$m1"; ?> </h5>
                    <h5 class="com"> Website : <?php echo "$m2"; ?> </h5>
                    <br>
                    <h5 class="j_d"> Job Description: </h5>
                    <p class="j_d2"> <?php echo "$m4"; ?> </p>
                    <br>
                    <h5 class="e_c"> Eligibility Crietria : </h5>
                    <p class="e_c2"> <?php echo "$m5"; ?> </p>
                    <br>
                    <h5 class="com"> Job Type : <?php echo "$m6"; ?> </h5>
                    <h5 class="com"> End Date : <?php echo "$m7"; ?> </h5>
                    <h5 class="com"> Location : <?php echo "$m8"; ?></h5>
                    <br>

                    <input type="submit" class="btn btn-primary" name="message" value="Apply">
                </div> <br><br><br><br><br>
            </form>

        <?php
        }
        ?>
        <br><br><br><br><br><br>
        <div class="jumbotron" align="center">
            <h1>Other Available Jobs </h1>
            <p>Not Related to your information. </p>
        </div>

        <?php
        $records2 = "select * from jobs where job_title !='$n1'";
        $sql2 = mysqli_query($con, $records2);


        while ($data = mysqli_fetch_array($sql2)) {
            $r1 = $data['cname'];
            $r2 = $data['cwebsite'];
            $r3 = $data['job_title'];
            $r4 = $data['job_desc'];
            $r5 = $data['job_eligibility'];
            $r6 = $data['job_type'];
            $r7 = $data['end_date'];
            $r8 = $data['location'];
        ?>
            <form method="post">
                <div class="job">
                    <h3 class="job_title" name="jobtitle"> <?php echo "$r3"; ?> </h3>
                    <br>
                    <h5 class="com"> Company : <?php echo "$r1"; ?> </h5>
                    <h5 class="com"> Website : <?php echo "$r2"; ?> </h5>
                    <br>
                    <h5 class="j_d"> Job Description: </h5>
                    <p class="j_d2"> <?php echo "$r4"; ?> </p>
                    <br>
                    <h5 class="e_c"> Eligibility Crietria : </h5>
                    <p class="e_c2"> <?php echo "$r5"; ?> </p>
                    <br>
                    <h5 class="com"> Job Type : <?php echo "$r6"; ?> </h5>
                    <h5 class="com"> End Date : <?php echo "$r7"; ?> </h5>
                    <h5 class="com"> Location : <?php echo "$r8"; ?></h5>
                    <br>

                </div> <br><br><br><br><br>
            </form>

        <?php
        }
        ?>

        <?php
        include 'footer.php';
        ?>

    </div>
</body>

</html>

<?php
if (isset($_POST['message'])) {

    $q = "insert into applications values('$u','$m1','$m2','$m3','$m4','$m5','$m6','$m7','$m8')";

    if ($con->query($q)) {
        echo "<script> alert ('Applied !  ') </script>  ";
    } else {
        echo "ERROR";
    }
}
?>