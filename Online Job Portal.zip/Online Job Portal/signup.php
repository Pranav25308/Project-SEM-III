<?php 
include 'connection.php';
?>

<!DOCTYPE html>
<html>
        <head>
        <script src="https://smtpjs.com/v3/smtp.js">
</script>
        <meta charset="UTF-8">
        <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>
    <link href="style-signup.css" rel="stylesheet">
    <link rel="icon" href="images/logo.png" type="image/icon type">
    <title> Sign Up </title>
    <style> 

    </style>

                    
        </head>
    <body>
        <div class="container-fluid">

            <?php 
             include 'header2.php';
            ?>
            
            <div class="jumbotron" align="center">
                <h2> Register Yourself Here.  </h2>
            </div>

            <br><br>
            <div class="iam">
                <label for="iam"> <h3  style="margin-left:50px;"> I Am Here For </h3></label> <br>
                <select id="iam" name="iam" class="form-control">
                    <option value=""> -- select -- </option>
                    <option value="user"> Getting a Job </option>
                    <option value="company"> Hiring talent </option>
                </select><br><br>
                <font>Already Registered ? <a href="login.php"> Login Here ! </a></font>
            </div> <br>
            <br><br>
                            <script> 
                            $('#iam').on('change' , function(event){
                                var i = $('#iam').val();
                                if(i=="user")
                                {
                                    $('.Seeker').css({
                                        'display':'block'
                                    });
                                    $('.Company').css({
                                        'display':'none'
                                    });
                                }
                                else if(i=="company")
                                {
                                    $('.Company').css({
                                        'display':'block'
                                    });
                                    $('.Seeker').css({
                                        'display':'none'
                                    });
                                }
                                else {
                                    $('.Seeker').css({
                                        'display':'none'
                                    });
                                    $('.Company').css({
                                        'display':'none'
                                    });
                                }
                            });

                            </script>


            <div class="Seeker" style="display:none;">
            <br>
            <form  method="post" name="f1"> 
                <table align="center" cellspacing="10px" cellpadding="10px">

                    <tr> 
                    <td> <label for="aname"> Name. </label><font color="red" size="4px"> * </font> </td>
                    <td> <input type="text" id="aname" class="form-control" name="name" placeholder="Enter Your Full Name." pattern="[a-zA-Z ]+" title="Please use alphabets only." required>  </td>
                    </tr>

                    <tr> 
                        <td> <label for="acon"> Contact No. </label> <font color="red" size="2px"> * </font> </td>
                        <td> <input type="text" id="acon" class="form-control" placeholder="Enter Your Contact Number." name="pcon" pattern="(7|8|9)\d{9}" title="Please Enter 10 Digit Contact Number.It Must Be Start With 7 or 8 or 9 ." required> </td>
                    </tr>

                    <tr> 
                    <td> <label for="aemail">Email. </label><font color="red" size="4px"> * </font> </td>
                    <td> <input type="email" id="aemail" class="form-control" placeholder="Enter your Email." name="email" required>  </td>
                    </tr>

                    <tr> 
                    <td> <label for="apass">Password.  </label><font color="red" size="4px"> * </font> </td>
                    <td> <input type="password" id="apass" class="form-control" placeholder="Enter a password." name="pass" pattern="(?=.*\d)(?=.*[a-z])(?=.*[A-Z]).{8,}" title="Must contain at least one number and one uppercase and lowercase letter, and at least 8 or more characters" required>  </td>
                    </tr>

                </table> <br> 
                <button type="submit" name="Seeker_btn" id="signup1"> Sign Up </button>
                </form>
                          <br>
            </div>


            <div class="Company" style="display:none;">
                <br>
                <form method="post" name="f2">  
                <table align="center" cellspacing="10px" cellpadding="10px">

                    <tr> 
                    <td> <label for="name"> Company Name. </label><font color="red" size="4px"> * </font> </td>
                    <td> <input type="text" id="name" class="form-control" name="cname" placeholder="Enter Your Full Name." pattern="[a-zA-Z ]+" title="Please use alphabets only." required>  </td>
                    </tr>

                    <tr> 
                        <td> <label for="pcon"> Comany Contact No. </label> <font color="red" size="2px"> * </font> </td>
                        <td> <input type="text" id="pcon" class="form-control" placeholder="Enter Mobile Number." name="ccon" pattern="(7|8|9)\d{9}" title="Please Enter 10 Digit Contact Number.It Must Be Start With 7 or 8 or 9 ." required> </td>
                    </tr>

                    <tr> 
                    <td> <label for="email">Email. </label><font color="red" size="4px"> * </font> </td>
                    <td> <input type="email" id="email" class="form-control" placeholder="Enter your Email." name="cemail" required>  </td>
                    </tr>

                    <tr> 
                    <td> <label for="pass">Password.  </label><font color="red" size="4px"> * </font> </td>
                    <td> <input type="password" id="pass" class="form-control" placeholder="Enter a password." name="cpass" pattern="(?=.*\d)(?=.*[a-z])(?=.*[A-Z]).{8,}" title="Must contain at least one number and one uppercase and lowercase letter, and at least 8 or more characters" required>  </td>
                    </tr>

                </table> <br> 
                <button type="submit" id="signup2" name="company_btn"> Sign Up </button>
                </form>
                
        
                
                          <br>
            </div>

            <br><br><br><br><br><br><br>

            <?php  
             include 'footer.php';
            ?>
        </div>
    </body>
</html>


<?php

//error_reporting(0); 

if(isset($_POST['Seeker_btn']))
{
    $n1=$_POST["name"];
    $n2=$_POST["pcon"];
    $n3=$_POST["email"];
    $n4=$_POST["pass"];
    //$n5 = md5($n4);
    //$n5 = password_hash($n4); 

    $sql = "select * from student_signup where Email='$n3' OR Contact='$n2'";
    $result = mysqli_query($con,$sql);
    if (mysqli_num_rows($result) > 0)
    {
        echo "<script> alert('This Email or Contact is already registered , Try to Login with Same or Use Another Email or Contact to Register.') </script>";
    }
    else
    {

        $q="insert into student_signup values('$n1','$n2','$n3','$n4')";
        if($con -> query($q))
        {

        echo "<script> alert ('Your have Registered Successfully.You Can Login to Your Account Using Registred Email and Password to complete the profile. ') </script>  ";
        echo "<script> window.location='login.php'</script>  ";
        }
    }
}


if(isset($_POST['company_btn']))
{
    $n5=$_POST["cname"];
    $n6=$_POST["ccon"];
    $n7=$_POST["cemail"];
    $n8=$_POST["cpass"];

    $sql0 = "select * from company_signup where Com_Email='$n7' OR Com_Contact='$n6'";
    $result0 = mysqli_query($con,$sql0);
    
    if (mysqli_num_rows($result0) > 0)
    {
        echo "<script> alert('This Email or Contact is already registered , Try to Login with Same or Use Another Email or Contact to Register.') </script>";
    }
    else
    {
    $q="insert into company_signup values('$n5','$n6','$n7','$n8')";

    if($con -> query($q))

{
    $headers = "MIME-Version: 1.0" . "\r\n";
  $headers .= "Content-type:text/html;charset=UTF-8" . "\r\n";
  $message = "Done ! ";
  $subject = "Testing !";
  if (mail($n7, $subject, $message, $headers)) {
   echo "Email sent";
  }else{
   echo "Failed to send email. Please try again later";
  }
    echo "<script> alert ('Your Registration Process is Completed.You Can Login to Your Account Using Registred Username and Password. ') </script>  ";
    echo "<script> window.location='login.php'</script>  ";
}
    }
}
?>