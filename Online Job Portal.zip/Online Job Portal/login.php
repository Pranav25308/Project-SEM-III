<?php 
include 'connection.php';
?>
<!DOCTYPE html>
<html>
        <head>
        <meta charset="UTF-8">
        <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>
    <link href="style-login.css" rel="stylesheet">
    <link rel="icon" href="images/logo.png" type="image/icon type">
    <title> Log In </title>
    <style> 

    </style>

    <script>
    </script>
        </head>
    <body>
        <div class="container-fluid">

            <?php 
             include 'header2.php';
            ?>
            
            <div class="jumbotron" align="center">
                <h2> Log in Here.  </h2>
            </div>

            <br>
            <font size="3px" style="margin-left:650px;;"> New User ? <a href="signup.php"> Register Here ! </a></font>
            <br><br> <br>
            <div class="logins">
                <div class="user-login">
                    <button id="user-login">  Applicant Login </button>
                    <br><br><br><br><br>
                    <div id="usercontent">
                        <form method="post">
                        <input type="email" name="emp_em" placeholder="Enter Your Email here." class="form-control" required> <br> 
                        <input type="password" name="emp_pass" id="id_password" placeholder="Enter Your Password here." class="form-control" required> <br>
                        <i class="fa fa-eye" id="togglePassword" style="margin-left: 560px; cursor: pointer;display:inline-block;font-size:20px;"> </i> 
                        <button type="submit" class="btn" style="background-color:#2294f2;width:150px;border-radius:7px;color:white;margin-left: 630px;" name="emp_log"> Log In <i class="glyphicon glyphicon-log-in"></i> </button>
                        </form>
                    </div>
                </div>

                <script>
                    const togglePassword = document.querySelector('#togglePassword');
                    const password = document.querySelector('#id_password');
                    togglePassword.addEventListener('click', function (e) {
                        // toggle the type attribute
                        const type = password.getAttribute('type') === 'password' ? 'text' : 'password';
                        password.setAttribute('type', type);
                        // toggle the eye slash icon
                        this.classList.toggle('fa-eye-slash');
                    });
                </script>
                <script>
                        $('#user-login').click(function(){
                            $('#usercontent').css({
                                'display':'block'
                            });
                            $('#admincontent').css({
                                'display':'none'
                            });
                            $('#companycontent').css({
                                'display':'none'
                            });
                            $('.user-login').css({
                                'border-bottom':'3px solid #4d86e8',
                                'transition':'0.3s ease'
                            });
                            $('.company-login').css({
                                'border':'none'
                            });
                            $('.admin-login').css({
                                'border':'none'
                            });
                        });
                    </script>

                <div class="company-login">
                    <button id="company"> Company Login</button>
                    <br><br><br><br><br>
                    <div id="companycontent">
                        <form method="post">
                        <input type="email" name="com_em" placeholder="Enter Your Company Email here." class="form-control" required> <br> 
                        <input type="password" name="com_pa" placeholder="Enter Your Password here." class="form-control" required> <br> <br> 
                        <button class="btn" name="com_log" style="background-color:#2294f2;width:150px;border-radius:7px;color:white;margin-left: 630px;"> Log In <i class="glyphicon glyphicon-log-in"></i> </button>
                        </form>
                    </div>
                
                    <script>
                        $('#company').click(function(){
                            $('#companycontent').css({
                                'display':'block'
                            });
                            $('#admincontent').css({
                                'display':'none'
                            });
                            $('#usercontent').css({
                                'display':'none'
                            });
                            $('.company-login').css({
                                'border-bottom':'3px solid #4d86e8',
                                'transition':'0.3s ease'
                            });
                            $('.user-login').css({
                                'border':'none'
                            });
                            $('.admin-login').css({
                                'border':'none'
                            });
                        });
                    </script>       
                </div>

                <div class="admin-login">
                    <button id="admin-login"> Admin Login</button>
                    <br><br><br><br><br>
                    <div id="admincontent" style="display:none;">
                    <form method="post">
                        <input type="text" placeholder="Enter Your Admin Username/Email here." class="form-control" name="adm_u"> <br> 
                        <input type="password" placeholder="Enter Your Password here." class="form-control" name="adm_p"> <br> <br> 
                        <button class="btn" name="adm_log" style="background-color:#2294f2;width:150px;border-radius:7px;color:white;margin-left: 540px;"> Log In <i class="glyphicon glyphicon-log-in"></i> </button>    
                    </form>
                </div>
                </div>

                    <script>
                        $('#admin-login').click(function(){
                            $('#admincontent').css({
                                'display':'block'
                            });
                            $('#usercontent').css({
                                'display':'none'
                            });
                            $('#companycontent').css({
                                'display':'none'
                            });
                            $('.admin-login').css({
                                'border-bottom':'3px solid #4d86e8',
                                'transition':'0.3s ease'
                            });
                            $('.company-login').css({
                                'border':'none'
                            });
                            $('.user-login').css({
                                'border':'none'
                            });
                        });
                    </script>
            </div>
            
            <br><br><br><br><br><br><br><br><br><br><br>

            <?php  
             include 'footer.php';
            ?>

        </div>
    </body>
</html>


<?php 
//error_reporting(0);

if(isset($_POST['emp_log']))
{
	$u=$_POST["emp_em"];
	$p=$_POST["emp_pass"];
    //$_SESSION['username'] = $u;

    $sql="select Email AND Password from student_signup where Email='$u' AND Password='$p' ";
    $result=mysqli_query($con,$sql);

    if(mysqli_num_rows($result)==1)
    {
        //echo "<script>alert('Welcome back !!') </script>";
        $_SESSION['email']=$u;
        echo "<script> window.location='Applicant/applicant-check.php'</script>  ";
    }
    else
    {
    echo "<script> alert('Incorrect Email or Password. !!') </script> ";
    exit();
    }
}

if(isset($_POST['com_log']))
{
	$u=$_POST["com_em"];
	$p=$_POST["com_pa"];

    $sql="select Com_Email AND Com_Pass from company_signup where Com_Email='$u' AND Com_Pass='$p' ";
    $result0=mysqli_query($con,$sql);

    if(mysqli_num_rows($result0)==1)
    {
        //echo "<script>alert('Welcome back !!') </script>";
        $_SESSION['email']=$u;
        echo "<script> window.location='Recruiter/recruiter-profile.php'</script>";
    }
    else
    {
    echo "<script> alert('Incorrect Email or Password. !!') </script> ";
    exit();
    }
}

if(isset($_POST['adm_log']))
{
	$u=$_POST["adm_u"];
	$p=$_POST["adm_p"];

    $sql="select Username AND Password from admin where Username='$u' AND Password='$p' ";
    $result0=mysqli_query($con,$sql);

    if(mysqli_num_rows($result0)==1)
    {
        //echo "<script>alert('Welcome back !!') </script>";
        $_SESSION['email']=$u;
        echo "<script> window.location='Admin/admin-index.php'</script>";
    }
    else
    {
    echo "<script> alert('Invalid Permission') </script> ";
    exit();
    }
}
?>