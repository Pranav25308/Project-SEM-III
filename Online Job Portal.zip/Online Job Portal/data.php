<!DOCTYPE html>
<html>

<head>
    <title></title>
   
</head>

<body>
    <form method="post" name="f1">
        <table align="center" cellspacing="10px" cellpadding="10px">

            <tr>
                <td> <label for="aname"> Name. </label>
                    <font color="red" size="4px"> * </font>
                </td>
                <td> <input type="text" id="aname" class="form-control" name="name" placeholder="Enter Your Full Name."> </td>
            </tr>

            <tr>
                <td> <label for="aemail">Email. </label>
                    <font color="red" size="4px"> * </font>
                </td>
                <td> <input type="email" id="aemail" class="form-control" placeholder="Enter your Email." name="email"> </td>
            </tr>
        </table> <br>
        <button type="submit" name="Seeker_btn" id="signup1"> Sign Up </button>
    </form>

    <button type="button" onclick="mail()"> Send </button>
    <script src="https://smtpjs.com/v3/smtp.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.5.1/jquery.js"> </script>
    <script>
        function mail() {

            Email.send({
                SecureToken: "e32595a7-851f-45e3-9dc8-4bcbf5bcc527",
                To: 'pranavyadav700@gmail.com',
                From: "pranavydv79@gmail.com",
                Subject: "This is the subject",
                Body: "And this is the body"
            }).then(
                message => alert(message)
            );
            }
    </script>

    <script>
            function mail1() {
                //var x = f1.name.value
                //var y = f1.email.value
                Email.send({
                    SecureToken: "190bf3d1-7f8e-41bb-9c47-4fa5dd0e57bb",
                    To: 'pranavyadav700@gmail.com',
                    From: "pranavydv79@gmail.com",
                    Subject: "About Registration Process.",
                    Body: ` <h3> Hello , <h3> <font color="green"> <h1>  </font> </h1> <h3>  Congratulations for registering yourself on our platform. Please continue the process by logging in and complete your profile. Thank You. </h3> <h4> <a href="#"> Click Here to Login </a> </h4>.`
                }).then(
                    message => {
                        //console.log (message);
                        if (message == 'OK') {
                            alert('m');
                        } else {
                            console.error(message);
                            alert(message)
                        }
                    }
                );
            }
    </script>
</body>

</html>

<?php
if (isset($_POST['Seeker_btn'])) {
    $n1 = $_POST["name"];
    $n2 = $_POST["email"];

    $subject = "This is subject";

    $message = "<b>This is HTML message.</b>";
    //$message .= "<h1>This is headline.</h1>";

    $header = "From:abc@somedomain.com \r\n";
    //$header .= "Cc:afgh@somedomain.com \r\n";
    //$header .= "MIME-Version: 1.0\r\n";
    //$header .= "Content-type: text/html\r\n";

    mail($n2, $subject, $message, $header);


    $cn = mysql_connect("localhost", "root");
    $db = mysql_select_db("job", $cn);

    $q = "insert into demo values('$n1','$n2')";

    echo "<script> alert ('Done ! ') </script>  ";
    //echo "<script> window.location='login.php'</script>  ";

    mysql_query($q);
    mysql_query($cn);
    //mysql_query($retval);
}
?>