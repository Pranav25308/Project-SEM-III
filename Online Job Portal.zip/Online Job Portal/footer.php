<hr style="border-top: 3px solid black;">

                <div class="footer">
                    <h4 class="ft"> @ | All Copyrights Reserved | Online Job Portal. </h4>
                </div>